# OMEGA X10 v4 test evidence — index

| Folder / file | Contents |
|---|---|
| `inputs.sha256` | hashes of the v3 inputs used (read-only copies) |
| `BASELINE-v3.json`, `baseline_v3*.{txt,json}` | v3.0.0 baseline on dev / validation / Phase 3 blind / dev4 / val4 |
| `val4_hygiene.txt` | near-duplicate removal for val4 (300 → 297) |
| `c1/` | candidate C1 at freeze: fingerprint, bench, workflow gate |
| `blind4a*`, `blind4a/` | round 1: frozen set hash and hygiene, C1 evaluation (77.1%), v3 vs C1 comparison |
| `c2/` | candidate C2 (= v4.0.0) at freeze: fingerprint, unit tests, bench, workflow gate, full-pipeline CV 77.9%, fusion variant CVs |
| `blind4b*`, `blind4b/` | round 2 (final): frozen set hash and hygiene, the single C2 evaluation (82.1%), v3/C1/C2 comparison, evaluator audit, fingerprint at evaluation |
| `security/` | scanners run on C1 (bandit, semgrep local + registry attempt log, detect-secrets, pip-audit) |
| `security-c2/` | scanners re-run on the release code (bandit, semgrep local, detect-secrets, pip-audit) |
| `taskapp/`, `taskapp-c2/` | task app regression: npm test, typecheck, lint, npm audit, E2E (Chromium), browser availability |
| `perf/` | latency / memory / pathological-input benchmark |
| `pyversions/` | unit tests on Python 3.11, 3.12, 3.13 (incl. the pre-dependency 3.11/3.12 logs) |
| `fresh/` | fresh extraction of omega-x10-v4.0.0.zip: archive check, quick_validate, doctor, fingerprint, 138 unit tests, bench 162/162, workflow gate 57/57, blind4b re-run 716/872 |
| `git-log.txt` | commit history v3.0.0 → v4.0.0 (freeze commits bbea294, blind freeze 439e0a4) |
