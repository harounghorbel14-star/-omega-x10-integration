# Changelog

## 4.0.0 — 2026-10-25

Release candidate C2. Router fingerprint `5db7c2547c297d7608f2dcc2f946e578c9fad0e02d812996e127b9dc73f5e64a`, workflow fingerprint `4675a25d7e26589e76d522f5ab6d2d5ee0a26e3fc3a8f97b69412287bf6558a3` (`omega.py fingerprint`).

### Routing: a layered, offline architecture
- **Contextual classifier layer** (`components/omega-engineering-x10/scripts/omega_classify.py`, `components/omega-engineering-x10/registry/classifier.json`).
  - Standard-library logistic regression, one-vs-rest. Features: character 3–5-grams, words and bigrams, Arabizi skeletons, lexicon concepts and the rule layer's scores.
  - Heads for 18 intents plus route / none / clarify outcome heads.
  - Applied to text with negated and discussion spans removed, on the whole request and per clause (`clause_tau`).
- **Deterministic trainer** (`components/omega-engineering-x10/scripts/omega_train.py`, `components/omega-engineering-x10/tests/train_classifier.sh`). Development data only, n=6898: dev, dev4, train4–7, the retired Phase 3 blind set, and the retired blind4a set. val4 and validation were folded in only after policy selection. The trainer needs numpy + scikit-learn; inference does not.
- **Fusion policy** recorded in the model file:
  - per-intent thresholds;
  - rule-backed routes when the classifier says clarify but the rules have concrete evidence (stricter, `rule_concrete_min_p`, for a verb with a named non-generic object);
  - rule fallback;
  - discussion veto.

  Every decision reports both layers, the probabilities and the strongest features. `route --rules-only` or `OMEGA_CLASSIFIER=off` disables the classifier.
- **Optional external adapter** (`components/omega-engineering-x10/scripts/omega_adapter.py`): off by default, never used without explicit consent, advisory only, offline fallback on any failure or invalid output (tests with a fake adapter).

### Phase 3 failure classes fixed in the rule layer (`components/omega-engineering-x10/scripts/omega_lang.py`, `components/omega-engineering-x10/registry/lexicon.json`)
- **A. Negation**
  - Subject-aware descriptive negation is now bug evidence: "images don't load", "الصور لا تظهر", "ma tetla3ch".
  - First-person plural negation is handled ("ma ndeployiwech", "ما ننشروش").
  - Lexical negation is handled: "leave … alone", "sans toucher", "ما تمسش".
  - Post-posed negation is handled ("X mouch lazma", "X not needed").
  - "Don't want / je ne veux pas" is recognised.
  - Negation scope is clause-local.
- **B. Vocabulary**: lexicon additions from development-set error analysis; the classifier covers open vocabulary.
- **C. Verb–object**: causative "make X faster" → performance; V_CODE verbs; "find why" → debugging; "find current info" → research.
- **D. Multi-step**: clause-level classification. Time clauses ("after you fix", "before deploying") set the order. Steps follow the order in which they are requested (measured better than forcing git/deploy last), and hard dependencies are kept in `depends_on`.
- **E. Arabizi collisions**: Latin matches take precedence over skeletons, and short skeletons need a raw-spelling match (bouton/boutique, tahni2a, scraping).
- **F. Over-matching**: token-boundary fixes for `heberge*` and `profil(e)`. Malformed registry patterns are skipped with a warning and never crash.
- **G. Discussion vs action**:
  - An evaluative-question frame ("is X worth/free?", "c'est vraiment utile ?", "هل…؟") is discussion.
  - Discussion masks start at the marker's clause, so "go over this diff and tell me what's risky" still routes.
- **H. Clarification**: the outcome heads decide clarify / none / route, with rule-backed overrides for concrete requests.

### Orchestration
- **`components/omega-engineering-x10/scripts/omega_workflow.py`** (new; `omega.py workflow validate|run|status|from-route`):
  - **Spec validation**: ids, prerequisites, cycles (the cycle path is printed), inputs bound to prerequisites' outputs, relative paths inside the workdir, argv-only commands, retry 1–5, timeout bounds, confirmation kinds.
  - **Execution**: subprocess without a shell, real exit codes, timeouts, bounded retries, output validators, sha256 ledger, secret redaction.
  - **Recovery and gating**: resume after interruption, stale-artifact detection, refusal when the spec changed, and confirmation gates for destructive/external/financial/publishing/deployment steps.
  - **Statuses**: READY / LIMITED / BLOCKED / RUNNING / COMPLETE / FAILED / SKIPPED; the run is COMPLETE / PARTIAL / FAILED / BLOCKED.
- **`components/omega-engineering-x10/tests/workflow_gate.py`**: the declared multi-step acceptance matrix, 57 scenarios with deterministic fake tools, covering the following, and audited against ledger invariants:
  - 2/3/5/10-step chains, branching, independent branches and aggregation;
  - missing optional/required tools, failures, timeouts, exhausted retries, corrupted artifacts, exit 0 without output, crashes;
  - confirmation gates, 16 invalid specs and 4 recovery cases;
  - 10 routed multilingual workflows.
- `omega.py run init/next/start/done/fail/report` (v3 ledger) is unchanged for backward compatibility.

### Evaluation and evidence
- New independently authored corpora (see `components/omega-engineering-x10/tests/corpus/README.md`): dev4 400, val4 297, train4–7 4,775, blind4a 896 (round 1), blind4b 872 (round 2, final).
- `routing_eval.py` adds:
  - strict exact match (set + order);
  - critical negation and ambiguity subsets;
  - unrequested external actions;
  - macro F1;
  - results by difficulty.
- `cv_route.py`: full-pipeline k-fold cross-validation. `eval_audit.py`: an independent evaluator audit covering denominators, re-judging, leakage, labels, unsupported tools and fingerprint. `perf_bench.py`: latency, memory and pathological inputs.
- **Blind results** (single runs on frozen candidates):
  - C1: 77.1% on blind4a (n=896).
  - C2 (this release): **82.1% on blind4b (n=872, CI 79–84)**; v3.0.0 scores 50.3% on the same set.
  - The 100% routing gate is **not passed**.
- Multi-step gate: 57/57 scenarios, all criteria at 100%.

### Unchanged / preserved
- All 23 intents, capability statuses, the connector consent rules, the Replica and ECC components, the AI-Engineer catalogue, and the Phase 2 regression bench (162/162).

## 3.0.0 — 2026-10-24

### Multilingual routing (`components/omega-engineering-x10/scripts/omega_lang.py`, `components/omega-engineering-x10/registry/lexicon.json`)

- **New language layer** for English, French, Arabic script (MSA and Tunisian), Tunisian Arabizi and code-switched prompts.
  - Normalisation: accents and Arabic diacritics/hamza seats dropped, ة/ى unified, Arabic digits and punctuation converted, English contractions expanded.
  - 63 language-independent concepts matched as Latin words, prefixes and phrases; Arabic stems after clitic stripping; Arabizi consonant skeletons (so `sala7li`, `salla7li`, `sallahli` meet).
- **Verb–object rules** (54) with nearest-object attachment. Later objects are modifiers ("tests *for the module*"). Relative clauses ("that/qui/elli/اللي") don't take the outer verb. Coordinated objects inherit the previous verb, and "just/juste/barka/فقط + deliverable" counts as a request.
- **Negation scope** to the end of the clause, for imperative negation only. Descriptive negation ("ne marche pas", "ma ye5demch", "ما يخدمش") is bug evidence.
- **Discussion frames** ("what is", "c'est quoi", "chnowa", "شنوة", "explain") mask execution evidence unless the clause has an execution verb. Naming a tool is not a request to use it.
- **New `documents` intent** (documents, spreadsheets, presentations): 23 intents.
- **Ordered plans.** Multi-intent results include `steps`: the sub-task text, the order in which it was asked (deploy and git last) and dependencies (explicit "then/puis/ba3d/ثم", anaphora "it/-la/-ha/ـها", and domain rules such as tests after code).
- **Penalties apply to both evidence layers**, and the creation-verb gate works per clause and in every language.

### Capability-aware status and orchestration

- **Status from real availability.** Status comes from the calling session's tool list (`--session-tools` / `OMEGA_SESSION_TOOLS`) and the user's authorisations (`--authorized` / `OMEGA_AUTHORIZED`):
  - connectors are never READY without both;
  - a tool the user named that isn't usable makes the step LIMITED with an explicit "ask before substituting".
- **New `omega.py run` ledger** (`components/omega-engineering-x10/scripts/omega_orchestrate.py`): `init`, `next`, `start`, `done`, `fail`, `report`.
  - Prerequisites must be DONE with artifacts whose sha256 still matches.
  - BLOCKED steps never start, and failures skip their dependents while independent steps continue.
  - Consent-gated connectors need authorisation.
  - `report` exits 3 on partial completion.

### Robustness

- A malformed regex in `intents.json` no longer crashes `route`: it is skipped, reported in `warnings` and listed by `check-routes`.
- A broken `lexicon.json` degrades routing to English-only, with a warning.
- `check-routes` validates the lexicon: roles, entry types, unknown concepts in rules, generic objects that could select a route alone, and tool→intent links.

### Evaluation (`components/omega-engineering-x10/tests/`)

- **Corpora** (`corpus/`): dev (143) and validation (100), committed before any v3 change, plus a blind set (125) written after the router freeze and evaluated once. Each covers 5 language groups and 6 categories.
- **`routing_eval.py`** measures any router generation on the same items:
  - exact match with Wilson CIs, and accuracy on items whose correct answer is a route;
  - per-intent precision/recall/F1 and a confusion matrix;
  - ordering accuracy, false security selections, clarification rates (overall, wrong, missed) and unsupported-tool selection;
  - an exact paired test between routers.
- `threshold_sweep.py` picks thresholds on validation with a Phase-2 no-regression guard.
- New suites: `test_multilingual.py` (normalisation, Arabizi variants, negation, discussion, generic words, multi-intent, tool availability and consent, false-positive traps, malformed registries, corpus hygiene, accuracy floors) and `test_orchestrate.py`.

### Results (same items, fixed skill fixture)

| | v1 | v2 | v3 |
|---|---:|---:|---:|
| Blind exact match (125, single run) | 14.4% | 31.2% | 68.0% |
| Validation exact match (100) | 14.0% | 44.0% | 90.0% |

The full metrics and the 40 attributed blind errors are in the Phase 3 report.

### Known limitations (found by the blind run; deliberately not fixed in the measured router)

- **Arabizi skeleton collisions:** prefix matching hits French/English words in Arabizi contexts (`bouton`, `boutique`, `scraping`, `tahni2a`).
- **Negation:**
  - descriptive negation with an explicit subject is treated as imperative ("images don't load", 3rd-person feminine `لا تصل` / `ma tetla3ch`);
  - first-person plural negation (`ma ndeployiwech`) and lexical negation ("leave X alone", "inutile de", "X mouch lazma") are not caught.
- **Penalties apply to the whole prompt:** a penalty in one clause can suppress a step in another (an "export" clause suppresses a "présentation" step).
- **Arabic suffix anaphora is lost on full-token matches** (`حركه`).
- **Morphology:** re-prefixed verbs (`redeploy`) are missed, and French noun/verb prefixes overlap (`heberge*` matches `hébergeurs`).
- **Vocabulary gaps:** filtre, veille, importer, برمج, اجمع آراء, تسريب الذاكرة; "code" as a verb.
- **Discussion frames not caught:** "is X still worth…", `هل …؟`.

## 2.0.0 — 2026-10-24

### Router (`components/omega-engineering-x10/scripts/omega.py`, `components/omega-engineering-x10/registry/intents.json`)

- **Fixed:** routes no longer fire on a single shared word. The old scorer (line 146) gave every route a point for any token shared with any trigger phrase, so "app" selected the security, browser-automation and app-replication routes.
- **New intent-based scoring.**
  - Weighted phrase / term / weak evidence is defined per intent in `intents.json`.
  - Negative evidence is supported ("log in to the portal" is navigation, not security).
  - Creative deliverables (image, video, 3D) need an action verb.
  - A noun directly after an action verb counts as the request's object.
  - Overlapping matches count once, and gap patterns stop at clause boundaries.
- **Thresholds and decisions.** A route needs at least 2.5 evidence to be selected. Secondary routes must reach 40% of the top score unless the prompt chains steps with "and", "then" or a comma. The router returns one of:
  - **route**: one specialist route.
  - **multi**: several routes, with a phase-ordered execution plan.
  - **clarify**: a question for the user.
  - **none**: no specialist route.
- **Explanations.** Every result lists:
  - the matched evidence, penalties and gates;
  - the strongest unselected alternatives;
  - a confidence value;
  - the generic words it ignored;
  - stack context.
- **New capability routes:** web research, image generation/editing, video/animation and 3D, alongside the existing engineering, browser, security, testing and deployment routes (22 intents in total).
- **Live availability per route.**
  - Statuses are READY, FALLBACK, LIMITED or BLOCKED.
  - Availability is checked against installed skills (`OMEGA_SKILL_ROOTS` overrides the search roots) and the fallback's tools.
  - Connectors are never reported as available, because only the session can confirm them, and they require user consent.
  - A request the fallback can't satisfy, such as photorealistic images or Blender work, is reported as LIMITED.

### Integrity

- **Fixed 4 broken internal references.** The 1.x audit reported 2; the corrected count is 4:
  - `sources/replica/...` should have been `references/replica/...`;
  - the replica stage files are `replica-<stage>.md`, not `SKILL.md`.
- **`doctor` severities.**
  - Fatal: package files, registry, references, hash manifest.
  - Optional: tools that only degrade some routes.
  - Warn: duplicate OMEGA installs.
  - Info: per-route readiness.
- **New `doctor` flags.** `--strict` was documented but not implemented; it now works. `--offline` skips network checks.
- **Reference scanner** now resolves plain paths, globs (`replica-*`), placeholders (`replica-<stage>`) and Markdown link targets.
- **`check-routes`** also validates `intents.json`:
  - regexes compile;
  - required fields are present;
  - rule links resolve;
  - every intent has phrase-level evidence;
  - no generic word can select a route by itself.
  It reports bad regexes instead of crashing.
- **`FILE-SHA256.json`** is regenerated for the final files; 1.x had stale hashes for `SKILL.md` and `MERGE-MANIFEST.json`.

### Tests (`components/omega-engineering-x10/tests/`)

- `routing_bench.py` measures any router version on the same cases.
- `test_router.py` has 17 unit tests covering mechanics, availability, integrity, doctor exit codes and accuracy floors.
- Four routing sets, 162 prompts in total: dev (54), held-out-1 (40), held-out-2 (34) and a final blind set (34, measured once).

### Docs

- `SKILL.md` §2 now describes one router, how to act on each decision and status, connector consent, and duplicate installs.

### Known limits

- The router is English-only keyword evidence. On the final blind set it passed 18/34, against 11/34 for 1.x.
  - Most of its misses are abstentions (asking or declining), not wrong routes: 3 misroutes against 16 for 1.x.
  - Treat CLARIFY and NONE as "use your judgement".
- Duplicate standalone installs are detected, not removed.
