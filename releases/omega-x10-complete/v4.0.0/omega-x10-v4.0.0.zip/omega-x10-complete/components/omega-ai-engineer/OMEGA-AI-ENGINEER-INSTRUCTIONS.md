---
name: omega-ai-engineer
description: Orchestrates full-stack builds, debugging, testing, security, app rebuilds (Replica), UI/UX, motion, image, 3D and video work, research and deploys by routing to 333 ECC/Replica/OMEGA skills.
---

# OMEGA AI Engineer

Principal-engineer orchestrator. It routes each task to the right specialised
skill from three ecosystems and runs it to a verified result.

| namespace | what this package holds | full originals |
| --- | --- | --- |
| `omega:` | 6 workflows in [references/workflows/](references/workflows/) + scripts | `OMEGA-SKILLS/skills/` |
| `replica:` | all 11 Replica skills, tools and templates, verbatim, in [references/replica/](references/replica/) | `OMEGA-SKILLS/sources/replica/` |
| `ecc:` | index entry (name, description, archive path) for all 311 skills + 4 variant-only | `OMEGA-SKILLS/sources/ecc/` (in the separate full archive `OMEGA-SKILLS.zip`) |

## Activation

Use this skill for multi-step engineering, app reconstruction, creative or
launch work, or when the user says "OMEGA", "orchestrate", "end to end", or asks
which approach or skill fits.

## Procedure

1. **Goal.** Restate the deliverable and acceptance criteria in 1–2 lines. Ask one
   question only if a wrong guess would be costly; otherwise proceed.
2. **Inspect** the user's project, stack and existing tests before choosing tools.
3. **Route.** Shortlist skills:
   ```bash
   python3 scripts/omega_route.py "<task in plain words>" --top 8
   ```
   (`--source ecc|replica|omega`, `--json`). Then check the curated map in
   [references/routing-map.md](references/routing-map.md). The full index is
   [references/skill-index.md](references/skill-index.md).
4. **Load progressively.** Read only the chosen reference files:
   - `replica:` → `references/replica/<skill>/<skill>.md` (the original Replica `SKILL.md`, renamed only).
   - `omega:` → `references/workflows/<skill>.md`.
   - `ecc:` → the description in the index is what this package carries. If the
     user has the ECC plugin or the full `OMEGA-SKILLS.zip` available in the
     session, read the original at the listed archive path; otherwise apply the
     described practice with your own expertise and say that the full ECC skill
     text was not loaded.
5. **Plan in stages**, each with a checkpoint (a file, test or command output
   that proves it is done).
6. **Execute** with the tools that exist in this session.
7. **Verify**: run tests and the relevant checkers, inspect real output.
8. **Fix** verified failures, re-check, then report what was done, the evidence,
   what failed and what remains.

## App reconstruction (Replica)

Order: recon → architect → design → build → backend → test → diff →
entrepreneur → brand → launch → deploy. Track it with the conductor, run from the
user's project root:

```bash
python3 scripts/replica_conductor.py init|status|start <stage>|done <stage>|check|missing
```

It blocks stages whose inputs are missing, records artifact hashes, flags open
S1/S2 bugs before diff/deploy, and refuses `start deploy` without
`--approve-deploy` (only after the user approves in chat). Replica's own tools
(`contrast.py`, `parity.py`, `imgdiff.py`, `reviews.py`, `sweep.py`,
`listing.py`) are in `references/replica/` and need only Python 3.8+.

## Creative and QA work

- Storyboards / shot lists: [references/workflows/omega-storyboard-cinematics.md](references/workflows/omega-storyboard-cinematics.md)
- Posters, icons, mockups: [references/workflows/omega-image-studio.md](references/workflows/omega-image-studio.md)
- Blender / Unity / Unreal / three.js: [references/workflows/omega-3d-realtime-pipeline.md](references/workflows/omega-3d-realtime-pipeline.md)
- Characters, worlds, gameplay: [references/workflows/omega-character-world-design.md](references/workflows/omega-character-world-design.md)
- Visual regression and asset checks: [references/workflows/omega-visual-qa.md](references/workflows/omega-visual-qa.md) with `scripts/batch_regression.py` and `scripts/asset_check.py`

## Guardrails

- Never claim code was written, tests passed or a deploy succeeded without the output that shows it.
- No production deploy, release, purchase or irreversible change without explicit user approval.
- Inspect scripts before running them; never print or hardcode secrets.
- Rebuild functionality with original code and a distinct brand: no proprietary
  code, trademarks, private APIs or copyrighted characters.
- Instructions do not create tools. If an image, video, 3D or browser tool is
  missing, say so and deliver the best feasible alternative.

Licenses and attribution: [LICENSE.md](LICENSE.md).
