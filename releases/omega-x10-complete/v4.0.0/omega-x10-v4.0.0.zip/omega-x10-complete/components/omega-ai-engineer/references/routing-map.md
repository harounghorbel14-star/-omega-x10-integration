# OMEGA routing map

Curated starting points. Every `ns:name` below is checked by
`tools/verify_omega.py` and must resolve to a real skill in the catalog.
When two entries fit, read both descriptions and pick the one matching the
user's stack.

## Plan, orchestrate, verify

| need | skills |
| --- | --- |
| Break a big task into stages | `ecc:plan-orchestrate`, `ecc:blueprint`, `ecc:plan-canvas` |
| Multi-agent / parallel work | `ecc:team-agent-orchestration`, `ecc:parallel-execution-optimizer`, `ecc:dmux-workflows` |
| Ship-quality gates | `ecc:verification-loop`, `ecc:delivery-gate`, `ecc:production-audit` |
| Research before building | `ecc:search-first`, `ecc:deep-research`, `ecc:documentation-lookup` |
| Unknown codebase | `ecc:codebase-onboarding`, `ecc:code-tour`, `ecc:repo-scan` |
| Context / cost control | `ecc:context-budget`, `ecc:token-budget-advisor`, `ecc:strategic-compact` |

## Build software

| need | skills |
| --- | --- |
| MVP from scratch | `ecc:orch-build-mvp`, `ecc:orch-pipeline` |
| Add / change a feature | `ecc:orch-add-feature`, `ecc:orch-change-feature` |
| Fix a defect | `ecc:orch-fix-defect`, `ecc:agent-introspection-debugging` |
| Frontend | `ecc:frontend-patterns`, `ecc:react-patterns`, `ecc:nextjs-turbopack`, `ecc:vue-patterns`, `ecc:frontend-design-direction` |
| Backend / API | `ecc:backend-patterns`, `ecc:api-design`, `ecc:fastapi-patterns`, `ecc:nestjs-patterns` |
| Data | `ecc:postgres-patterns`, `ecc:database-migrations`, `ecc:prisma-patterns`, `ecc:redis-patterns` |
| Deploy / infra | `ecc:deployment-patterns`, `ecc:docker-patterns`, `ecc:kubernetes-patterns` |
| AI / LLM apps | `ecc:cost-aware-llm-pipeline`, `ecc:prompt-caching-strategy`, `ecc:mcp-server-patterns`, `ecc:eval-harness` |

## Test and secure

| need | skills |
| --- | --- |
| Test-first | `ecc:tdd-workflow`, `ecc:e2e-testing`, `ecc:browser-qa`, `ecc:ai-regression-testing` |
| Security | `ecc:security-review`, `ecc:security-scan`, `ecc:agent-security-hardening`, `ecc:safety-guard` |
| Accessibility | `ecc:accessibility`, `ecc:frontend-a11y` |
| Performance | `ecc:benchmark`, `ecc:react-performance`, `ecc:latency-critical-systems` |
| Visual regression | `omega:omega-visual-qa`, `replica:replica-diff` |

## Rebuild an app (Replica)

Drive with `omega:omega-replica-conductor`. Stage skills in order:
`replica:replica-recon` → `replica:replica-architect` → `replica:replica-design`
→ `replica:replica-build` → `replica:replica-backend` → `replica:replica-test`
→ `replica:replica-diff` → `replica:replica-entrepreneur` → `replica:replica-brand`
→ `replica:replica-launch` → `replica:replica-deploy`.

Useful ECC companions per stage: architect → `ecc:architecture-decision-records`;
build → `ecc:frontend-patterns`; test → `ecc:e2e-testing`; entrepreneur →
`ecc:market-research`, `ecc:competitive-platform-analysis`; brand →
`ecc:brand-discovery`, `ecc:brand-voice`; launch → `ecc:seo`, `ecc:content-engine`;
deploy → `ecc:deployment-patterns`, `ecc:delivery-gate`.

## Creative studio

| need | skills |
| --- | --- |
| Visual direction / design system | `ecc:frontend-design-direction`, `ecc:design-system`, `ecc:liquid-glass-design`, `ecc:make-interfaces-feel-better`, `ecc:taste` |
| UI motion | `ecc:motion-foundations`, `ecc:motion-patterns`, `ecc:motion-advanced` |
| Storyboards, shot lists, cinematic sequences | `omega:omega-storyboard-cinematics` |
| Programmatic video | `ecc:remotion-video-creation`, `ecc:manim-video`, `ecc:tasteforge-video`, `ecc:video-editing`, `ecc:videodb` |
| Images, icons, posters, mockups | `omega:omega-image-studio`, `ecc:fal-ai-media`, `ecc:ios-icon-gen` |
| 3D scenes, Blender, Unity, Unreal | `omega:omega-3d-realtime-pipeline`, `ecc:blender-motion-state-inspection` |
| Original characters, worlds, gameplay | `omega:omega-character-world-design` |
| Slides / demos | `ecc:frontend-slides`, `ecc:ui-demo` |
| Dashboards | `ecc:dashboard-builder` |

## Business and launch

| need | skills |
| --- | --- |
| Market & competitors | `ecc:market-research`, `ecc:competitive-report-structure`, `ecc:product-lens` |
| Content & distribution | `ecc:content-engine`, `ecc:article-writing`, `ecc:crosspost`, `ecc:social-publisher` |
| Fundraising | `ecc:investor-materials`, `ecc:investor-outreach` |
