---
name: omega-3d-realtime-pipeline
description: 3D production workflow across Blender, Unity, Unreal Engine and web 3D (three.js / React Three Fiber) — scene layout, modelling budget, materials (PBR), lighting, cameras, animation, rendering or real-time performance, and export between tools. Use for "Blender scene", "render this product in 3D", "Unity/Unreal level", "three.js hero", "glTF export", "lighting setup", "optimise draw calls".
metadata:
  version: 1.0.0
  origin: omega (new; complements ecc:blender-motion-state-inspection, which only inspects motion state)
---

# 3D & Real-time Pipeline

Only run tools that are installed. Check first (`blender --version`,
Unity/Unreal project files, `node` + `three` in package.json). If an engine is
missing, produce scripts and settings the user can run locally and label them
unexecuted.

## 1. Target and budget

Pick the target before modelling: offline render (Blender Cycles/EEVEE),
real-time desktop/console (Unreal, Unity HDRP/URP), mobile/XR (Unity URP), or
web (three.js/R3F). Set budgets: triangles per hero asset, texture resolution,
draw calls, frame time (16.6 ms at 60 fps, 11.1 ms at 90 fps XR), output
resolution and samples for renders.

## 2. Scene

- Real-world scale (1 unit = 1 m), Y-up for engines / Z-up in Blender, apply
  transforms before export.
- Naming: `GEO_`, `MAT_`, `LGT_`, `CAM_`, `RIG_` prefixes; one collection/prefab per asset.
- Blender automation: write `bpy` scripts and run them headless
  (`blender -b file.blend -P script.py`) so changes are reproducible.

## 3. Materials

PBR metal/rough workflow. Base colour in sRGB; roughness, metallic, normal, AO
in linear (non-colour). Pack ORM maps for engines. Keep texel density consistent.

## 4. Lighting and camera

- Three-point or HDRI + key for product shots; physically plausible intensities.
- Real-time: bake static lighting, limit dynamic shadow-casting lights, use
  reflection probes.
- Cameras: focal length by intent (24–35 mm environment, 50 mm neutral, 85–135 mm
  product/portrait); depth of field only where it guides the eye. Shot planning
  comes from `omega:omega-storyboard-cinematics`.

## 5. Animation

Keyframe on 1s for hero motion, bake simulations before export, NLA/animation
clips named by action. UI-adjacent motion should match `ecc:motion-foundations` easing.

## 6. Interchange

glTF 2.0 / GLB for web and most engines (Draco or Meshopt compression), FBX for
Unity/Unreal when rigs need it, USD for pipelines that require it. Verify after
export by re-importing and checking scale, normals, materials and clip names.

## 7. Performance and verification

- Engines: profile (Unity Profiler / Unreal `stat unit`, `stat gpu`); fix the
  largest cost first (overdraw, shadow cascades, draw calls → instancing/batching, LODs).
- Web: `renderer.info` for calls and triangles, cap pixel ratio at 2, dispose
  geometries/textures, lazy-load models.
- Renders: check noise, fireflies and colour management (Filmic/AgX vs Standard).
- Inspect motion state in Blender with `ecc:blender-motion-state-inspection`.
- Compare render or viewport screenshots against a baseline with
  `omega:omega-visual-qa`.
