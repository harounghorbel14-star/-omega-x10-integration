---
name: omega-character-world-design
description: Designs original characters, interactive environments and gameplay systems — character sheets, silhouettes and expression sets, world and level layouts, core loops, mechanics, progression and balancing tables — ready for art, animation or engine implementation. Use for "design a character / mascot", "game concept", "level design", "core gameplay loop", "world building", "balance these stats".
metadata:
  version: 1.0.0
  origin: omega (new)
---

# Character, World & Gameplay Design

Everything produced here must be original. Do not reproduce existing
copyrighted characters, mascots or franchise settings, and do not create
"look-alikes" by swapping colours on a known design.

## 1. Pillars

Three design pillars (e.g. "fragile but fast", "readable at a glance",
"cosy dread") plus audience, platform and session length. Every later choice is
checked against the pillars.

## 2. Characters

Character sheet per character:
- Role, want/need, one-line personality, voice sample (2 lines).
- **Silhouette test**: recognisable as a solid black shape; distinct from every
  other character in the cast.
- Shape language (round = friendly, square = sturdy, triangle = dynamic/threat),
  palette (3 main colours + accent, values distinct in greyscale), proportions
  in heads.
- Turnaround (front, ¾, side, back), expression set (6–8), key poses.
- Animation notes: idle, locomotion, signature action; anticipation and follow-through.
- Hand-off: visuals through `omega:omega-image-studio`; 3D through
  `omega:omega-3d-realtime-pipeline`.

## 3. World and levels

- World bible: history in five bullets, factions, rules of the world, biomes.
- Level brief per level: goal, new mechanic introduced, critical path, optional
  paths, landmarks for orientation, sight lines, pacing graph (tension over time).
- Teach mechanics safe → combined → under pressure.

## 4. Systems

- Core loop (seconds), session loop (minutes), meta loop (days) as diagrams.
- Mechanics spec: inputs, rules, feedback (visual, audio, haptic), failure states.
- Progression and economy tables (CSV): sources, sinks, costs, rewards per level.
- Balance: compute time-to-kill, DPS, gold/hour etc. with a script, not by eye;
  flag dominant strategies.

## 5. Verify

- Playtest plan: 3–5 questions per build, success metrics, what would change the design.
- Accessibility: remappable controls, colour-blind-safe cues, subtitle defaults,
  difficulty options.
- Engine-specific build work goes through the matching engine skills or tools
  available in the session; report what is designed vs implemented.
