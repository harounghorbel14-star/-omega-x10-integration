---
name: omega-image-studio
description: End-to-end workflow for still visuals — posters, illustrations, icons and icon sets, social graphics, brand assets and product mockups — from brief to exported, validated files. Chooses between code-drawn output (SVG/HTML/canvas), connected design tools, and image-generation tools that actually exist in the session. Use for "make a poster", "icon set", "product mockup", "hero image", "social banner", "export assets in all sizes".
metadata:
  version: 1.0.0
  origin: omega (new; routes to ecc:fal-ai-media, ecc:ios-icon-gen, ecc:design-system and connected design tools)
---

# Image Studio

## 1. Brief

Purpose, placement and exact output sizes (list every size up front: e.g.
1080×1350 feed, 1080×1920 story, 1200×630 OG, 1024 app icon), brand tokens,
copy, deadline for revisions. Ask only if a size or the copy is unknown and the
cost of guessing is high.

## 2. Pick the production path (by what exists in this session)

1. **Code-drawn** (always available): SVG for icons, logos, diagrams and flat
   illustration; HTML/CSS for posters and mockups with real typography, rendered
   to PNG with a headless browser if one is installed. Deterministic and editable.
2. **Connected design tool** (Figma, Canva, Adobe Express …) when the user works
   there or needs an editable design file. Use the connector's own workflow.
3. **Generative image model** (`ecc:fal-ai-media` or another available
   image tool) for photographic or painterly imagery. Write prompts with subject,
   composition, lens/angle, lighting, palette, style, and negative constraints.
4. **Icons for Apple platforms**: `ecc:ios-icon-gen`.

If none of 2–3 is available, say so and deliver path 1 plus ready-to-run prompts.

## 3. Compose

- Grid and hierarchy first: one focal point, then headline, then support.
- Type: at most two families; headline ≥ 2× body; check line length.
- Colour: pull from the design system (`ecc:design-system`); check text contrast
  ≥ 4.5:1 (3:1 for ≥ 24 px) — `references/replica/replica-design/contrast.py`
  computes WCAG ratios.
- Mockups: original device frames or generic shapes; no third-party trademarks,
  logos or copyrighted characters unless the user owns them.

## 4. Export

- Master in vector or high-res; derive every listed size from the master.
- Formats: SVG for flat art, PNG for UI/transparent, WebP/AVIF for web photos,
  JPEG only for photos without transparency. Strip metadata unless needed.
- Name files `<asset>-<w>x<h>.<ext>`.

## 5. Validate

Run `omega:omega-visual-qa` asset checks against the size list
(`asset_check.py --spec`), view each exported image, and confirm contrast.
Report which files exist, their sizes, and anything not produced.
