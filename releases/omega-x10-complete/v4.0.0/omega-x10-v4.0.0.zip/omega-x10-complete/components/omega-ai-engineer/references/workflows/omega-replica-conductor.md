---
name: omega-replica-conductor
description: Runs the eleven original Replica skills as one tracked pipeline. Adds stage dependency checks, on-disk checkpoints, a missing-feature report from features.csv, a bug gate before diff, regression re-checks, and a deploy preflight that requires explicit approval. Use when rebuilding an app end to end with Replica, resuming a half-finished Replica project, or asking "what stage am I on / what is missing".
metadata:
  version: 1.0.0
  origin: omega (new; wraps replica:* without modifying it)
  requires: python3 >= 3.8 (stdlib only)
---

# OMEGA Replica Conductor

Replica's skills each read what the previous one wrote under `replica/` in the
user's project. This conductor does not replace any of them. It checks that
each stage's inputs exist before you start it, records checkpoints, and refuses
to call a stage done until its artifacts are on disk.

Original stage skills live in `references/replica/replica-*/replica-*.md`. Load the
current stage's file and follow it exactly; use this skill between stages.

## Stage contract

| # | stage | needs (under `replica/`) | must produce |
| --- | --- | --- | --- |
| 1 | recon | — | `recon.md`, `features.csv` |
| 2 | architect | `recon.md`, `features.csv` | `architecture.md` |
| 3 | design | `recon.md` | `design/tokens.json`, `design/components.md` |
| 4 | build | `architecture.md`, `features.csv`, `design/tokens.json` | `build-log.md` |
| 5 | backend | `architecture.md` | `backend.md` |
| 6 | test | `recon.md` | `test-plan.md`, `bugs.md` |
| 7 | diff | `features.csv`, `bugs.md` | `parity.md` |
| 8 | entrepreneur | `features.csv` | `feedback.md`, `fixes.md` |
| 9 | brand | `fixes.md` | `brand.json`, `brand.md` |
| 10 | launch | `brand.json`, `brand.md`, `fixes.md` | `launch/landing.md` |
| 11 | deploy | `launch/landing.md`, `parity.md` | `deploy.md` |

Gates enforced by the script:

- **Bug gate (before diff and deploy):** no bug in `bugs.md` with severity S1
  or S2 and status `open` (Replica's own bug template fields).
- **Deploy preflight:** `deploy` can only be started with `--approve-deploy`,
  which records that the user approved it in chat. The conductor never deploys
  anything itself; `replica:replica-deploy` and its `preflight.md` do the work.

## Commands

Run from the user's project root (the folder that contains or will contain `replica/`):

```bash
S=<package>/skills/omega-replica-conductor/scripts/replica_conductor.py
python3 $S init                      # creates replica/.omega-state.json
python3 $S status                    # every stage: done / ready / blocked, and why
python3 $S start design              # refuses if inputs are missing
python3 $S done design               # refuses if outputs are missing; stores hashes
python3 $S check                     # re-verify all done stages (regression check)
python3 $S missing                   # must/should features where clone != yes
python3 $S start deploy --approve-deploy
```

Add `--json` to `status`, `check` or `missing` for machine output. Exit code is
non-zero when a check fails, so it can sit in CI.

`check` re-hashes every artifact recorded at `done`. A changed artifact is
reported as `changed` (not failed): earlier stages were revised, so re-run the
stages that depend on it. A deleted artifact is a failure.

## Workflow

1. `init`, then `status`.
2. For the next `ready` stage: `start <stage>`, load
   `references/replica/replica-<stage>/replica-<stage>.md`, do the stage, run that stage's own
   tool if it has one (`contrast.py`, `parity.py`, `imgdiff.py`, `reviews.py`,
   `sweep.py`, `listing.py`), then `done <stage>`.
3. After build or backend changes, run `missing` and `check`.
4. Before deploy: bug gate clean, `parity.md` present, user approval recorded.
5. Keep the distinct-brand rule from Replica: run `replica-brand/sweep.py` so the
   original product's name and assets are gone before launch.
