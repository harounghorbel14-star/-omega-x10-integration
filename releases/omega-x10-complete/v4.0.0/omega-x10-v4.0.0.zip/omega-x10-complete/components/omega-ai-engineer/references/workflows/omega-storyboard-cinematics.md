---
name: omega-storyboard-cinematics
description: Plans motion and video work before anything is rendered — creative brief, beat sheet, storyboard frames, shot list with camera, timing, transitions, audio cues and captions — then hands each shot to the right renderer (Remotion, Manim, CSS/motion, Blender, an editor). Use for trailers, product videos, explainer animations, title sequences, cinematic UI transitions, or when the user says "storyboard", "shot list", "animatic", "plan this video".
metadata:
  version: 1.0.0
  origin: omega (new; fills the pre-production gap before ecc:remotion-video-creation, ecc:manim-video, ecc:video-editing and the ecc motion-* skills)
---

# Storyboard & Cinematics

Pre-production for anything that moves. The output is a plan precise enough
that a renderer skill can execute it shot by shot without guessing.

## 1. Brief (5 lines, confirm before going further on long pieces)

Goal and audience · runtime and aspect ratio(s) · platform (web, 9:16 social,
16:9 YouTube, in-app) · tone in three words · hard constraints (brand tokens,
captions required, no voice-over, max file size).

## 2. Beat sheet

Split the runtime into beats: hook (≤ 3 s on social), setup, development, peak,
resolution, call to action. Give each beat a time range and one sentence of
intent. Total must equal the runtime.

## 3. Shot list (the contract)

Write `storyboard/shots.csv` with these columns:

`id,beat,start,end,duration,shot,camera,motion,subject,on_screen_text,audio,transition_in,renderer,notes`

- `shot`: wide / medium / close / insert / screen-capture / title card
- `camera`: static, push-in, pull-out, pan, orbit, rack focus, handheld
- `motion`: easing and spring choices; reuse tokens from `ecc:motion-foundations`
  when the target is UI
- `renderer`: `remotion` · `manim` · `motion-react` · `css` · `blender` ·
  `editor` (cut existing footage) · `live-action`
- Durations must sum to the runtime; `start` of each shot = `end` of the last.

## 4. Storyboard frames

One frame per shot: composition (rule of thirds / centred), focal point, key
colours, text placement inside title-safe area (90 % width), and the first and
last pose so transitions are designable. If an image tool is available in the
session, render thumbnails; otherwise draw them as SVG or describe them
precisely. Never claim a frame was rendered when it was described.

## 5. Sound and captions

Mark music hits and SFX against shot boundaries (cut on the beat where possible).
Captions: ≤ 42 characters per line, ≤ 2 lines, ≥ 1 s on screen, burned in for
social, sidecar `.srt`/`.vtt` otherwise.

## 6. Hand-off

Group shots by `renderer` and route:

| renderer | skill |
| --- | --- |
| remotion | `ecc:remotion-video-creation` |
| manim | `ecc:manim-video` |
| motion-react / css | `ecc:motion-patterns`, `ecc:motion-advanced` |
| blender | `omega:omega-3d-realtime-pipeline` |
| editor | `ecc:video-editing`, `ecc:videodb` |
| polish / taste pass | `ecc:tasteforge-video` |

## 7. Verify

- Timing: recompute total from `shots.csv`; fix gaps or overlaps.
- Render a low-res animatic or key frames when tools allow; check text is legible
  at the smallest target size and inside safe areas.
- Accessibility: no flashes faster than 3 per second; respect reduced motion in UI.
- Report what was rendered vs what remains a plan.
