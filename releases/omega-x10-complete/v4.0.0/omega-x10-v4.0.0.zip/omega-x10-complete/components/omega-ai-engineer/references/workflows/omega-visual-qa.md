---
name: omega-visual-qa
description: Visual regression and asset validation for UI, design and creative output. Batch-compares a folder of baseline screenshots or renders against a current folder (reusing Replica's imgdiff engine), flags new, missing and changed images, writes diff images, and validates exported assets against a size/format/byte-budget spec. Use for "visual regression", "did the UI change", "compare screenshots", "check my exported assets", "are all icon sizes there".
metadata:
  version: 1.0.0
  origin: omega (new; batch wrapper over references/replica/replica-diff/imgdiff.py, which is used unmodified)
  requires: python3 >= 3.8 (stdlib only)
---

# Visual QA

Two stdlib scripts. Neither modifies the images it reads.

## Screenshot / render regression

```bash
python3 skills/omega-visual-qa/scripts/batch_regression.py baseline/ current/ \
    --mode pixel --fail-under 99 --diff-dir qa-diffs/ [--json]
```

- Pairs PNGs by relative path. Reports `new` (only in current), `missing`
  (only in baseline), and a score per pair.
- `--mode pixel` (default) for your own regressions; `--mode layout` when
  colours changed on purpose (rebrand) and only structure should match — this
  is Replica's parity mode.
- Exit 1 when any pair scores under `--fail-under` or a baseline image is missing.
- Uses `references/replica/replica-diff/imgdiff.py` for decoding and scoring, so
  its rules apply: PNG only, non-interlaced; images compared at a shared width.

Capture screenshots with whatever the session has (Playwright via
`ecc:e2e-testing`, `ecc:browser-qa`, an engine's screenshot command). Keep
viewport, device scale, fonts and animation state fixed between runs or scores
are noise; disable animations or wait for idle before capturing.

## Asset validation

```bash
python3 skills/omega-visual-qa/scripts/asset_check.py assets/ --spec assets.spec.json [--json]
```

Spec format:

```json
{
  "assets": [
    {"path": "icon-1024x1024.png", "width": 1024, "height": 1024, "format": "png", "max_bytes": 1048576},
    {"path": "og-1200x630.png", "width": 1200, "height": 630},
    {"glob": "social/*.webp", "format": "webp", "max_bytes": 512000, "min_count": 3}
  ]
}
```

Reads dimensions from file headers for PNG, JPEG, GIF, WebP and SVG
(`width`/`height` or `viewBox`). Reports every rule as pass/fail with the actual
values. Exit 1 on any failure.

## Done means

All pairs at or above threshold (or each difference explained and the baseline
updated on purpose), no missing baselines, asset spec passing. Attach the
script output as evidence.
