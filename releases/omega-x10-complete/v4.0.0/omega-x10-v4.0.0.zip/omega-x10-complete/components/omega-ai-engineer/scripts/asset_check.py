#!/usr/bin/env python3
"""Validate exported image assets against a JSON spec. Standard library only.

    python3 asset_check.py assets/ --spec assets.spec.json [--json]

Each spec rule has "path" (one file) or "glob" (pattern, optional "min_count"),
and any of: width, height, format (png|jpeg|gif|webp|svg), max_bytes.
"""

import argparse
import glob
import json
import os
import re
import struct
import sys


def sniff(path):
    """Return (format, width, height); width/height None if unknown."""
    with open(path, "rb") as fh:
        head = fh.read(64)
        if head.startswith(b"\x89PNG\r\n\x1a\n") and head[12:16] == b"IHDR":
            w, h = struct.unpack(">II", head[16:24])
            return "png", w, h
        if head[:6] in (b"GIF87a", b"GIF89a"):
            w, h = struct.unpack("<HH", head[6:10])
            return "gif", w, h
        if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
            chunk = head[12:16]
            if chunk == b"VP8X":
                w = 1 + int.from_bytes(head[24:27], "little")
                h = 1 + int.from_bytes(head[27:30], "little")
                return "webp", w, h
            if chunk == b"VP8 ":
                w, h = struct.unpack("<HH", head[26:30])
                return "webp", w & 0x3FFF, h & 0x3FFF
            if chunk == b"VP8L":
                b = head[21:25]
                bits = int.from_bytes(b, "little")
                return "webp", (bits & 0x3FFF) + 1, ((bits >> 14) & 0x3FFF) + 1
            return "webp", None, None
        if head[:2] == b"\xff\xd8":
            fh.seek(2)
            while True:
                marker = fh.read(2)
                if len(marker) < 2 or marker[0] != 0xFF:
                    return "jpeg", None, None
                code = marker[1]
                if code in (0xD8, 0x01) or 0xD0 <= code <= 0xD7:
                    continue
                seglen = struct.unpack(">H", fh.read(2))[0]
                if code in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                            0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                    fh.read(1)
                    h, w = struct.unpack(">HH", fh.read(4))
                    return "jpeg", w, h
                fh.seek(seglen - 2, 1)
    if path.lower().endswith(".svg"):
        text = open(path, encoding="utf-8", errors="replace").read(4096)
        tag = re.search(r"<svg\b[^>]*>", text, re.S)
        if not tag:
            return "svg", None, None
        attrs = tag.group(0)

        def num(name):
            m = re.search(r'\b%s\s*=\s*["\']\s*([0-9.]+)\s*(px)?\s*["\']' % name, attrs)
            return float(m.group(1)) if m else None
        w, h = num("width"), num("height")
        if w is None or h is None:
            vb = re.search(r'viewBox\s*=\s*["\']\s*[-0-9.]+[\s,]+[-0-9.]+[\s,]+([0-9.]+)[\s,]+([0-9.]+)', attrs)
            if vb:
                w, h = float(vb.group(1)), float(vb.group(2))
        to_int = lambda v: int(v) if v is not None and float(v).is_integer() else v
        return "svg", to_int(w), to_int(h)
    return "unknown", None, None


def check_file(path, rule):
    fails, info = [], {}
    size = os.path.getsize(path)
    fmt, w, h = sniff(path)
    info.update(format=fmt, width=w, height=h, bytes=size)
    want_fmt = rule.get("format", "").lower().replace("jpg", "jpeg")
    if want_fmt and fmt != want_fmt:
        fails.append(f"format {fmt} != {want_fmt}")
    if "width" in rule and w != rule["width"]:
        fails.append(f"width {w} != {rule['width']}")
    if "height" in rule and h != rule["height"]:
        fails.append(f"height {h} != {rule['height']}")
    if "max_bytes" in rule and size > rule["max_bytes"]:
        fails.append(f"{size} bytes > {rule['max_bytes']}")
    return fails, info


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("root")
    ap.add_argument("--spec", required=True)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    with open(args.spec, encoding="utf-8") as fh:
        spec = json.load(fh)
    results = []
    for rule in spec.get("assets", []):
        if "path" in rule:
            p = os.path.join(args.root, rule["path"])
            if not os.path.isfile(p):
                results.append({"rule": rule["path"], "ok": False, "problems": ["missing"]})
                continue
            fails, info = check_file(p, rule)
            results.append({"rule": rule["path"], "ok": not fails, "problems": fails, **info})
        elif "glob" in rule:
            matches = sorted(glob.glob(os.path.join(args.root, rule["glob"])))
            need = rule.get("min_count", 1)
            if len(matches) < need:
                results.append({"rule": rule["glob"], "ok": False,
                                "problems": [f"{len(matches)} file(s) < min_count {need}"]})
            for p in matches:
                fails, info = check_file(p, rule)
                results.append({"rule": os.path.relpath(p, args.root), "ok": not fails,
                                "problems": fails, **info})
        else:
            results.append({"rule": json.dumps(rule), "ok": False,
                            "problems": ["rule needs 'path' or 'glob'"]})
    ok = all(r["ok"] for r in results)
    if args.json:
        print(json.dumps({"ok": ok, "results": results}, indent=2))
    else:
        for r in results:
            dims = f" {r.get('width')}x{r.get('height')} {r.get('format')} {r.get('bytes')}B" \
                if "format" in r else ""
            print(f"{'PASS' if r['ok'] else 'FAIL'}  {r['rule']}{dims}"
                  + ("" if r["ok"] else "  <- " + "; ".join(r["problems"])))
        print(f"{sum(r['ok'] for r in results)}/{len(results)} passed")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
