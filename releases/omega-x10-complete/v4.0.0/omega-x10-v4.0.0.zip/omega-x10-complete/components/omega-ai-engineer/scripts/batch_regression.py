#!/usr/bin/env python3
"""Batch visual regression over two folders of PNG screenshots/renders.

    python3 batch_regression.py baseline/ current/ [--mode pixel|layout]
        [--fail-under 99] [--diff-dir out/] [--json] [--imgdiff path/to/imgdiff.py]

Scoring and PNG decoding come from Replica's imgdiff.py, loaded unmodified from
sources/replica/replica-diff/imgdiff.py in the OMEGA-SKILLS package (or the path
given with --imgdiff). Standard library only.
"""

import argparse
import importlib.util
import json
import os
import sys


def find_imgdiff(explicit=None):
    if explicit:
        return explicit
    here = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "references",
                        "replica", "replica-diff", "imgdiff.py")
    if os.path.isfile(here):
        return os.path.abspath(here)
    roots = [os.environ.get("OMEGA_SKILLS_ROOT")]
    marker = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "OMEGA_ROOT")
    if os.path.isfile(marker):
        roots.append(open(marker, encoding="utf-8").read().strip())
    for r in roots:
        if r:
            cand = os.path.join(r, "sources", "replica", "replica-diff", "imgdiff.py")
            if os.path.isfile(cand):
                return cand
    cur = os.path.dirname(os.path.abspath(__file__))
    while True:
        cand = os.path.join(cur, "sources", "replica", "replica-diff", "imgdiff.py")
        if os.path.isfile(cand):
            return cand
        parent = os.path.dirname(cur)
        if parent == cur:
            return None
        cur = parent


def load_module(path):
    # Never write __pycache__ into sources/: the originals must stay byte-identical.
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("omega_imgdiff", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def pngs(root):
    out = {}
    for d, _, files in os.walk(root):
        for f in files:
            if f.lower().endswith(".png"):
                full = os.path.join(d, f)
                out[os.path.relpath(full, root).replace(os.sep, "/")] = full
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("baseline")
    ap.add_argument("current")
    ap.add_argument("--mode", choices=("pixel", "layout"), default="pixel")
    ap.add_argument("--fail-under", type=float, default=99.0)
    ap.add_argument("--width", type=int, default=480)
    ap.add_argument("--diff-dir")
    ap.add_argument("--imgdiff")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    for d in (args.baseline, args.current):
        if not os.path.isdir(d):
            print(f"not a folder: {d}", file=sys.stderr)
            return 2
    path = find_imgdiff(args.imgdiff)
    if not path or not os.path.isfile(path):
        print("imgdiff.py not found; pass --imgdiff", file=sys.stderr)
        return 2
    imgdiff = load_module(path)

    base, cur = pngs(args.baseline), pngs(args.current)
    results = []
    for rel in sorted(set(base) | set(cur)):
        if rel not in cur:
            results.append({"image": rel, "status": "missing"})
            continue
        if rel not in base:
            results.append({"image": rel, "status": "new"})
            continue
        try:
            a = imgdiff.read_png(base[rel])
            b = imgdiff.read_png(cur[rel])
            report, diff_rows = imgdiff.compare(a, b, mode=args.mode, width=args.width)
        except Exception as exc:  # decoding problems are reported, not hidden
            results.append({"image": rel, "status": "error", "error": str(exc)})
            continue
        score = report["score"]
        status = "pass" if score >= args.fail_under else "fail"
        entry = {"image": rel, "status": status, "score": score,
                 "verdict": report.get("verdict"),
                 "regions": len(report.get("regions", []))}
        if args.diff_dir and status == "fail" and diff_rows:
            out = os.path.join(args.diff_dir, rel[:-4] + ".diff.png")
            os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
            imgdiff.write_png(out, len(diff_rows[0]), len(diff_rows), diff_rows)
            entry["diff"] = out
        results.append(entry)

    bad = [r for r in results if r["status"] in ("fail", "missing", "error")]
    if args.json:
        print(json.dumps({"ok": not bad, "mode": args.mode, "fail_under": args.fail_under,
                          "results": results}, indent=2))
    else:
        for r in results:
            extra = f" score={r['score']}" if "score" in r else ""
            extra += f" diff={r['diff']}" if "diff" in r else ""
            extra += f" error={r['error']}" if "error" in r else ""
            print(f"{r['status']:<8}{r['image']}{extra}")
        counts = {}
        for r in results:
            counts[r["status"]] = counts.get(r["status"], 0) + 1
        print("summary: " + ", ".join(f"{k}={v}" for k, v in sorted(counts.items())))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
