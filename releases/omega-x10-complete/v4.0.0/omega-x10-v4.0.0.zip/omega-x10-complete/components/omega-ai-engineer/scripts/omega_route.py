#!/usr/bin/env python3
"""Rank OMEGA-SKILLS catalog entries against a task description.

    python3 omega_route.py "rebuild a booking app and deploy it" --top 8
    python3 omega_route.py "remotion product video" --source ecc --json
    python3 omega_route.py "storyboard" --all-variants

Scoring is plain keyword overlap between the task and each skill's name and
description (name hits weigh more). It is a shortlist generator: read the hits'
SKILL.md before choosing. Standard library only.
"""

import argparse
import json
import os
import re
import sys

STOP = set("""a an and are as at be by can for from how i in into is it its me my
of on or our so that the this to use used uses using we what when with you your
skill skills any all build make help""".split())


def find_root(start):
    """Package root: $OMEGA_SKILLS_ROOT, an OMEGA_ROOT file written by
    tools/install.sh next to SKILL.md, or the nearest parent with the catalog."""
    env = os.environ.get("OMEGA_SKILLS_ROOT")
    if env and os.path.isfile(os.path.join(env, "catalog", "skill-catalog.json")):
        return os.path.abspath(env)
    marker = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "OMEGA_ROOT")
    if os.path.isfile(marker):
        cand = open(marker, encoding="utf-8").read().strip()
        if os.path.isfile(os.path.join(cand, "catalog", "skill-catalog.json")):
            return cand
    cur = os.path.abspath(start)
    while True:
        if os.path.isfile(os.path.join(cur, "catalog", "skill-catalog.json")):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            return None
        cur = parent


def tokens(text):
    out = []
    for t in re.findall(r"[a-z0-9]+", (text or "").lower()):
        if t in STOP or len(t) < 2:
            continue
        out.append(t)
        if len(t) > 4 and t.endswith("s"):
            out.append(t[:-1])
    return out


def score(task_tokens, entry):
    name_t = set(tokens(entry["name"].replace("-", " ")))
    desc_t = set(tokens(entry.get("description", "")))
    s = 0.0
    for t in set(task_tokens):
        if t in name_t:
            s += 3.0
        elif any(n.startswith(t) or t.startswith(n) for n in name_t if len(n) > 3 and len(t) > 3):
            s += 1.5
        if t in desc_t:
            s += 1.0
    return s


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("task", help="the task in plain words")
    ap.add_argument("--top", type=int, default=8)
    ap.add_argument("--source", choices=("ecc", "replica", "omega"))
    ap.add_argument("--all-variants", action="store_true",
                    help="include translated / harness-mirror SKILL.md copies")
    ap.add_argument("--root", help="package root (auto-detected)")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    pkg_index = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "references",
                             "skill-index.json")
    if not args.root and os.path.isfile(pkg_index):
        with open(pkg_index, encoding="utf-8") as fh:
            catalog = json.load(fh)
        return rank(args, catalog)
    root = args.root or find_root(os.path.dirname(__file__)) or find_root(os.getcwd())
    if not root:
        print("catalog/skill-catalog.json not found; pass --root", file=sys.stderr)
        return 2
    with open(os.path.join(root, "catalog", "skill-catalog.json"), encoding="utf-8") as fh:
        catalog = json.load(fh)

    return rank(args, catalog)


def rank(args, catalog):
    task_t = tokens(args.task)
    if not task_t:
        print("task has no searchable words", file=sys.stderr)
        return 2
    ranked = []
    for e in catalog["skills"]:
        if not args.all_variants and e["kind"] == "variant":
            continue
        if args.source and e["source"] != args.source:
            continue
        s = score(task_t, e)
        if s > 0:
            ranked.append((s, e))
    ranked.sort(key=lambda x: (-x[0], x[1]["id"]))
    ranked = ranked[: max(args.top, 1)]

    if args.json:
        print(json.dumps([dict(score=s, **{k: e[k] for k in ("id", "path", "description") if k in e})
                          for s, e in ranked], indent=2))
        return 0
    if not ranked:
        print("no match; try other words or read catalog/skill-catalog.md")
        return 1
    for s, e in ranked:
        desc = " ".join(e.get("description", "").split())
        print(f"{s:5.1f}  {e['id']}\n       {e['path']}\n       {desc[:160]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
