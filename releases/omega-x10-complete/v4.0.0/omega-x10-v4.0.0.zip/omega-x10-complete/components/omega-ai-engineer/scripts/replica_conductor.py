#!/usr/bin/env python3
"""Stage tracker for the Replica pipeline. Standard library only.

    python3 replica_conductor.py init
    python3 replica_conductor.py status [--json]
    python3 replica_conductor.py start <stage> [--approve-deploy]
    python3 replica_conductor.py done <stage>
    python3 replica_conductor.py check [--json]
    python3 replica_conductor.py missing [--json]

Works on ./replica/ (override with --dir). State lives in
replica/.omega-state.json. Never deploys or edits project files besides the
state file.
"""

import argparse
import csv
import datetime as _dt
import hashlib
import json
import os
import re
import sys

STAGES = [
    ("recon", [], ["recon.md", "features.csv"]),
    ("architect", ["recon.md", "features.csv"], ["architecture.md"]),
    ("design", ["recon.md"], ["design/tokens.json", "design/components.md"]),
    ("build", ["architecture.md", "features.csv", "design/tokens.json"], ["build-log.md"]),
    ("backend", ["architecture.md"], ["backend.md"]),
    ("test", ["recon.md"], ["test-plan.md", "bugs.md"]),
    ("diff", ["features.csv", "bugs.md"], ["parity.md"]),
    ("entrepreneur", ["features.csv"], ["feedback.md", "fixes.md"]),
    ("brand", ["fixes.md"], ["brand.json", "brand.md"]),
    ("launch", ["brand.json", "brand.md", "fixes.md"], ["launch/landing.md"]),
    ("deploy", ["launch/landing.md", "parity.md"], ["deploy.md"]),
]
STAGE = {name: (needs, makes) for name, needs, makes in STAGES}
BUG_GATED = {"diff", "deploy"}
STATE_FILE = ".omega-state.json"


def now():
    return _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat()


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


class Project:
    def __init__(self, root):
        self.root = os.path.abspath(root)
        self.state_path = os.path.join(self.root, STATE_FILE)

    def p(self, rel):
        return os.path.join(self.root, rel)

    def exists(self, rel):
        path = self.p(rel)
        return os.path.isfile(path) and os.path.getsize(path) > 0

    def load(self):
        if not os.path.isfile(self.state_path):
            raise SystemExit(f"no state at {self.state_path}; run `init` first")
        with open(self.state_path, encoding="utf-8") as fh:
            return json.load(fh)

    def save(self, state):
        tmp = self.state_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(state, fh, indent=2)
            fh.write("\n")
        os.replace(tmp, self.state_path)


# ---------------------------------------------------------------- bug gate
def open_blockers(bugs_path):
    """Bugs with Severity S1/S2 and Status open, per Replica's bug-report.md."""
    if not os.path.isfile(bugs_path):
        return []
    text = open(bugs_path, encoding="utf-8").read()
    blocks = re.split(r"(?m)^(?=#{1,6}\s)", text)
    found = []
    for block in blocks:
        sev = re.search(r"(?im)^\W*severity\W*\s*(S[1-4])\b", block)
        status = re.search(r"(?im)^\W*status\W*\s*([^\n]+)", block)
        if not sev or sev.group(1).upper() not in ("S1", "S2"):
            continue
        if status and not status.group(1).strip().lower().startswith("open"):
            continue
        title = block.strip().splitlines()[0].lstrip("# ").strip() if block.strip() else "?"
        found.append(f"{sev.group(1).upper()}: {title}")
    return found


# ---------------------------------------------------------------- features
def missing_features(features_path):
    rows = []
    with open(features_path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        for raw in reader:
            row = {(k or "").strip().lower(): (v or "").strip() for k, v in raw.items()}
            if not row.get("feature"):
                continue
            prio = row.get("priority", "").lower()
            clone = row.get("clone", "").lower()
            if prio in ("must", "should") and clone not in ("yes", "skip"):
                rows.append({"feature": row["feature"], "area": row.get("area", ""),
                             "priority": prio, "clone": clone or "(blank)"})
    rows.sort(key=lambda r: (r["priority"] != "must", r["area"], r["feature"]))
    return rows


# ---------------------------------------------------------------- views
def stage_view(proj, state):
    out = []
    for name, needs, makes in STAGES:
        rec = state["stages"].get(name, {})
        missing_in = [n for n in needs if not proj.exists(n)]
        if rec.get("status") == "done":
            status, why = "done", ""
        elif missing_in:
            status, why = "blocked", "needs " + ", ".join(missing_in)
        elif rec.get("status") == "started":
            status, why = "started", "missing " + ", ".join(m for m in makes if not proj.exists(m)) \
                if any(not proj.exists(m) for m in makes) else "outputs present; run `done`"
        else:
            status, why = "ready", ""
        if status in ("ready", "started") and name in BUG_GATED:
            blockers = open_blockers(proj.p("bugs.md"))
            if blockers:
                status, why = "blocked", f"{len(blockers)} open S1/S2 bug(s)"
        out.append({"stage": name, "status": status, "detail": why})
    return out


def cmd_init(proj, args):
    os.makedirs(proj.root, exist_ok=True)
    if os.path.isfile(proj.state_path):
        print(f"already initialised: {proj.state_path}")
        return 0
    proj.save({"version": 1, "created": now(), "stages": {}, "log": []})
    print(f"initialised {proj.state_path}")
    return 0


def cmd_status(proj, args):
    view = stage_view(proj, proj.load())
    if args.json:
        print(json.dumps(view, indent=2))
        return 0
    for i, v in enumerate(view, 1):
        print(f"{i:2}. {v['stage']:<13} {v['status']:<8} {v['detail']}")
    nxt = next((v["stage"] for v in view if v["status"] in ("ready", "started")), None)
    print(f"\nnext: {nxt or 'nothing ready'}")
    return 0


def cmd_start(proj, args):
    state = proj.load()
    name = args.stage
    needs, _ = STAGE[name]
    missing_in = [n for n in needs if not proj.exists(n)]
    if missing_in:
        print(f"cannot start {name}: missing " + ", ".join(f"replica/{m}" for m in missing_in))
        return 1
    if name in BUG_GATED:
        blockers = open_blockers(proj.p("bugs.md"))
        if blockers:
            print(f"cannot start {name}: open blocking bugs:\n  " + "\n  ".join(blockers))
            return 1
    if name == "deploy" and not args.approve_deploy:
        print("deploy needs explicit user approval: re-run with --approve-deploy "
              "only after the user approved deployment in chat")
        return 1
    rec = state["stages"].setdefault(name, {})
    rec.update(status="started", started=now())
    if name == "deploy":
        rec["deploy_approved"] = now()
    state["log"].append({"at": now(), "event": "start", "stage": name})
    proj.save(state)
    print(f"started {name}; follow references/replica/replica-{name}/replica-{name}.md")
    return 0


def cmd_done(proj, args):
    state = proj.load()
    name = args.stage
    _, makes = STAGE[name]
    rec = state["stages"].get(name, {})
    if rec.get("status") not in ("started", "done"):
        print(f"{name} was never started; run `start {name}` first")
        return 1
    missing_out = [m for m in makes if not proj.exists(m)]
    if missing_out:
        print(f"{name} is not done: missing " + ", ".join(f"replica/{m}" for m in missing_out))
        return 1
    rec.update(status="done", done=now(), artifacts={m: sha(proj.p(m)) for m in makes})
    state["stages"][name] = rec
    state["log"].append({"at": now(), "event": "done", "stage": name})
    proj.save(state)
    print(f"{name} done: " + ", ".join(makes))
    return 0


def cmd_check(proj, args):
    state = proj.load()
    results, failed = [], False
    for name, _, _ in STAGES:
        rec = state["stages"].get(name, {})
        if rec.get("status") != "done":
            continue
        for rel, digest in rec.get("artifacts", {}).items():
            if not proj.exists(rel):
                results.append({"stage": name, "artifact": rel, "result": "missing"})
                failed = True
            elif sha(proj.p(rel)) != digest:
                results.append({"stage": name, "artifact": rel, "result": "changed"})
            else:
                results.append({"stage": name, "artifact": rel, "result": "ok"})
    if args.json:
        print(json.dumps({"ok": not failed, "results": results}, indent=2))
    else:
        if not results:
            print("no completed stages yet")
        for r in results:
            print(f"{r['result']:<8} {r['stage']:<13} replica/{r['artifact']}")
        changed = sorted({r["stage"] for r in results if r["result"] == "changed"})
        if changed:
            print("\nchanged since done: " + ", ".join(changed) +
                  " — re-run the stages that depend on them")
    return 1 if failed else 0


def cmd_missing(proj, args):
    path = proj.p("features.csv")
    if not os.path.isfile(path):
        print("replica/features.csv not found (run recon first)")
        return 1
    rows = missing_features(path)
    if args.json:
        print(json.dumps(rows, indent=2))
        return 0
    if not rows:
        print("every must/should feature is marked clone=yes or skip")
        return 0
    print(f"{len(rows)} must/should feature(s) not done:")
    for r in rows:
        print(f"  [{r['priority']}] {r['area']}: {r['feature']} (clone={r['clone']})")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--dir", default="replica", help="Replica folder (default ./replica)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init")
    for c in ("status", "check", "missing"):
        sp = sub.add_parser(c)
        sp.add_argument("--json", action="store_true")
    sp = sub.add_parser("start")
    sp.add_argument("stage", choices=list(STAGE))
    sp.add_argument("--approve-deploy", action="store_true")
    sp = sub.add_parser("done")
    sp.add_argument("stage", choices=list(STAGE))
    args = ap.parse_args(argv)
    proj = Project(args.dir)
    return {"init": cmd_init, "status": cmd_status, "start": cmd_start, "done": cmd_done,
            "check": cmd_check, "missing": cmd_missing}[args.cmd](proj, args)


if __name__ == "__main__":
    sys.exit(main())
