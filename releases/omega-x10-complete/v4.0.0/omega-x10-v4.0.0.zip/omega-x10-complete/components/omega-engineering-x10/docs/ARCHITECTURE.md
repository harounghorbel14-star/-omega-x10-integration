# OMEGA X10 v4 — router and orchestration architecture

Everything below runs offline with the Python standard library. Nothing calls a network service unless the
user explicitly configures and consents to the optional external adapter (see `OPTIONAL-MODELS.md`).

```
request text
  │
  ├─ 1. normalisation            omega_lang.normalise / analyse
  ├─ 2. scope analysis           negation, discussion, source material, clauses, anaphora  (omega_lang.analyse)
  ├─ 3. rule layer               English phrase signals (intents.json) + verb–object concept rules (lexicon.json)
  ├─ 4. contextual classifier    omega_classify.py + registry/classifier.json (offline logistic regression)
  ├─ 5. fusion & decision        omega.route: route / multi / clarify / none, with the reason for every override
  ├─ 6. (optional) adapter       omega_adapter.py — OFF unless OMEGA_ADAPTER_CMD and OMEGA_ADAPTER_CONSENT=granted
  ├─ 7. capability planning      per step READY / FALLBACK / LIMITED / BLOCKED from the live session (resolve_intent)
  ├─ 8. ordering & dependencies  request order, time clauses (after/before), hard dependencies (DEPENDS)
  └─ 9. explanation              every layer's decision, evidence, masks, penalties, fusion step, confidence
            │
            └─ execution: omega_workflow.py (validated DAG executor) or omega_orchestrate.py (agent-driven ledger)
```

## 1. Normalisation
Unicode NFKD, combining marks removed, Arabic letter variants unified (ة→ه, ى→ي, hamza forms), Arabic-Indic digits and
punctuation mapped, French/English contractions expanded. Arabizi tokens are also read as consonant skeletons
(7→h, 9→q, 5→x, 3→ʕ, ch/sh→$ …) so spelling variants share one form.

## 2. Scope analysis (what is *not* requested)
* **Imperative negation** masks the rest of its clause: "don't deploy", "ne déploie rien", "ma tdeployich",
  "لا تنشر", "ma ndeployiwech" (1st-person plural), lexical forms ("leave X alone", "sans toucher", "pas besoin de",
  "inutile de") and post-posed forms ("the video mouch lazma", "X not needed").
* **Descriptive negation** is bug evidence, not a mask, when the negated verb describes behaviour or has a subject:
  "images don't load", "les mails n'arrivent plus", "الإشعارات لا تصل", "el site ma tetla3ch".
* **Discussion** masks questions about a tool or concept ("what is X", "how does X work", "is X free?",
  "c'est vraiment utile ?", "هل هذا مجاني؟") unless the same sentence also asks for work.
* **Clauses** are split on conjunctions, sequence markers and punctuation; anaphora ("it", "-ha", "ها") links a step to
  the previous one.

## 3. Rule layer
For each of 23 intents, the stronger of (a) English phrase signals with per-intent negatives and a verb gate, and
(b) language-independent verb–object rules over lexicon concepts. v4 fixes: stricter Arabizi skeleton matching
(clitic-only suffixes; 2-consonant digit stems need the same digit), Latin-word precedence over Arabizi re-reading,
causative "make X faster" (performance, not creation), `V_CODE` (برمجها, codiha, code it), and no prefix over-match
for "hébergeur(s)".

Malformed regexes in the registry never crash routing: they are skipped and reported (`check-routes`, `warnings`).

## 4. Contextual classifier
One-vs-rest logistic regression with 18 intent heads and 3 outcome heads (route / none / clarify). Features of the
*unmasked* text: word unigrams and bigrams, character 3–5-grams, Arabizi skeletons, lexicon concepts, masked-span
markers, and the rule layer's per-intent scores. Weights are produced by `scripts/omega_train.py` from development
data only (`tests/train_classifier.sh`, deterministic: identical bytes on re-run). Per-intent thresholds come from
cross-validation. Inference is pure standard library.

Fallbacks: `OMEGA_CLASSIFIER=off` or `route --rules-only` → rules only (reported as `layers.classifier.used=false`);
missing or corrupt `classifier.json` → rules only with a warning; unusable `lexicon.json` → English rules only and
the classifier is skipped (it was trained with lexicon features).

## 5. Fusion
The classifier decides by default. Every exception is printed under `Fusion:` / `layers.classifier.fusion`:
* **rule-backed**: the classifier says *clarify* but the rule layer has concrete verb–object or malfunction evidence
  that the classifier also supports (p ≥ `rule_backed_min_p`) → route.
* **rule fallback**: the classifier is sure work is requested but no intent reaches its threshold → the rule
  layer's reading.
* **discussion**: rules found only a discussion frame and the classifier hesitated → none.
* **discussion veto**: no intent reached its threshold and the request is a question about a tool → none.

## 6. Optional external adapter
See `OPTIONAL-MODELS.md`. Advisory only, consent-gated, offline fallback on every failure.

## 7. Capability planning
Unchanged from v3: each selected intent resolves to an installed skill, an authorised connector or a built-in
fallback; status READY / FALLBACK / LIMITED / BLOCKED. Connectors that need consent are never selected without
`--authorized`.

## 8. Ordering
Steps follow the order in which they are asked for. Subordinate time clauses are honoured: "deploy it after you fix
the crash" → fix first; "before deploying, run the tests" → tests first. Hard dependencies (e.g. deployment after
implementation/tests) are recorded in `depends_on` and enforced by the executors.

## 9. Execution
* `omega_workflow.py` — validated DAG specs (ids, prerequisites, inputs/outputs, validators, bounded retries,
  timeouts, confirmation gates), argv-only subprocess execution, sha256 ledger, resume after interruption, stale
  artifact recovery. See `WORKFLOWS.md`.
* `omega_orchestrate.py` — the v3 agent-driven ledger (`omega.py run init/next/start/done/fail/report`), kept for
  backward compatibility.

## Release identity
`python3 scripts/omega.py fingerprint` prints the sha256 of the router sources, registries and classifier model
(`router_fingerprint`) and of the workflow engine (`workflow_fingerprint`). The release notes record the fingerprint
that was evaluated on the blind set.
