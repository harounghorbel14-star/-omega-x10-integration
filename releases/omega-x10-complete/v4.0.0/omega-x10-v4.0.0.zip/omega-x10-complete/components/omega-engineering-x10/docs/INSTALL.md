# Install

Requirements: Python ≥ 3.11 (standard library only at run time). numpy + scikit-learn are needed only to retrain
the classifier.

Optional: in the folder where you downloaded the release files, `sha256sum -c OMEGA-X10-V4-SHA256SUMS.txt`.

```bash
unzip omega-x10-v4.0.0.zip -d ~/skills/            # or install the .skill/.zip through your skills UI
cd ~/skills/omega-x10-complete
O=components/omega-engineering-x10/scripts/omega.py
python3 $O doctor --offline                          # package integrity and environment
python3 $O fingerprint                               # compare router_fingerprint with the release notes
python3 $O route "fix the login crash then add tests"
python3 -m unittest discover -s components/omega-engineering-x10/tests   # full offline suite
python3 components/omega-engineering-x10/tests/workflow_gate.py         # multi-step acceptance matrix
```

Upgrading from v3: see `MIGRATION.md` (CLI is backward compatible; new subcommands only).
Do not install over a previous version in place if you need to keep it: unpack to a new directory.
