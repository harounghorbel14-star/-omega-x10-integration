# Intents, labelling rules and how to add an intent

## Intents
23 intents live in `registry/intents.json`. 18 of them are also classifier heads (trained from the corpora):

| id | when |
|---|---|
| implementation | code written or changed: app, API, endpoint, feature, component, script, refactor |
| debugging | something malfunctions (incl. verb-less descriptions: "notifications stopped arriving") |
| tdd | tests written, added or run |
| code-review | code, a PR or a diff reviewed |
| security | audit, vulnerabilities, hardening, leaked secrets |
| ui-ux-design | mockups, wireframes, screens, flows, colours, typography, landing page design |
| web-research | current/external information, comparisons with sources, prices, reviews |
| image | still images: logo, icon, poster, banner, illustration, retouch, background removal |
| video-animation | video, animation, GIF, reel, motion graphics (incl. animating an image) |
| 3d | 3D models, scenes, rendering |
| browser-automation | operating a website: log in, click, fill forms, scrape, export data from a site |
| deployment-release | deploy, release, publish a package, CI/CD, rollback |
| performance | speed, latency, memory, load; "make X faster" |
| planning | plan, roadmap, milestones, spec |
| documents | document, report, CV, spreadsheet, slide deck |
| repository-architecture | explanation/map of the user's codebase, where something is used |
| app-replication | recreate an existing third-party app |
| git-workflow | commits, branches, PRs, merges, rebases |

Rule-only intents (no classifier head; selected by the rule layer and kept by the fusion only when the classifier
has no opinion): requirements-discovery, skill-discovery, skill-authoring, session-memory, agents-orchestration.

Decisions besides routes: **clarify** (genuinely unclear what or on what: "fix it", "make it better") and **none**
(answer directly: questions about tools/concepts, short personal prose).

The full labelling rules used for every corpus are in `tests/corpus/v4/LABELING-GUIDE.md`.

## Adding an intent
1. **Registry** — add an entry to `registry/intents.json` (`id`, `label`, `family`, `phase`, `signals`,
   `negative`, `action_verbs` if it creates a deliverable, `fallback`, capability candidates). Run
   `python3 scripts/omega.py check-routes` (malformed regexes are reported, never fatal).
2. **Multilingual rules** — add concepts and verb–object rules for EN/FR/AR/Arabizi to the lexicon builder and
   regenerate `registry/lexicon.json`; keep generic words (app, code, design…) out of selectors.
3. **Data** — label at least ~150 development prompts across the five language groups with the new id following the
   labelling guide (single, multi-step, negated, discussion and trap cases). Never put validation or blind prompts
   into training files.
4. **Classifier** — add the id to `TRAIN_INTENTS` in `scripts/omega_train.py`, then run
   `tests/train_classifier.sh` (deterministic). Use `tests/cv_route.py` (full-pipeline cross-validation) to compare
   thresholds; record the policy in `train_classifier.sh`.
5. **Tests** — add positive, negative, adversarial and paraphrase cases to `tests/test_v4_regressions.py`, run the
   full suite and `tests/workflow_gate.py`.
6. **Evaluation** — freeze (`omega.py fingerprint`), then evaluate on a *new* blind set written by someone who has
   not seen the rules or labels. A blind set that has been used to make changes is development data afterwards.
