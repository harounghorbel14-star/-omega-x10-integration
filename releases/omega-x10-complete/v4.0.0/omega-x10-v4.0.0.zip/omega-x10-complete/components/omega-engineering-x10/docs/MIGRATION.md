# Migrating from OMEGA X10 v3.0.0 to v4.0.0

## Summary

v4 is a drop-in upgrade. Every v3 command, file and registry entry is still present. No v3 file was removed, and the 23 intents, statuses, connector consent rules, Replica/ECC components and the AI-Engineer catalogue are unchanged. What changes is how a route is decided, plus a new workflow executor.

## Install side by side, then switch

1. Unpack `omega-x10-v4.0.0.zip` into a **new** directory, or install the `.zip`/`.skill` through your skills UI. Do not unpack over v3 if you may need to roll back.
2. Verify the package:

   ```bash
   cd omega-x10-complete
   python3 components/omega-engineering-x10/scripts/omega.py doctor --offline
   python3 components/omega-engineering-x10/scripts/omega.py fingerprint
   ```

   - `doctor` must report `0 fatal failure(s)`.
   - `router_fingerprint` must be `5db7c2547c297d7608f2dcc2f946e578c9fad0e02d812996e127b9dc73f5e64a`, the evaluated build.
3. Disable or remove the v3 copy once you are satisfied. `doctor` warns when duplicate OMEGA skills are installed. It never deletes anything.

**Rollback:** re-enable the v3 directory. v4 writes no state outside the directories you pass to it.

## Requirements

- Python ≥ 3.11 at run time, standard library only. The full suite was run on 3.11, 3.12 and 3.13.
- numpy + scikit-learn are needed **only** to retrain the classifier (`tests/train_classifier.sh`).
- The package grew to about 2.2 MB compressed. The classifier weights (`registry/classifier.json`, about 6 MB uncompressed) and the v4 corpora account for most of it.

## Behaviour changes to know about

| Area | v3 | v4 |
|---|---|---|
| Decision | rule layer only | rule layer + offline contextual classifier, combined by a documented fusion policy |
| `confidence` | derived from the top rule score | derived from the classifier's probabilities (still 0–1 with a label) |
| JSON output | — | new `layers` object: the rule decision, classifier probabilities, evidence and fusion step. All v3 keys are unchanged |
| Negation | imperative negation masked to the clause end | adds descriptive (bug evidence), lexical ("leave … alone"), post-posed ("X mouch lazma") and first-person-plural negation |
| Discussion | "what is / c'est quoi / شنوة" | adds evaluative questions ("is X worth/free?", "هل…؟"); a mask starts at the marker's clause |
| Plan order | git/deploy forced last | the order the user asked for, time clauses honoured ("after you fix…"); hard dependencies still in `depends_on` |
| Accuracy (fresh blind sets) | 50.3% on blind4b | 82.1% on blind4b (n = 872) |

To get v3-like rule-only routing (for example to compare results), use `omega.py route --rules-only "<task>"` or `OMEGA_CLASSIFIER=off`.

## New, opt-in features

- **`omega.py workflow validate|run|status|from-route`**: validated DAG execution with timeouts, bounded retries, output validators, a sha256 ledger, resume and confirmation gates (`docs/WORKFLOWS.md`). `omega.py run …` (the v3 ledger) still works unchanged.
- **`omega.py fingerprint`**: identity of the router and workflow engine. Compare it with the release notes.
- **`OMEGA_CLASSIFIER_MODEL=/path/model.json`**: use another classifier file, for example a retrained one.
- **Optional external adapter** (`OMEGA_ADAPTER_CMD` + `OMEGA_ADAPTER_CONSENT=granted`): off by default, never used without consent, offline fallback on any failure (`docs/OPTIONAL-MODELS.md`).

## If you customised v3

- **Edited `intents.json` or `lexicon.json`**: merge your changes into the v4 files, then **retrain** the classifier. Its rule-score features depend on the rule layer:

  ```bash
  cd components/omega-engineering-x10/tests
  bash train_classifier.sh
  ```

  The new model has a different fingerprint. Evaluate it on data it has never seen before you rely on its accuracy.
- **Added an intent**: follow `docs/INTENTS.md` ("Adding an intent"). The classifier only has heads for the 18 trained intents. Other intents are decided by the rule layer.
- **Scripts that parse `route --json`**: nothing to change. All v3 fields are still present, and `layers` is additive.
