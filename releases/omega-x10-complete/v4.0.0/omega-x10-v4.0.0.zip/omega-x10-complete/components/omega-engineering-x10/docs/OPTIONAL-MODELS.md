# Optional external models (LLM / embeddings) and consent

The bundled router is fully offline: rules + a standard-library classifier whose weights ship in
`registry/classifier.json`. No credentials, network access or paid credits are ever needed.

An external classifier can be plugged in through `scripts/omega_adapter.py`. It is **off by default** and is used
only when the user sets **both**:

| variable | value |
|---|---|
| `OMEGA_ADAPTER_CMD` | a JSON argv list, e.g. `["python3", "/home/me/llm_router.py"]` |
| `OMEGA_ADAPTER_CONSENT` | exactly `granted` — the user agrees that the request text may leave this process (the command may call a paid service) |
| `OMEGA_ADAPTER_TIMEOUT` | optional, seconds (default 8) |

Protocol: the command receives `{"task": "...", "intents": [...]}` on stdin and must print
`{"decision": "route|multi|clarify|none", "intents": [...], "confidence": 0..1}` using only known intent ids.

Behaviour (tested in `tests/test_v4_regressions.py::ExternalAdapter`):
* not configured, or consent missing → not called; `layers.adapter.why` says so;
* failure, timeout, non-zero exit, invalid JSON or unknown intents → ignored with a reason; offline result stands;
* valid answer → advisory: it replaces the offline decision only when the offline classifier is uncertain (its
  strongest outcome probability < 0.6) and the adapter's confidence ≥ 0.7; `layers.adapter.override` records it.

The offline test suite never sets these variables. Do not set them for an agent session without asking the user.
