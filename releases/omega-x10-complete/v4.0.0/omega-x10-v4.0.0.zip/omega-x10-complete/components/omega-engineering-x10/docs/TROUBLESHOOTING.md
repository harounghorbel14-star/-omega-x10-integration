# Troubleshooting

| symptom | cause / fix |
|---|---|
| `warnings: classifier model unusable` | `registry/classifier.json` missing or corrupt. Routing continues with rules only. Restore the file from the package (check `omega.py fingerprint` against the release notes) or retrain with `tests/train_classifier.sh` (needs numpy + scikit-learn). |
| `lexicon.json unusable … multilingual evidence disabled` | the lexicon failed to load; English rules only and the classifier is skipped. Run `omega.py check-routes`. |
| `malformed pattern skipped` | a regex in `intents.json` does not compile; it is ignored. Fix it and run `check-routes`. |
| A clear request gets CLARIFY | very short prompts with a demonstrative ("make this faster") are the classifier's weak spot. The explanation shows both layers; act on the rule layer's reading if it is right, or rephrase with the object. |
| A step is missing from a multi-step plan | the most common residual error class (see the blind results). Check `Strongest alternatives not selected`; add the step yourself. |
| A step is BLOCKED in the plan | the capability is not available in this session (`--session-tools`) or needs consent (`--authorized`). |
| `workflow run` exits 5 | nothing could run: a required capability is missing or a confirmation is needed (`--confirm <step-id>`). |
| `workflow run --resume` refuses | the spec changed since the run started; use a new `--workdir`. |
| A workflow step FAILED with "output … invalid" | the tool exited 0 but the declared output is missing/empty/invalid. This is intentional: exit code 0 alone never completes a step. |
| First route call takes ~1–3 s | the classifier model (~4–5 MB JSON) is parsed once per process; later calls take tens of milliseconds. |
| Need deterministic rules-only behaviour | `OMEGA_CLASSIFIER=off` or `omega.py route --rules-only`. |
