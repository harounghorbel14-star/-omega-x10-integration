# Workflows: validated DAG execution (`omega_workflow.py`)

```bash
W="python3 components/omega-engineering-x10/scripts/omega.py workflow"
$W validate spec.json                                  # structure, ids, prerequisites, cycles, inputs, paths
$W run spec.json --workdir out/run1 --capabilities tool:python,tool:node [--confirm deploy] [--json]
$W run spec.json --workdir out/run1 --resume           # continue an interrupted or partial run
$W status --workdir out/run1
$W from-route "fix the crash then deploy"              # skeleton spec from the router's plan (no commands)
```

Exit codes: `0` COMPLETE, `3` PARTIAL, `4` FAILED, `5` BLOCKED, `2` invalid spec or usage.

## Spec

```json
{
  "name": "fix-and-ship",
  "final_deliverables": ["report.main"],
  "steps": [
    {"id": "fix", "action": "fix the crash", "capability": "tool:python",
     "command": ["{python}", "tools/fix.py", "--out", "{out:patch}"],
     "outputs": {"patch": {"path": "out/fix.patch", "validate": {"min_bytes": 1, "contains": "diff"}}},
     "retry": {"max_attempts": 2}, "timeout_s": 120},
    {"id": "test", "capability": "tool:pytest", "prerequisites": ["fix"], "inputs": {"patch": "fix.patch"},
     "command": ["pytest", "-q", "--junitxml", "{out:junit}"],
     "outputs": {"junit": {"path": "out/junit.xml", "validate": {"contains": "testsuite"}}}},
    {"id": "deploy", "capability": "tool:deploy", "prerequisites": ["test"], "requires_confirmation": "deployment",
     "command": ["./deploy.sh", "staging"], "evidence": {"stdout_contains": "deployed"}},
    {"id": "report", "capability": "tool:python", "prerequisites": ["test"], "inputs": {"j": "test.junit"},
     "command": ["{python}", "tools/report.py", "{in:j}", "{out:main}"],
     "outputs": {"main": {"path": "out/report.md", "validate": {"min_bytes": 20}}}}
  ]
}
```

Rules checked before anything runs (all problems are reported at once): unique ids, known prerequisites, no
self-dependency, **no cycles** (the cycle path is printed), inputs reference declared outputs of *prerequisites*,
output paths relative and inside the workdir, commands are argv lists (never shell strings), retries 1–5,
timeouts in (0, 3600] s, confirmation kind in {destructive, external, financial, publishing, deployment}, and every
step with a command declares outputs or evidence (exit code 0 alone never proves completion).

## Statuses

| step status | meaning |
|---|---|
| PENDING | not planned yet |
| READY | capability available, prerequisites pending or done |
| LIMITED | runs through its `fallback_capability` / `fallback_command` (degraded) |
| BLOCKED | required capability missing, or confirmation not given, or no command (agent step) |
| RUNNING | executing (seen in the ledger while it runs; after a crash it is redone on `--resume`) |
| COMPLETE | exit code 0 **and** every output validated and hashed (or evidence found) |
| FAILED | non-zero exit, timeout, unstartable, invalid/missing output, or integrity failure |
| SKIPPED | a required prerequisite did not complete, or an optional capability is missing |

Workflow status: **COMPLETE** (every required step complete and every final deliverable re-validated),
**PARTIAL** (some required steps complete), **FAILED** (something ran, nothing required completed), **BLOCKED**
(nothing could run).

## Guarantees (tested by `tests/workflow_gate.py`, 57 scenarios)
* A step starts only when all prerequisites are COMPLETE and their artifacts still match their sha256.
* Dependents of a failed/blocked/skipped required step never run; independent branches continue.
* Outputs from an earlier attempt are deleted before each attempt, so stale files cannot pass validation.
* Bounded retries; every attempt is recorded with argv (secrets redacted), exit code, duration, stdout/stderr tails.
* `--resume`: a step left RUNNING is redone; a COMPLETE step whose artifacts changed is re-run with its dependents;
  a changed spec is refused (results would not be traceable).
* Steps marked `requires_confirmation` run only when their id is passed with `--confirm` (or `OMEGA_CONFIRM`).
* The child environment is reduced to PATH/HOME/LANG/TMP-style variables; no shell is ever used.

## Agent-driven ledger (v3, unchanged)
`omega.py run init "<task>"`, `run next`, `run start N`, `run done N --artifact PATH`, `run fail N --reason`,
`run report` — for steps the agent performs itself (e.g. image generation through a connector).
