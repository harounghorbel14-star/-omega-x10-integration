#!/usr/bin/env python3
"""OMEGA-ENGINEERING X10 router and environment doctor.

  omega.py route "<task>" [--json] [--session-tools LIST|@FILE] [--authorized KEYS]
  omega.py run init "<task>" [--state FILE] | next | start N | done N --artifact P | fail N --reason R | report
  omega.py doctor [--json] [--strict] [--offline]
  omega.py list [--plugin NAME] [--topic TOPIC]
  omega.py show <invocation-or-name>
  omega.py check-routes          # registry integrity: intents.json, lexicon.json, routing-rules.json

Routing (v3) combines two evidence layers per intent and keeps the stronger one:
  * English regex signals (registry/intents.json), with negative evidence and a creation-verb gate;
  * language-independent verb-object rules (registry/lexicon.json, scripts/omega_lang.py) for
    English, French, Arabic script, Tunisian Arabizi and code-switched prompts.
Negated spans ("don't deploy", "ma t3amelch", "لا تنشر") and discussion questions ("what is X",
"c'est quoi", "شنوة") never score. Generic words never select a route alone. Multi-intent requests
become ordered steps with dependencies; weak evidence produces a clarification question.
Route status (READY / FALLBACK / LIMITED / BLOCKED) comes from installed skills, the calling session's
tool list (OMEGA_SESSION_TOOLS) and the user's authorisations (OMEGA_AUTHORIZED).

Pure standard library. Reads registry/*.json next to this script.
Exit codes: 0 ok; 1 problems (check-routes, doctor with a fatal failure, or any
failure with --strict); 2 usage.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
import re
import shutil
import subprocess
import sys
from functools import lru_cache
from pathlib import Path

HERE = Path(__file__).resolve().parent
COMPONENT = HERE.parent
REG = COMPONENT / "registry"
# Package root when bundled in omega-x10-complete (components/<name>/scripts), else the component.
PACKAGE = COMPONENT.parent.parent if (COMPONENT.parent.name == "components" and (COMPONENT.parent.parent / "SKILL.md").exists()) else COMPONENT
STOP = set("a an the to of for in on and or with my this that is it be can how do i we you please me use".split())
OMEGA_FAMILY = ("omega-x10-complete", "omega-engineering-x10", "omega-ai-engineer")


def load(name):
    with open(REG / name, encoding="utf-8") as fh:
        return json.load(fh)


def tokens(text):
    return [t for t in re.findall(r"[a-z0-9][a-z0-9+#.-]*", text.lower()) if t not in STOP and len(t) > 1]


CONTRACTIONS = [(r"\b(what|who|where|how|that|it|there)'s\b", r"\1 is"), (r"\b(\w+)n't\b", r"\1 not"),
                (r"\b(we|you|they)'re\b", r"\1 are"), (r"\bi'm\b", "i am"), (r"\b(i|we|you|they)'d\b", r"\1 would")]
DETERMINERS = set("a an the my our your this that these those its their some".split())
BUILD_VERBS = set("build create develop write code make scaffold design add".split())


def _normalise(text):
    return _lang().normalise(text)


def _generic_object(match_text, generic):
    """True when a verb+object match carries no specific object: 'make the app', 'build my site'."""
    words = re.findall(r"[\w'-]+", match_text)
    if len(words) < 2 or words[0] not in BUILD_VERBS:
        return False  # only verb + object phrases; noun phrases like "landing page" are real evidence
    stems = {w.rstrip("s") for w in generic}
    return words[-1].rstrip("s") in stems and all(w in DETERMINERS for w in words[1:-1])


# ------------------------------------------------------------------ installed skills
def _skill_roots():
    env = os.environ.get("OMEGA_SKILL_ROOTS")
    if env:
        return [Path(p).expanduser() for p in env.split(os.pathsep) if p]
    config = Path(os.environ.get("CLAUDE_CONFIG_DIR", Path.home() / ".claude")).expanduser()
    return [config / "skills", config / "plugins", Path("/mnt/skills")]


def _frontmatter_name(path):
    try:
        head = path.read_text(encoding="utf-8", errors="replace")[:2000]
    except OSError:
        return None
    m = re.search(r"^---\s*\n(.*?)\n---", head, re.S)
    if m:
        n = re.search(r"^name:\s*['\"]?([^'\"\n]+)", m.group(1), re.M)
        if n:
            return n.group(1).strip()
    return None


@lru_cache(maxsize=1)
def skill_inventory():
    """Map of installed skill names -> SKILL.md paths. Includes 'plugin:name' aliases."""
    found = {}
    for root in _skill_roots():
        if not root.is_dir():
            continue
        base_depth = len(root.parts)
        for dirpath, dirnames, filenames in os.walk(root):
            if len(Path(dirpath).parts) - base_depth > 6 or "node_modules" in dirpath:
                dirnames[:] = []
                continue
            dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in ("node_modules", "references", "components")]
            if "SKILL.md" not in filenames:
                continue
            p = Path(dirpath) / "SKILL.md"
            names = {Path(dirpath).name}
            fm = _frontmatter_name(p)
            if fm:
                names.add(fm)
            parts = Path(dirpath).parts
            if "skills" in parts:  # <plugin>/skills/<name>/SKILL.md
                i = len(parts) - 1 - parts[::-1].index("skills")
                if i >= 1:
                    names |= {f"{parts[i - 1]}:{n}" for n in list(names)}
            for n in names:
                found.setdefault(n, []).append(str(p))
    return found


def _need_met(need):
    if need.startswith("py:"):
        return importlib.util.find_spec(need[3:]) is not None
    if need.startswith("node:"):
        return any((p / "node_modules" / need[5:]).is_dir() for p in [Path.cwd(), *Path.cwd().parents])
    return shutil.which(need) is not None


def _sibling(name):
    """Modules next to this file are loaded by path (so `python3 -I` works), keyed by path so that two
    router generations evaluated in one process never share a language or classifier module."""
    key = f"{name}@{HERE}"
    mod = sys.modules.get(key)
    if mod is None:
        path = HERE / f"{name}.py"
        if not path.exists():
            raise ImportError(f"{path} missing")
        spec = importlib.util.spec_from_file_location(key, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[key] = mod
        spec.loader.exec_module(mod)
    return mod


def _lang():
    return _sibling("omega_lang")


# ------------------------------------------------------------------ session capabilities
def session_tools():
    """Tool names present in the calling session (OMEGA_SESSION_TOOLS: comma list or @file)."""
    raw = os.environ.get("OMEGA_SESSION_TOOLS", "")
    if raw.startswith("@"):
        try:
            raw = Path(raw[1:]).read_text(encoding="utf-8").replace("\n", ",")
        except OSError:
            raw = ""
    return [t.strip() for t in raw.split(",") if t.strip()]


def authorized():
    """Tool keys the user has authorised for this task (OMEGA_AUTHORIZED, e.g. 'canva,adobe')."""
    return {t.strip().lower() for t in os.environ.get("OMEGA_AUTHORIZED", "").split(",") if t.strip()}


def _tool_state(spec, inventory, tools, auth, key):
    """(present, usable, how) for a tool spec from lexicon.json 'tools' or an intent candidate."""
    if spec.get("session"):
        present = any(t.startswith(spec["session"]) for t in tools)
        if present:
            ok = (not spec.get("consent", False)) or key in auth
            return True, ok, f"session tool {spec['session']}*" + ("" if ok else " (present, needs user consent)")
    if spec.get("skill"):
        if spec["skill"] in inventory:
            return True, True, f"skill {spec['skill']}"
    if spec.get("cmd") and shutil.which(spec["cmd"]):
        return True, True, f"command {spec['cmd']}"
    if spec.get("py") and importlib.util.find_spec(spec["py"]) is not None:
        return True, True, f"python module {spec['py']}"
    if spec.get("node") and _need_met("node:" + spec["node"]):
        return True, True, f"node module {spec['node']}"
    return False, False, "not available in this session"


def resolve_intent(it, text, inventory=None, requested=()):
    """Decide how an intent can be served in THIS environment, from real availability. Never claims a tool ran."""
    inventory = skill_inventory() if inventory is None else inventory
    tools, auth = session_tools(), authorized()
    options, use, use_auth = [], None, True
    for c in it.get("candidates", []):
        kind = c["kind"]
        if kind in ("skill", "plugin-skill"):
            avail, ok, how = c["name"] in inventory, c["name"] in inventory, "installed skill"
        elif kind in ("connector", "session-tool"):
            avail, ok, how = _tool_state(c, inventory, tools, auth, c.get("key", c["name"].lower()))
            avail = avail if tools else None  # without a session tool list, availability is unknown
        else:  # bundled guidance, not an executor
            avail, ok, how = None, False, "guidance bundled with this package"
        options.append({**c, "available": avail, "usable": ok, "detail": how})
        if ok and use is None:
            use = (f"skill: {c['name']}" if kind in ("skill", "plugin-skill") else f"{kind}: {c['name']}")
            use_auth = True
    fb = it.get("fallback") or {}
    missing = [n for n in fb.get("needs", []) if not _need_met(n)]
    limits = it.get("limits")
    limit_msg = limits["message"] if limits and _search(limits.get("re", ""), text) else None
    req_notes = []
    for r in requested:
        present, ok, how = _tool_state(r["spec"], inventory, tools, auth, r["tool"])
        if ok:
            use, use_auth = f"requested tool: {r['label']} ({how})", True
        else:
            req_notes.append(f"requested {r['label']} is not usable here ({how}); the fallback would not use it - ask before substituting")
    if use:
        status, how = "READY", use
    elif not missing:
        status, how = "FALLBACK", fb.get("text", "")
    else:
        status, how = "BLOCKED", f"fallback needs missing: {', '.join(missing)}"
    notes = ([limit_msg] if limit_msg else []) + req_notes
    if notes and status == "FALLBACK":
        status = "LIMITED"
    return {"status": status, "use": how, "options": options, "fallback": fb.get("text"), "authorized": use_auth,
            "fallback_missing": missing, "limit": "; ".join(notes) or None}


# ------------------------------------------------------------------ route (v3)
_BAD_PATTERNS = []


@lru_cache(maxsize=4096)
def _rx(pattern):
    """Compiled pattern, or None when the registry holds a malformed one (reported by check-routes)."""
    try:
        return re.compile(pattern)
    except (re.error, TypeError) as exc:
        _BAD_PATTERNS.append(f"{pattern!r}: {exc}")
        return None


def _search(pattern, text):
    rx = _rx(pattern)
    return rx.search(text) if rx else None


def _score_regex(it, ctx, th, generic, keep):
    """Phase-2 English evidence, now skipping matches inside negated/discussion spans."""
    lang = _lang()
    text = ctx["norm"]
    hits, penalties, spans, masked_hits = [], [], [], []
    for sig in sorted(it["signals"], key=lambda s: -s.get("w", 0)):
        m = _search(sig.get("re", ""), text)
        if not m or any(a <= m.start() and m.end() <= b for a, b in spans):
            continue
        if sig["kind"] == "phrase" and _generic_object(m.group(0), generic):
            continue  # verb + generic object only ("make the app") is not evidence
        why = lang.masked(ctx, m.start(), m.end(), keep)
        if why:
            masked_hits.append({"match": m.group(0), "why": why})
            continue
        spans.append(m.span())
        hits.append({"match": m.group(0), "w": sig["w"], "kind": sig["kind"], "pos": m.start(), "layer": "regex"})
    verbs = it.get("action_verbs")
    if verbs:
        for h in list(hits):
            if h["kind"] == "term" and _search("(" + verbs + r")(\s+[\w'-]+){0,3}?\s+" + re.escape(h["match"]) + r"\b", text):
                hits.append({"match": f"direct object: {h['match']}", "w": 1.5, "kind": "object", "pos": h["pos"], "layer": "regex"})
                break
    raw = sum(h["w"] for h in hits)
    gate = None
    if raw and verbs:
        verb_m = _search(verbs, text)
        if not (verb_m and not lang.masked(ctx, verb_m.start(), verb_m.end(), keep)) and \
                not any(lang.creative_verb_present(ctx, h["pos"]) for h in hits):
            raw *= th["verb_gate_factor"]
            gate = f"no creation/editing verb for this deliverable: x{th['verb_gate_factor']}"
    for neg in it.get("negative", []):
        m = _search(neg.get("re", ""), text)
        if m:
            penalties.append({"match": m.group(0), "w": neg["w"], "why": neg["why"]})
    return raw, hits, penalties, gate, masked_hits


def _score_intent(it, ctx, th, generic, concept, keeps):
    keep = it["id"] in keeps
    raw, hits, penalties, gate, masked_hits = _score_regex(it, ctx, th, generic, keep)
    pen = sum(p["w"] for p in penalties)
    regex_score = max(0.0, raw + pen)
    c = concept.get(it["id"])
    concept_score = max(0.0, c["score"] + pen) if c else 0.0
    why = list(hits)
    if c:
        why.append({"match": c["evidence"], "w": c["score"], "kind": "concept", "pos": c["pos"], "layer": "concept", "clause": c["clause"],
                    "concrete": c["score"] >= 4.0 and not c.get("generic_object", True)})
    score = max(regex_score, concept_score)
    win = [h for h in why if (h["layer"] == "concept") == (concept_score > regex_score)] or why
    pos = min((h["pos"] for h in win), default=len(ctx["norm"]))
    clause = c["clause"] if c and concept_score >= regex_score else ctx["clause_of"](next((i for i, (_, s, e) in enumerate(ctx["tokens"]) if s >= pos), 0))
    strong = sum(h["kind"] == "phrase" for h in hits) + (1 if c and c["score"] >= 4.0 else 0)
    return {"id": it["id"], "label": it["label"], "family": it["family"], "phase": it["phase"], "rule": it.get("rule"),
            "score": round(score, 2), "phrase_hits": strong, "why": why, "penalties": penalties, "gate": gate,
            "masked": masked_hits, "pos": pos, "clause": clause,
            "layer": "concept" if concept_score > regex_score else "regex"}


def _catalogue(meaningful, route_rule_ids, limit):
    skills = load("skills.json")
    rules = {r["id"]: r for r in load("routing-rules.json")["routes"]}
    route_skills = set()
    for rid in route_rule_ids:
        r = rules.get(rid)
        if r:
            route_skills |= {r.get("primary")} | {a["skill"] for a in r.get("alternatives", [])}
    docs = [set(tokens(s["name"].replace("-", " ") + " " + s["description"] + " " + " ".join(s["topics"]))) for s in skills]
    df = {}
    for d in docs:
        for w in d:
            df[w] = df.get(w, 0) + 1
    n = len(docs)
    inv = skill_inventory()
    scored = []
    for s, d in zip(skills, docs):
        name_words = set(tokens(s["name"].replace("-", " ")))
        sc = sum((math.log((n + 1) / (df[t] + 1)) + 1) * (2.5 if t in name_words else 1.0) for t in set(meaningful) if t in d)
        if s["invocation"] in route_skills:
            sc += 2.0
        if sc:
            scored.append((round(sc, 1), s))
    scored.sort(key=lambda x: (-x[0], x[1]["invocation"]))
    return [{"score": sc, "invocation": s["invocation"], "plugin": s["plugin"], "description": s["description"][:200],
             "dependencies": s["dependencies"], "installed": s["invocation"] in inv} for sc, s in scored[:limit]]


DEPENDS = {  # step -> intents it consumes when they are in the same plan
    "deployment-release": {"implementation", "debugging", "tdd", "security", "performance", "code-review", "ui-ux-design"},
    "git-workflow": {"implementation", "debugging", "tdd", "code-review"},
    "tdd": {"implementation", "debugging", "ui-ux-design"},
    "code-review": {"implementation"},
}
LAST = ("git-workflow", "deployment-release")


AFTER_MARKERS = re.compile(r"(?<![\w])(after|once|apres|une fois que|ba3d ma|ba3dma|mba3d ma|ba3d matkammel|بعد ما|بعدما|بعد ان|عندما تنتهي من)(?![\w])")
BEFORE_MARKERS = re.compile(r"(?<![\w])(before|prior to|avant de|avant d|avant|9bal ma|qbal ma|9bal|qbal|قبل ما|قبل ان|قبل)(?![\w])")


def _order_key(r, norm):
    """Requested order, with subordinate time clauses put where they belong:
    "deploy it after you fix the crash" -> fix first; "before deploying, run the tests" -> tests first."""
    pos = r["pos"]
    sent_start = max([m.end() for m in re.finditer(r"[.!?;\n]", norm[:pos])], default=0)
    sent_end = next((m.start() + pos for m in re.finditer(r"[.!?;\n]", norm[pos:])), len(norm))
    sentence = norm[sent_start:sent_end]
    rel = pos - sent_start
    for m in AFTER_MARKERS.finditer(sentence):
        lead = sentence[:m.start()].strip(" ,")
        if lead and re.search(r"\w{2,}", lead):  # "X after Y": Y is done first
            return (sent_start, 0 if rel >= m.start() else 1, pos, r["phase"])
    m = BEFORE_MARKERS.search(sentence)
    if m and not sentence[:m.start()].strip(" ,"):  # sentence-initial "before X, Y": X is done last
        cut = sentence.find(",", m.end())
        if cut < 0:  # no comma: the time clause is the first word group after the marker
            nxt = re.search(r"\s\S+\s", sentence[m.end():])
            cut = m.end() + (nxt.end() if nxt else len(sentence))
        return (sent_start, 1 if rel < cut else 0, pos, r["phase"])
    return (sent_start, 0, pos, r["phase"])


def _topo(order):
    """Stable topological order: keep the requested order except where a hard dependency forces a step later."""
    out = []
    pending = list(order)
    while pending:
        for r in pending:
            blockers = DEPENDS.get(r["id"], set())
            if not any(o["id"] in blockers for o in pending if o is not r):
                break
        else:
            r = pending[0]
        pending.remove(r)
        out.append(r)
    return out


def _plan(selected, ctx):
    """Order subtasks by where they are asked for, then enforce hard dependencies; mark explicit links."""
    order = sorted(selected, key=lambda r: _order_key(r, ctx["norm"]))
    # v4: keep the order in which steps are asked for (measured better than forcing git/deploy last);
    # hard dependencies are still recorded in depends_on and enforced by the executor.
    steps = []
    clauses = ctx["clauses"]
    for k, r in enumerate(order):
        deps = set()
        ids_before = [s["id"] for s in steps]
        for prior in ids_before:
            if prior in DEPENDS.get(r["id"], set()):
                deps.add(prior)
        cl = clauses[r["clause"]] if r["clause"] < len(clauses) else None
        linked = bool(cl and (cl["seq_before"] or any(cl["i"] <= a < cl["j"] for a in ctx["anaphora"])))
        if linked and steps and steps[-1]["clause"] != r["clause"]:
            deps.add(steps[-1]["id"])
        steps.append({"id": r["id"], "label": r["label"], "depends_on": sorted(deps, key=ids_before.index),
                      "subtask": cl["text"] if cl else ctx["norm"], "clause": r["clause"], "linked": linked})
    return steps


def _rule_layer(task):
    """Normalisation, negation/discussion scope, rules and concept scoring. Returns everything route() needs."""
    reg = load("intents.json")
    th = reg["thresholds"]
    lang = _lang()
    lex_path = REG / "lexicon.json"
    warnings = []
    try:
        ctx = lang.analyse(task, lex_path)
        keeps = set(ctx["index"].lex.get("discussion_keeps", []))
        concept = lang.evaluate_rules(ctx, keeps)
    except Exception as exc:  # noqa: BLE001 - a broken lexicon must degrade to English-only routing, not crash
        warnings.append(f"lexicon.json unusable ({exc.__class__.__name__}: {exc}); multilingual evidence disabled")
        ctx = lang.analyse(task, None)
        keeps, concept = set(), {}
    generic = set(reg["generic_words"])
    ranking = sorted((_score_intent(it, ctx, th, generic, concept, keeps) for it in reg["intents"]),
                     key=lambda r: (-r["score"], -r["phrase_hits"], r["phase"]))
    return reg, th, lang, ctx, ranking, warnings


def classifier_mode():
    """'on' (default: bundled offline model), or 'off' (rules only). Never a network service."""
    v = os.environ.get("OMEGA_CLASSIFIER", "on").strip().lower()
    return "off" if v in ("0", "off", "false", "no", "rules") else "on"


def _evidence_pos(cl, model, head, ctx, lang):
    """Where the classifier saw this intent: the strongest token of the clause with the most evidence."""
    ev = cl.token_evidence(ctx, model, head, lang)
    if not ev:
        return len(ctx["norm"])
    starts = [s for _, s, _ in ctx["tokens"]]
    by_clause = {}
    for s, sc in ev:
        c = ctx["clause_of"](starts.index(s))
        by_clause.setdefault(c, []).append((s, sc))
    best_c = max(by_clause, key=lambda c: (sum(max(0.0, x) for _, x in by_clause[c]), -c))
    s, sc = max(by_clause[best_c], key=lambda x: (x[1], -x[0]))
    return s


def _classify(reg, th, lang, ctx, ranking, warnings, rule_decision=None):
    """Contextual classifier layer. Returns (decision, selected ids, probabilities, explanation) or None."""
    if classifier_mode() == "off":
        return None
    if any(w.startswith("lexicon.json unusable") for w in warnings):
        warnings.append("classifier layer skipped: it was trained with lexicon features; rules only")
        return None
    try:
        cl = _sibling("omega_classify")
    except ImportError as exc:
        warnings.append(f"classifier layer unavailable ({exc}); rules only")
        return None
    model = cl.load_model()
    if "error" in model:
        warnings.append(f"classifier model unusable ({model['error']}); rules only")
        return None
    scores = {r["id"]: r["score"] for r in ranking}
    feats = cl.features(ctx, scores, lang)
    p = cl.predict(feats, model)
    pol = model["policy"]
    out = {o: p.get("out:" + o, 0.0) for o in cl.OUTCOMES}
    intents = {h: v for h, v in p.items() if not h.startswith("out:")}
    taus = pol.get("tau_i", {})
    chosen = [h for h, v in sorted(intents.items(), key=lambda x: -x[1]) if v >= taus.get(h, pol["tau"])]
    clause_tau = pol.get("clause_tau")
    clause_added = []
    if clause_tau is not None and chosen and len(ctx["clauses"]) > 1:
        # each clause on its own as well: a request in a later clause must not be drowned by the first one
        for k, c in enumerate(ctx["clauses"]):
            if c["j"] - c["i"] < 3:
                continue
            a, b = c["start"], c["end"]
            sub = {"norm": ctx["norm"][a:b], "raw": ctx["norm"][a:b], "clauses": [c], "anaphora": [],
                   "masks": [{**m, "start": max(m["start"], a) - a, "end": min(m["end"], b) - a} for m in ctx["masks"]
                             if m["end"] > a and m["start"] < b],
                   "hits": [h for h in ctx["hits"] if c["i"] <= h.i < c["j"]]}
            pc = cl.predict(cl.features(sub, {r["id"]: r["score"] for r in ranking if r.get("clause") == k}, lang), model)
            for h, v in sorted(pc.items(), key=lambda x: -x[1]):
                if not h.startswith("out:") and h not in chosen and v >= clause_tau and pc["out:route"] >= 0.5:
                    chosen.append(h)
                    clause_added.append(h)
    best_out = max(out, key=out.get)
    rd = rule_decision or {}
    if best_out == "route" or (chosen and intents[chosen[0]] >= pol["tau_override"]):
        if not chosen and rd.get("decision") in ("route", "multi"):
            # the classifier is sure work is requested but unsure which: take the rule layer's verb-object reading
            chosen = [h for h in rd["selected"] if intents.get(h, 0.0) >= pol.get("rule_fallback_min_p", 0.05)]
        if not chosen:
            top = max(intents, key=intents.get) if intents else None
            if top and intents[top] >= pol["tau_low"]:
                chosen = [top]
        decision = ("multi" if len(chosen) > 1 else "route") if chosen else ("clarify" if out["clarify"] >= out["none"] else "none")
    else:
        decision = best_out
        chosen = []
    fusion = None
    theta = pol.get("rule_backed_min_p", 0.1)
    if decision == "clarify" and rd.get("decision") in ("route", "multi"):
        rank_by = {r["id"]: r for r in ranking}
        gen = set(ctx["index"].lex.get("generic_objects", ["G_APP", "N_CODE", "N_GENERIC_DESIGN"])) if ctx.get("index") else set()

        def concrete_obj(h):
            if any(w.get("concrete") for w in rank_by[h]["why"]):
                return True
            c = ctx["clauses"][rank_by[h]["clause"]] if rank_by[h]["clause"] < len(ctx["clauses"]) else None
            objs = {x.concept for x in ctx["hits"] if c and c["i"] <= x.i < c["j"] and x.role == "object" and not x.masked
                    and x.concept not in gen}
            return len(objs) >= 2  # the intent's own cue plus a named thing it applies to ("this endpoint ... faster")
        concrete = {h for h in rd["selected"] if concrete_obj(h)}
        theta_c = pol.get("rule_concrete_min_p", theta)
        # a verb with a named, non-generic object ("make this endpoint faster") is concrete enough with weaker support
        backed = [h for h in rd["selected"] if intents.get(h, 0.0) >= (theta_c if h in concrete else theta)]
        if backed:  # concrete rule evidence (verb-object or a described malfunction) that the classifier also supports
            decision, chosen = ("multi" if len(backed) > 1 else "route"), backed
            fusion = f"rule-backed: rules selected {backed} and the classifier gives them p >= {theta}"
    if decision == "clarify" and rd.get("decision") == "none" and ctx["masks"] and all(m["reason"] == "discussion" for m in ctx["masks"]):
        decision, chosen = "none", []
        fusion = "discussion: a question about a tool or concept, answered directly"
    if decision in ("route", "multi") and rd.get("decision") == "none" and not any(intents[h] >= taus.get(h, pol["tau"]) for h in chosen) \
            and any(m["reason"] == "discussion" for m in ctx["masks"]):
        decision, chosen = "none", []
        fusion = "discussion veto: the request asks about a tool or concept and no intent reached its threshold"
    top_feats = {}
    for h in chosen:
        hidx = model["heads"].index(h)
        contrib = []
        for k, v in feats.items():
            w = next((w for hh, w in (model["weights"].get(k) or []) if hh == hidx), 0.0)
            if w * v > 0:
                contrib.append((round(w * v, 2), k))
        top_feats[h] = [k for _, k in sorted(contrib, reverse=True)[:5]]
    if clause_added and fusion is None:
        fusion = f"clause-level: {clause_added} found in a clause of their own (p >= {clause_tau})"
    return {"decision": decision, "chosen": chosen, "p": {k: round(v, 3) for k, v in p.items()}, "evidence": top_feats, "fusion": fusion,
            "model": model.get("trained_on", {}), "pos": {h: _evidence_pos(cl, model, h, ctx, lang) for h in chosen}}


def route(task, limit=12):
    reg, th, lang, ctx, ranking, warnings = _rule_layer(task)
    keeps = set(ctx["index"].lex.get("discussion_keeps", [])) if ctx.get("index") else set()
    text = ctx["norm"]
    generic = set(reg["generic_words"])
    by_id = {it["id"]: it for it in reg["intents"]}
    top = ranking[0]["score"] if ranking else 0.0
    has_conj = ctx["has_conj"] or bool(re.search(reg["conjunctions"], text))
    ratio = 0.0 if has_conj else th["secondary_ratio"]
    selected = [r for r in ranking if r["score"] >= th["select_min"] and r["score"] >= ratio * top]
    meaningful = [t for i, (t, _, _) in enumerate(ctx["tokens"])
                  if t not in generic and t not in ctx["index"].stop and len(t) > 1]
    ignored = sorted({t for t, _, _ in ctx["tokens"] if t in generic})
    question = None

    if selected:
        decision = "multi" if len(selected) > 1 else "route"
        if len(selected) > 1 and not has_conj and selected[0]["phrase_hits"] == 0 \
                and (selected[0]["score"] - selected[1]["score"]) <= 0.15 * selected[0]["score"]:
            decision = "clarify"
    else:
        weak = [r for r in ranking if r["score"] >= th["clarify_min_signal"]]
        decision = "clarify" if (weak or len(meaningful) <= 2) else "none"
        if decision == "clarify" and ctx["masks"] and all(m["reason"] == "discussion" for m in ctx["masks"]):
            decision = "none"  # a question about a tool or concept: answer it, do not run anything

    rule_decision = {"decision": decision, "selected": [r["id"] for r in selected] if decision in ("route", "multi") else []}
    clf = _classify(reg, th, lang, ctx, ranking, warnings, rule_decision)
    if clf:
        decision = clf["decision"]
        rank_by = {r["id"]: r for r in ranking}
        selected = []
        for h in clf["chosen"]:
            r = dict(rank_by[h])
            if r["score"] <= 0 or r["pos"] >= len(text):
                r["pos"] = clf["pos"][h]
                tok_i = next((i for i, (_, s0, _) in enumerate(ctx["tokens"]) if s0 >= r["pos"]), 0)
                r["clause"] = ctx["clause_of"](tok_i) if ctx["tokens"] else 0
            r["classifier_p"] = clf["p"][h]
            r["classifier_evidence"] = clf["evidence"][h]
            selected.append(r)
        # primary = strongest rule evidence among the chosen intents (the classifier decides the set)
        selected.sort(key=lambda r: (-r["score"], -r["phrase_hits"], r["phase"], -r["classifier_p"]))

    adapter_info = {"used": False, "why": "adapter module missing"}
    try:
        adapter = _sibling("omega_adapter")
        ans, adapter_info = adapter.consult(task, [it["id"] for it in reg["intents"]])
    except ImportError:
        ans = None
    if ans:
        offline_sure = clf is not None and max(clf["p"].get("out:" + o, 0.0) for o in ("route", "none", "clarify")) >= 0.6
        if not offline_sure and float(ans.get("confidence", 0)) >= 0.7:
            rank_by = {r["id"]: r for r in ranking}
            decision = ans["decision"]
            selected = [dict(rank_by[h]) for h in ans.get("intents", []) if h in rank_by] if decision in ("route", "multi") else []
            if decision in ("route", "multi") and not selected:
                decision = "clarify"
            adapter_info["override"] = True
        else:
            adapter_info["override"] = False

    if decision == "clarify":
        cands = (selected or [r for r in ranking if r["score"] >= th["clarify_min_signal"]])[:3]
        if cands:
            question = "Which outcome do you want: " + " / ".join(c["label"] for c in cands) + "? And on which file, app or asset?"
        else:
            question = ("What should I produce: a code change, a bug fix, research with sources, an image/video/3D asset, "
                        "a document/spreadsheet/deck, browser automation, a security review, or a test/deploy step? Which project or file?")
        selected_out = []
    else:
        selected_out = selected

    tools_req = [t for t in ctx["tools"] if not t["masked"]]
    for r in selected_out:
        req = [{**t, "spec": ctx["index"].lex["tools"][t["tool"]]} for t in tools_req if r["id"] in t["intents"]]
        r.update(resolve_intent(by_id[r["id"]], text, requested=req))
    steps = _plan(selected_out, ctx) if selected_out else []
    plan = [s["id"] for s in steps]
    for s in steps:
        r = next(x for x in selected_out if x["id"] == s["id"])
        s["status"], s["use"] = r["status"], r["use"]
    sel_ids = {r["id"] for r in selected_out}
    alternatives = [{"id": r["id"], "score": r["score"], "label": r["label"]} for r in ranking if r["score"] > 0 and r["id"] not in sel_ids][:3]
    if selected_out and clf and all("classifier_p" in r for r in selected_out):
        confidence = round(min(r["classifier_p"] for r in selected_out), 2)  # weakest selected intent
    else:
        confidence = round(top / (top + th["select_min"]), 2) if selected_out else 0.0
    stack = [s for s in reg["stack_hints"] if re.search(r"(?<![\w.])" + re.escape(s) + r"(?![\w])", text)]
    return {
        "task": task, "normalised": text, "languages": ctx["langs"], "decision": decision,
        "primary": selected_out[0]["id"] if selected_out else None,  # strongest evidence; ties: phrase evidence, then phase
        "confidence": confidence,
        "confidence_label": "high" if confidence >= 0.7 else "medium" if confidence >= 0.55 else "low" if confidence else "n/a",
        "selected": selected_out, "plan": plan, "steps": steps, "alternatives": alternatives, "clarify_question": question,
        "layers": {"rules": rule_decision, "classifier": ({k: clf[k] for k in ("decision", "chosen", "p", "evidence", "fusion")} if clf else
                   {"mode": classifier_mode(), "used": False}),
                   "adapter": adapter_info},
        "masks": ctx["masks"], "requested_tools": [{k: v for k, v in t.items() if k != "pos"} for t in ctx["tools"]],
        "warnings": warnings + [f"malformed pattern skipped: {b}" for b in sorted(set(_BAD_PATTERNS))],
        "ignored_generic_words": ignored, "stack": stack,
        "catalogue": _catalogue([t for t in meaningful if re.fullmatch(r"[a-z0-9+#.-]+", t)],
                                [r["rule"] for r in selected_out if r.get("rule")], limit) if selected_out else [],
    }


def explain(res):
    out = [f"Task: {res['task']}", f"Languages: {', '.join(res['languages']) or '?'}   normalised: {res['normalised']}", ""]
    label = {"route": "SINGLE ROUTE", "multi": "MULTI-INTENT", "clarify": "CLARIFY", "none": "NO SPECIALIST ROUTE"}[res["decision"]]
    conf = f" (confidence {res['confidence_label']} {res['confidence']})" if res["selected"] else ""
    out.append(f"Decision: {label}{conf}")
    if res["decision"] == "clarify":
        out.append(f"  Ask: {res['clarify_question']}")
    if res["decision"] == "none":
        out.append("  No intent has enough evidence for execution; answer directly or ask what deliverable is wanted.")
    lay = res.get("layers", {})
    if lay:
        rl, cl_ = lay.get("rules", {}), lay.get("classifier", {})
        out.append(f"  Layers: rules -> {rl.get('decision')} {rl.get('selected', [])}; classifier -> "
                   + (f"{cl_.get('decision')} {cl_.get('chosen', [])}" if "decision" in cl_ else f"not used ({cl_.get('mode')})")
                   + f"; external adapter -> {'used' if lay.get('adapter', {}).get('used') else 'not used'} ({lay.get('adapter', {}).get('why')})")
        if cl_.get("fusion"):
            out.append(f"  Fusion: {cl_['fusion']}")
    for m in res["masks"]:
        out.append(f"  Ignored ({m['reason']}): \"{res['normalised'][m['start']:m['end']]}\"")
    for w in res.get("warnings", []):
        out.append(f"  WARNING: {w}  (run check-routes)")
    if res["steps"]:
        out.append("\nPlan:")
        for k, s in enumerate(res["steps"], 1):
            dep = f" after {', '.join(s['depends_on'])}" if s["depends_on"] else ""
            out.append(f"  {k}. {s['id']:<20} [{s['status']}]{dep}   <- \"{s['subtask']}\"")
    for i, r in enumerate(res["selected"], 1):
        out.append(f"\n{i}. {r['id']}  ({r['label']})  score {r['score']}  status {r['status']}")
        for h in r["why"]:
            out.append(f"     +{h['w']:<4} {h['kind']:<7} \"{h['match']}\"")
        for p in r["penalties"]:
            out.append(f"     {p['w']:<5} penalty \"{p['match']}\" - {p['why']}")
        for mh in r.get("masked", []):
            out.append(f"     ignored ({mh['why']}) \"{mh['match']}\"")
        if r["gate"]:
            out.append(f"     gate: {r['gate']}")
        out.append(f"     use: {r['use']}")
        for o in r["options"]:
            mark = {True: "available", False: "not available", None: "unknown: no session tool list"}[o["available"]]
            if o["available"] and not o.get("usable"):
                mark = "present, needs consent"
            note = f" - {o['note']}" if o.get("note") else ""
            out.append(f"       option: {o['name']} [{mark}]{note}")
        if r["limit"]:
            out.append(f"     limit: {r['limit']}")
    if res["alternatives"]:
        out.append("\nStrongest alternatives not selected: " + ", ".join(f"{a['id']} ({a['score']})" for a in res["alternatives"]))
    if res["requested_tools"]:
        out.append("Tools named in the request: " + ", ".join(f"{t['label']}" + (f" ({t['masked']}, not requested)" if t["masked"] else "") for t in res["requested_tools"]))
    if res["ignored_generic_words"]:
        out.append("Ignored generic words: " + ", ".join(res["ignored_generic_words"]))
    if res["stack"]:
        out.append("Stack context: " + ", ".join(res["stack"]))
    if res["catalogue"]:
        out.append("\nCatalogue matches (registry entries; 'installed' is checked, not assumed):")
        for s in res["catalogue"][:6]:
            out.append(f"  {s['score']:>5}  {s['invocation']}  [{'installed' if s['installed'] else 'not installed'}]")
    return "\n".join(out)


# ------------------------------------------------------------------ integrity
def check_routes():
    skills = {s["invocation"] for s in load("skills.json")}
    rules = load("routing-rules.json")
    caps = load("capabilities.json")
    commands = {f"{c['plugin']}:/{c['name']}" for c in caps["commands"]}
    problems = []
    for r in rules["routes"]:
        names = [r.get("primary")] + [a["skill"] for a in r.get("alternatives", [])] + r.get("pipeline", []) \
            + r.get("cli_skills", []) + [x for x in r.get("always_with", []) if ":" in x]
        for n in names:
            if not n or n.startswith("(search)") or n.startswith("ecc agents"):
                continue
            if n.split(" --")[0] not in skills and n not in commands:
                problems.append(f"route {r['id']}: '{n}' is not a registered skill or command")
    problems += check_intents()
    problems += check_lexicon()
    return problems


SPECIAL_OBJECTS = {"ANAPHORA", "CONTENT", "G_APP+CONTENT", "N_CURRENT+N_RESEARCH"}
ROLES = {"verb", "verb_generic", "object", "object_generic", "marker", "disc"}


def check_lexicon():
    problems = []
    try:
        lex = load("lexicon.json")
    except (OSError, ValueError) as exc:
        return [f"lexicon.json unreadable: {exc}"]
    concepts = lex.get("concepts", {})
    intents = {i["id"] for i in load("intents.json").get("intents", [])}
    for name, c in concepts.items():
        if c.get("role") not in ROLES:
            problems.append(f"lexicon concept {name}: unknown role {c.get('role')!r}")
        for field in ("latin", "arabic", "arabizi"):
            if not isinstance(c.get(field, []), list) or any(not isinstance(e, str) or not e.strip() for e in c.get(field, [])):
                problems.append(f"lexicon concept {name}: '{field}' must be a list of non-empty strings")
    for k, r in enumerate(lex.get("rules", [])):
        tag = f"lexicon rule {k} ({r.get('intent')})"
        if r.get("intent") not in intents:
            problems.append(f"{tag}: intent not in intents.json")
        if not isinstance(r.get("w"), (int, float)):
            problems.append(f"{tag}: weight 'w' missing")
        for v in r.get("verbs") or []:
            if v != "V_IMPLICIT" and v not in concepts:
                problems.append(f"{tag}: unknown verb concept {v!r}")
        for o in r.get("objects") or []:
            if o not in SPECIAL_OBJECTS and o not in concepts:
                problems.append(f"{tag}: unknown object concept {o!r}")
        if r.get("verbs") is None and r.get("objects") is None:
            problems.append(f"{tag}: needs verbs or objects")
    sel = load("intents.json").get("thresholds", {}).get("select_min", 2.5)
    for k, r in enumerate(lex.get("rules", [])):
        objs = r.get("objects") or []
        if r.get("verbs") is None and any(concepts.get(o, {}).get("role") == "object_generic" for o in objs) and r.get("w", 0) >= sel:
            problems.append(f"lexicon rule {k}: a generic object alone would select '{r.get('intent')}'")
    for t, spec in lex.get("tools", {}).items():
        if not set(spec.get("intents", [])) <= intents:
            problems.append(f"lexicon tool {t}: unknown intent in {spec.get('intents')}")
    return problems


def check_intents():
    problems = []
    try:
        reg = load("intents.json")
    except (OSError, ValueError) as exc:
        return [f"intents.json unreadable: {exc}"]
    rule_ids = {r["id"] for r in load("routing-rules.json")["routes"]}
    seen = set()
    for key in ("select_min", "secondary_ratio", "verb_gate_factor", "clarify_min_signal"):
        if not isinstance(reg.get("thresholds", {}).get(key), (int, float)):
            problems.append(f"intents.json: threshold '{key}' missing")
    for it in reg.get("intents", []):
        iid = it.get("id", "?")
        if iid in seen:
            problems.append(f"intent {iid}: duplicate id")
        seen.add(iid)
        for field in ("label", "family", "phase", "signals", "candidates", "fallback"):
            if field not in it:
                problems.append(f"intent {iid}: missing '{field}'")
        if it.get("rule") and it["rule"] not in rule_ids:
            problems.append(f"intent {iid}: rule '{it['rule']}' not in routing-rules.json")
        if not any(s.get("kind") == "phrase" for s in it.get("signals", [])):
            problems.append(f"intent {iid}: needs at least one phrase-level signal")
        for sig in it.get("signals", []) + it.get("negative", []) + ([it["limits"]] if it.get("limits") else []):
            try:
                re.compile(sig["re"])
            except (re.error, KeyError) as exc:
                problems.append(f"intent {iid}: bad regex {sig.get('re')!r}: {exc}")
        for w in reg.get("generic_words", []):
            for sig in it.get("signals", []):
                try:
                    hit = re.fullmatch(sig["re"], w)
                except (re.error, KeyError, TypeError):
                    continue  # already reported above as a bad regex
                if hit and sig.get("w", 0) >= reg.get("thresholds", {}).get("select_min", 0):
                    problems.append(f"intent {iid}: generic word '{w}' can select this route alone via {sig['re']!r}")
        if it.get("action_verbs"):
            try:
                re.compile(it["action_verbs"])
            except re.error as exc:
                problems.append(f"intent {iid}: bad action_verbs regex: {exc}")
    return problems


REF_PREFIXES = ("references/", "scripts/", "registry/", "components/", "sources/", "tests/")


def check_references(root=None):
    """Every backticked package path in a .md file must resolve. Returns (ok_count, missing list)."""
    root = Path(root or PACKAGE)
    # Paths may contain globs (replica-*) or placeholders (replica-<stage>); both become globs.
    pat = re.compile(r"`([A-Za-z0-9_][A-Za-z0-9_./*<>-]*\.(?:py|md|json|csv|ts|sh|txt))`")
    ok, missing = 0, []
    for md in sorted(root.rglob("*.md")):
        if "node_modules" in md.parts:
            continue
        comp = next((md.parents[i] for i in range(len(md.parents) - 1) if md.parents[i].parent.name == "components"), None)
        for ref in pat.findall(md.read_text(encoding="utf-8", errors="replace")):
            if not ref.startswith(REF_PREFIXES):
                continue
            bases = [md.parent, root] + ([comp] if comp else [])
            glob = re.sub(r"<[^>/]+>", "*", ref)
            if "*" in glob:
                found = any(next(iter(b.glob(glob)), None) is not None for b in bases)
            else:
                found = any((b / ref).exists() for b in bases)
            if found:
                ok += 1
            else:
                missing.append(f"{md.relative_to(root)} -> {ref}")
        # Markdown link targets: [text](relative/path) — resolved against the file's own folder.
        for target in re.findall(r"\]\(([^)\s#]+)(?:#[^)]*)?\)", md.read_text(encoding="utf-8", errors="replace")):
            if re.match(r"^[a-z][a-z0-9+.-]*:", target):  # http:, mailto:, computer:
                continue
            if (md.parent / target).exists():
                ok += 1
            else:
                missing.append(f"{md.relative_to(root)} -> ({target})")
    return ok, missing


# ------------------------------------------------------------------ doctor
def _which(cmd):
    return shutil.which(cmd)


def _version(cmd, args=("--version",)):
    try:
        out = subprocess.run([cmd, *args], capture_output=True, text=True, timeout=15)
        return (out.stdout or out.stderr).strip().splitlines()[0][:80] if (out.stdout or out.stderr) else "?"
    except Exception as exc:  # noqa: BLE001 - diagnostic only
        return f"error: {exc.__class__.__name__}"


def doctor(offline=False):
    checks = []

    def add(name, ok, detail, fix, needed_by, severity="optional"):
        checks.append({"check": name, "ok": bool(ok), "detail": detail, "fix": fix, "needed_by": needed_by, "severity": severity})

    # ---- fatal: the skill itself must be intact
    add("python >= 3.8", sys.version_info >= (3, 8), sys.version.split()[0], "Install Python 3.8+", "omega.py", "fatal")
    skill_md = PACKAGE / "SKILL.md"
    fm = _frontmatter_name(skill_md) if skill_md.exists() else None
    add("SKILL.md with name frontmatter", fm, f"{skill_md} (name: {fm})" if fm else f"{skill_md} missing or no name",
        "Restore SKILL.md from the release archive", "skill activation", "fatal")
    probs = check_routes()
    add("registry integrity (check-routes)", not probs, "0 problems" if not probs else f"{len(probs)} problem(s): {probs[0]}",
        "Run `omega.py check-routes` and fix the listed entries", "routing", "fatal")
    nref, missing = check_references()
    add("internal file references", not missing, f"{nref} resolved" if not missing else f"{len(missing)} broken: {missing[0]}",
        "Fix the paths listed by `omega.py doctor --json`", "workflows", "fatal")
    if missing:
        checks[-1]["missing"] = missing
    manifest = PACKAGE / "FILE-SHA256.json"
    if manifest.exists():
        import hashlib
        data = json.loads(manifest.read_text(encoding="utf-8"))
        files = data.get("files", data) if isinstance(data, dict) else {}
        bad = [p for p, h in files.items() if not (PACKAGE / p).exists()
               or hashlib.sha256((PACKAGE / p).read_bytes()).hexdigest() != (h["sha256"] if isinstance(h, dict) else h)]
        add("FILE-SHA256.json matches files", not bad, f"{len(files)} files verified" if not bad else f"{len(bad)} mismatch: {bad[:3]}",
            "Reinstall from the release archive (files were modified after packaging)", "integrity", "fatal")

    # ---- optional tools: missing ones only disable specific routes
    for cmd, fix, by in [
        ("node", "Install Node.js 18+", "3D fallback (gltf-validator), ECC hooks, npx skills"),
        ("npx", "Install Node.js (ships npx)", "find-skills (npx skills), ui-ux-pro-max-cli"),
        ("git", "Install git", "git-workflow route, code-review fallback"),
        ("ffmpeg", "Install ffmpeg (apt install ffmpeg / brew install ffmpeg)", "video-animation fallback"),
        ("agent-browser", "npm i -g agent-browser@0.39.2 && agent-browser install", "agent-browser plugin skill"),
        ("graphify", "uv tool install graphifyy==0.9.94   (or: pipx install graphifyy==0.9.94)", "graphify"),
        ("uv", "https://docs.astral.sh/uv/ (review the installer first)", "graphify (recommended installer)"),
        ("bun", "Installed on demand by claude-mem; or https://bun.sh", "claude-mem worker"),
        ("claude-mem", "Install the claude-mem plugin from its upstream marketplace", "claude-mem hooks"),
        ("gh", "https://cli.github.com", "PR workflows"),
    ]:
        path = _which(cmd)
        add(cmd, path, f"{path} ({_version(cmd)})" if path else "not on PATH", None if path else fix, by)
    pw = importlib.util.find_spec("playwright") is not None
    add("python playwright", pw, "importable" if pw else "not importable",
        None if pw else "pip install playwright && python -m playwright install chromium", "image / video / 3D / browser fallbacks")

    # ---- duplicate installs of the OMEGA family (warn; never delete user files)
    inv = skill_inventory()
    installed = {n: inv[n] for n in OMEGA_FAMILY if n in inv}
    dupes = len(installed) > 1 or any(len(v) > 1 for v in installed.values())
    add("single OMEGA entry point", not dupes,
        "only one OMEGA skill installed" if not dupes else "also installed: " + ", ".join(f"{k} ({len(v)})" for k, v in installed.items()),
        None if not dupes else "Disable or uninstall the standalone omega-engineering-x10 / omega-ai-engineer skills; "
                               "omega-x10-complete bundles both. This tool never deletes them for you.",
        "unambiguous activation", "warn")

    # ---- per-route readiness in this environment
    reg = load("intents.json")
    for it in reg["intents"]:
        r = resolve_intent(it, "", inv)
        add(f"route {it['id']}", r["status"] in ("READY", "FALLBACK"), f"{r['status']}: {r['use']}",
            None if r["status"] in ("READY", "FALLBACK") else f"Install one of: {', '.join(o['name'] for o in r['options'])}",
            it["label"], "info")

    # ---- optional services
    port = host = None
    settings_path = Path(os.environ.get("CLAUDE_MEM_DATA_DIR", Path.home() / ".claude-mem")).expanduser() / "settings.json"
    try:
        settings = json.loads(settings_path.read_text(encoding="utf-8-sig"))
        settings = settings.get("env", settings) if isinstance(settings, dict) else {}
        port, host = settings.get("CLAUDE_MEM_WORKER_PORT"), settings.get("CLAUDE_MEM_WORKER_HOST")
    except (OSError, ValueError):
        pass
    port = os.environ.get("CLAUDE_MEM_WORKER_PORT") or port or str(37700 + ((os.getuid() if hasattr(os, "getuid") else 77) % 100))
    host = os.environ.get("CLAUDE_MEM_WORKER_HOST") or host or "127.0.0.1"
    try:
        import urllib.request
        if not re.fullmatch(r"[A-Za-z0-9.\-]+|\[[0-9a-fA-F:]+\]", str(host)) or not str(port).isdigit():
            raise ValueError("invalid claude-mem host/port setting")
        # scheme fixed to http and host/port validated above
        with urllib.request.urlopen(f"http://{host}:{port}/api/health", timeout=2) as r:  # nosec B310
            add("claude-mem worker", r.status == 200, f"http://{host}:{port}/api/health -> {r.status}", None, "claude-mem:mem-search")
    except Exception as exc:  # noqa: BLE001
        add("claude-mem worker", False, f"not reachable on {host}:{port} ({exc.__class__.__name__})",
            "Start a Claude Code session with the claude-mem plugin enabled", "claude-mem:mem-search")
    gout = Path.cwd() / "graphify-out" / "graph.json"
    add("graphify-out/graph.json in cwd", gout.exists(), str(gout) if gout.exists() else "no graph built here",
        None if gout.exists() else "Run /graphify in this repo to build one", "graphify query/path/explain", "info")
    if not offline:
        ok, detail = _reachable(os.environ.get("SKILLS_API_URL", "https://skills.sh") + "/api/search?q=react")
        add("skills.sh reachable", ok, detail,
            None if ok else "Allow https://skills.sh in your network policy; until then `npx skills find` reports 'No skills found'",
            "find-skills:find-skills")
    for ecc in _installed_ecc_dirs():
        have = (ecc / "node_modules" / "js-yaml").is_dir()
        add(f"ecc runtime deps ({ecc})", have, "node_modules present" if have else "node_modules missing: Cannot find module 'js-yaml'",
            None if have else f"{HERE / 'install-plugin-deps.sh'} {ecc}", "ecc hooks")
    return checks


def _reachable(url):
    import urllib.error
    import urllib.request
    if not url.startswith(("https://", "http://")):
        return False, f"{url}: only http(s) URLs are checked"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, method="GET"), timeout=8) as r:  # nosec B310
            return True, f"{url} -> HTTP {r.status}"
    except urllib.error.HTTPError as exc:  # the host answered, so it is reachable
        return True, f"{url} -> HTTP {exc.code}"
    except Exception as exc:  # noqa: BLE001 - diagnostic only
        return False, f"{url} unreachable ({exc.__class__.__name__}: {str(exc)[:80]})"


def _installed_ecc_dirs():
    found = []
    config = Path(os.environ.get("CLAUDE_CONFIG_DIR", Path.home() / ".claude")).expanduser()
    for manifest in sorted((config / "plugins" / "cache").glob("*/ecc/*/.claude-plugin/plugin.json")):
        found.append(manifest.parent.parent)
    local = COMPONENT.parent / "ecc"
    if (local / ".claude-plugin" / "plugin.json").exists():
        found.append(local)
    return found


# ------------------------------------------------------------------ cli
FINGERPRINT_FILES = ("scripts/omega.py", "scripts/omega_lang.py", "scripts/omega_classify.py", "scripts/omega_adapter.py",
                     "registry/intents.json", "registry/lexicon.json", "registry/classifier.json")
WORKFLOW_FILES = ("scripts/omega_workflow.py", "scripts/omega_orchestrate.py")


def fingerprint():
    """Release identity: per-file sha256 and a combined sha256 (router) plus the workflow engine hash."""
    root = HERE.parent

    def combo(names):
        h = hashlib.sha256()
        files = {}
        for n in names:
            b = (root / n).read_bytes()
            files[n] = hashlib.sha256(b).hexdigest()
            h.update(n.encode() + b"\0" + b)
        return h.hexdigest(), files
    r, rf = combo(FINGERPRINT_FILES)
    w, wf = combo(WORKFLOW_FILES)
    return {"router_fingerprint": r, "workflow_fingerprint": w, "files": {**rf, **wf}}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("route"); p.add_argument("task"); p.add_argument("--limit", type=int, default=12); p.add_argument("--json", action="store_true")
    p.add_argument("--rules-only", action="store_true", help="skip the classifier layer (same as OMEGA_CLASSIFIER=off)")
    p.add_argument("--session-tools", help="comma list or @file of tool names present in this session")
    p.add_argument("--authorized", help="comma list of tool keys the user authorised (e.g. canva,adobe)")
    p = sub.add_parser("run", help="multi-step execution ledger")
    p.add_argument("action", choices=["init", "next", "start", "done", "fail", "report"])
    p.add_argument("arg", nargs="?")
    p.add_argument("--state", default=None)
    p.add_argument("--artifact", action="append", default=[])
    p.add_argument("--note")
    p.add_argument("--reason")
    p.add_argument("--json", action="store_true")
    p.add_argument("--session-tools")
    p.add_argument("--authorized")
    p = sub.add_parser("doctor"); p.add_argument("--json", action="store_true"); p.add_argument("--strict", action="store_true"); p.add_argument("--offline", action="store_true")
    p = sub.add_parser("list"); p.add_argument("--plugin"); p.add_argument("--topic")
    p = sub.add_parser("show"); p.add_argument("name")
    sub.add_parser("check-routes")
    sub.add_parser("fingerprint", help="sha256 of the router sources, registries and classifier model (release identity)")
    p = sub.add_parser("workflow", help="validated DAG workflows: validate / run / status / from-route (see omega_workflow.py)")
    p.add_argument("rest", nargs=argparse.REMAINDER)
    a = ap.parse_args(argv)

    for flag, env in (("session_tools", "OMEGA_SESSION_TOOLS"), ("authorized", "OMEGA_AUTHORIZED")):
        if getattr(a, flag, None) is not None:
            os.environ[env] = getattr(a, flag)
    if a.cmd == "route":
        if a.rules_only:
            os.environ["OMEGA_CLASSIFIER"] = "off"
        res = route(a.task, a.limit)
        print(json.dumps(res, indent=1, ensure_ascii=False) if a.json else explain(res))
        return 0
    if a.cmd == "run":
        spec = importlib.util.spec_from_file_location("omega_orchestrate", HERE / "omega_orchestrate.py")
        orch = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(orch)
        state = a.state or orch.DEFAULT_STATE
        if a.action == "init":
            if not a.arg:
                ap.error("run init needs the task text")
            data = orch.init(route(a.arg), state)
            print(orch.report(data)["text"])
            return 0
        data = orch._load(state)
        if a.action == "next":
            r = orch.ready(data)
            print(json.dumps([{"n": s["n"], "id": s["id"], "subtask": s["subtask"], "use": s["use"]} for s in r], indent=1, ensure_ascii=False)
                  if a.json else ("\n".join(f"{s['n']}. {s['id']}  <- {s['subtask']}  [{s['route_status']}] {s['use']}" for s in r) or "nothing ready"))
            return 0
        if a.action in ("start", "done", "fail") and not (a.arg or "").isdigit():
            ap.error(f"run {a.action} needs a step number")
        if a.action == "start":
            inputs = orch.start(data, int(a.arg), state)
            print(f"step {a.arg} running; verified inputs:" + ("".join(f"\n  {i['path']} ({i['sha256'][:12]}...)" for i in inputs) or " none"))
            return 0
        if a.action == "done":
            st = orch.done(data, int(a.arg), a.artifact, a.note, state)
            print(f"step {a.arg} done; {len(st['artifacts'])} artifact(s) verified")
            return 0
        if a.action == "fail":
            orch.fail(data, int(a.arg), a.reason or "unspecified", state)
            print(orch.report(data)["text"])
            return 0
        rep = orch.report(data)
        print(json.dumps(rep, indent=1, ensure_ascii=False) if a.json else rep["text"])
        return 0 if rep["complete"] else 3
    if a.cmd == "doctor":
        res = doctor(offline=a.offline)
        fatal = [c for c in res if not c["ok"] and c["severity"] == "fatal"]
        failed = [c for c in res if not c["ok"] and c["severity"] in ("optional", "warn")]
        if a.json:
            print(json.dumps({"fatal_failures": len(fatal), "optional_missing": len(failed), "checks": res}, indent=1))
        else:
            mark = {"fatal": "FAIL", "optional": "MISS", "warn": "WARN", "info": "INFO"}
            for c in res:
                tag = "OK  " if c["ok"] else mark[c["severity"]]
                print(f"[{tag}] {c['check']:<36} {c['detail']}")
                if not c["ok"] and c["fix"]:
                    print(f"        needed by: {c['needed_by']}\n        fix: {c['fix']}")
            print(f"\n{len(fatal)} fatal failure(s), {len(failed)} optional/warning item(s) missing")
        return 1 if fatal or (a.strict and failed) else 0
    if a.cmd == "list":
        for s in load("skills.json"):
            if a.plugin and s["plugin"] != a.plugin:
                continue
            if a.topic and a.topic not in s["topics"]:
                continue
            print(f"{s['invocation']:<55} {s['description'][:90]}")
        return 0
    if a.cmd == "show":
        hits = [s for s in load("skills.json") if a.name in (s["invocation"], s["name"])]
        print(json.dumps(hits, indent=1) if hits else f"no skill named {a.name}")
        return 0 if hits else 1
    if a.cmd == "fingerprint":
        fp = fingerprint()
        print(json.dumps(fp, indent=1))
        return 0
    if a.cmd == "workflow":
        return _sibling("omega_workflow").main(a.rest)
    if a.cmd == "check-routes":
        probs = check_routes()
        for pr in probs:
            print(pr)
        print(f"{len(probs)} problem(s)")
        return 1 if probs else 0
    return 2


if __name__ == "__main__":
    sys.exit(main())
