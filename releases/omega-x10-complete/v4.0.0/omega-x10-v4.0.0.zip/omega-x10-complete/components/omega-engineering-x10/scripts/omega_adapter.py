#!/usr/bin/env python3
"""Optional external classifier adapter (LLM or embedding service). OFF by default; never used silently.

The adapter is consulted only when BOTH are set by the user:
  OMEGA_ADAPTER_CMD      an argv command (JSON list, e.g. ["python3", "/path/my_llm_router.py"]) that reads
                         {"task": "...", "intents": [...]} on stdin and prints
                         {"decision": "route|multi|clarify|none", "intents": [...], "confidence": 0..1}
  OMEGA_ADAPTER_CONSENT  must be exactly "granted": the user agreed that the request text may leave this
                         process (the command may call a network service, need credentials or spend credits)

Behaviour:
  * no command or no consent  -> adapter is not called; route() reports adapter.used = false and why
  * command fails, times out (OMEGA_ADAPTER_TIMEOUT, default 8 s), or prints invalid output -> a warning
    is reported and routing continues with the offline rules + classifier (deterministic fallback)
  * a valid answer is advisory: it replaces the offline decision only when the offline classifier is
    uncertain (its strongest outcome probability is below 0.6) and the adapter's confidence is >= 0.7;
    every override is shown in the route result under layers.adapter.
The offline tests never set these variables; this module itself never opens a network connection.
"""
import json
import os
import subprocess

VALID = {"route", "multi", "clarify", "none"}


def status():
    cmd = os.environ.get("OMEGA_ADAPTER_CMD", "").strip()
    consent = os.environ.get("OMEGA_ADAPTER_CONSENT", "").strip()
    if not cmd:
        return None, "not configured (OMEGA_ADAPTER_CMD unset)"
    if consent != "granted":
        return None, "configured but not used: OMEGA_ADAPTER_CONSENT is not 'granted'"
    try:
        argv = json.loads(cmd)
        if not isinstance(argv, list) or not argv or not all(isinstance(x, str) for x in argv):
            raise ValueError("must be a JSON list of strings")
    except ValueError as exc:
        return None, f"OMEGA_ADAPTER_CMD invalid ({exc})"
    return argv, "enabled with consent"


def consult(task, intents):
    """Returns (answer_or_None, info dict)."""
    argv, why = status()
    info = {"used": False, "why": why}
    if argv is None:
        return None, info
    try:
        timeout = float(os.environ.get("OMEGA_ADAPTER_TIMEOUT", "8"))
    except ValueError:
        timeout = 8.0
    try:
        proc = subprocess.run(argv, input=json.dumps({"task": task, "intents": intents}), capture_output=True, text=True,  # noqa: S603 - user-configured argv, no shell
                              timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        info.update(why=f"adapter failed ({exc.__class__.__name__}); offline layers used")
        return None, info
    if proc.returncode != 0:
        info.update(why=f"adapter exit code {proc.returncode}; offline layers used")
        return None, info
    try:
        ans = json.loads(proc.stdout)
        if ans.get("decision") not in VALID or not isinstance(ans.get("intents", []), list) or \
                not set(ans.get("intents", [])) <= set(intents) or not 0 <= float(ans.get("confidence", 0)) <= 1:
            raise ValueError("schema")
    except (ValueError, AttributeError, TypeError):
        info.update(why="adapter output invalid; offline layers used")
        return None, info
    info.update(used=True, why="answer received", answer=ans)
    return ans, info
