#!/usr/bin/env python3
"""OMEGA X10 contextual classifier layer (v4). Standard library only, fully offline, deterministic.

A one-vs-rest logistic-regression model over sparse features of the *unmasked* request:
  - word unigrams/bigrams of the normalised text (negated and discussion spans removed; their words
    are kept as separate "neg:"/"disc:" features so the model can learn what not-doing looks like),
  - character 3-5 grams inside word boundaries (spelling variation, morphology, Arabizi),
  - Arabizi consonant skeletons of Latin tokens,
  - lexicon concepts found by the rule layer (unmasked hits, with their roles),
  - the rule layer's per-intent scores (stacking).

Heads: one per intent (is this intent required?) plus three outcome heads (route / none / clarify).
Weights live in registry/classifier.json, produced by scripts/omega_train.py from development data only.
The model never calls a network service; an optional external LLM/embedding adapter is a separate,
opt-in component (see references/optional-models.md) and is never used by this module.
"""
import json
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MODEL_PATH = ROOT / "registry" / "classifier.json"
OUTCOMES = ("route", "none", "clarify")
_MODEL = {}


def _strip_spans(norm, masks):
    """Text with masked spans blanked; and the list of masked texts by reason."""
    keep = list(norm)
    removed = {"negated": [], "discussion": [], "source": []}
    for m in masks:
        removed.setdefault(m["reason"], []).append(norm[m["start"]:m["end"]])
        for k in range(m["start"], min(m["end"], len(keep))):
            keep[k] = " "
    return "".join(keep), removed


def _words(text):
    return re.findall(r"[\w'+#./-]+", text)


def features(ctx, rule_scores, lang):
    """Sparse feature dict for one request (or one clause: pass a sub-context)."""
    f = {}

    def add(k, v=1.0):
        f[k] = f.get(k, 0.0) + v

    text, removed = _strip_spans(ctx["norm"], ctx["masks"])
    words = [w.strip("'./-") for w in _words(text)]
    words = [w for w in words if w]
    for w in words:
        add("w:" + w)
        if not lang.is_arabic(w) and re.search(r"[a-z]", w):
            sk = lang.skeleton(w)
            if len(sk) >= 2:
                add("s:" + sk)
        padded = " " + w + " "
        for n in (3, 4, 5):
            for i in range(len(padded) - n + 1):
                add("c:" + padded[i:i + n], 0.25)
    for a, b in zip(words, words[1:]):
        add("b:" + a + "_" + b)
    for reason, spans in removed.items():
        if spans:
            add("mask:" + reason)
        for span in spans:
            for w in _words(span)[:6]:
                add(reason[:4] + ":" + w)
    for h in ctx["hits"]:
        if h.masked:
            add("mc:" + h.concept)
            continue
        add("k:" + h.concept)
        add("r:" + h.role)
    for intent, s in rule_scores.items():
        if s > 0:
            add("rule:" + intent, min(s, 8.0) / 4.0)
            if s >= 2.5:
                add("rsel:" + intent)
    n = len(words)
    add("len:" + ("1" if n <= 1 else "2" if n == 2 else "3-4" if n <= 4 else "5-8" if n <= 8 else "9-16" if n <= 16 else "17+"))
    if "?" in ctx["raw"] or "؟" in ctx["raw"]:
        add("qmark")
    add("nclause:" + str(min(len(ctx["clauses"]), 4)))
    if ctx.get("anaphora"):
        add("anaphora")
    add("bias")
    # L2-normalise the n-gram block so long rambling prompts do not dominate
    norm = math.sqrt(sum(v * v for k, v in f.items() if k[:2] in ("c:", "w:", "b:", "s:"))) or 1.0
    for k in list(f):
        if k[:2] in ("c:", "w:", "b:", "s:"):
            f[k] = f[k] / norm
    return f


def load_model(path=None):
    """The bundled model; OMEGA_CLASSIFIER_MODEL may point at another model file (used by cross-validation)."""
    import os  # noqa: PLC0415
    path = path or os.environ.get("OMEGA_CLASSIFIER_MODEL") or MODEL_PATH
    key = str(path)
    if key not in _MODEL:
        try:
            with open(path, encoding="utf-8") as fh:
                m = json.load(fh)
            if m.get("format") != "omega-classifier/1":
                raise ValueError("unknown classifier format")
            _MODEL[key] = m
        except (OSError, ValueError) as exc:
            _MODEL[key] = {"error": f"{exc.__class__.__name__}: {exc}"}
    return _MODEL[key]


def _sigmoid(z):
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    e = math.exp(z)
    return e / (1.0 + e)


def predict(feats, model):
    """{head: probability} for every head in the model."""
    heads = model["heads"]
    z = list(model["bias"])
    W = model["weights"]
    for k, v in feats.items():
        row = W.get(k)
        if row:
            for h, w in row:
                z[h] += w * v
    return {heads[h]: _sigmoid(z[h]) for h in range(len(heads))}


def token_evidence(ctx, model, head, lang):
    """Per-token positive evidence for one head (word, skeleton, char n-gram and bigram weights), ignoring
    masked spans. Used to place each selected intent in the clause where it is asked for."""
    hidx = model["heads"].index(head)
    W = model["weights"]

    def w(k):
        return next((x for h, x in (W.get(k) or []) if h == hidx), 0.0)

    masked = [(m["start"], m["end"]) for m in ctx["masks"]]
    toks = [(t, s, e) for t, s, e in ctx["tokens"] if not any(a <= s < b for a, b in masked)]
    out = []
    for n, (t, s, e) in enumerate(toks):
        t2 = t.strip("'./-")
        if not t2:
            continue
        score = w("w:" + t2)
        if not lang.is_arabic(t2) and re.search(r"[a-z]", t2):
            score += w("s:" + lang.skeleton(t2))
        padded = " " + t2 + " "
        score += 0.25 * sum(w("c:" + padded[i:i + k]) for k in (3, 4, 5) for i in range(len(padded) - k + 1))
        if n + 1 < len(toks):
            score += 0.5 * w("b:" + t2 + "_" + toks[n + 1][0].strip("'./-"))
        if n > 0:
            score += 0.5 * w("b:" + toks[n - 1][0].strip("'./-") + "_" + t2)
        out.append((s, score))
    return out
