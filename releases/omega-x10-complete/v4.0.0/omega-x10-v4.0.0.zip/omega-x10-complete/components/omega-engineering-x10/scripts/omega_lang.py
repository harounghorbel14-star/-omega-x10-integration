#!/usr/bin/env python3
"""Language layer for omega.py route: English, French, Arabic script, Tunisian Arabizi, mixed.

Pipeline (all deterministic, standard library only):
  1. normalise(): NFKD + drop combining marks (accents, Arabic diacritics, hamza seats), lowercase,
     Arabic letter unification (ة->ه, ى->ي, tatweel), Arabic punctuation/digits -> ASCII, English contractions.
  2. Tokenise; match tokens and phrases to language-independent concepts (registry/lexicon.json):
       latin entries: exact / prefix (*) / phrase, optionally scoped to fr: or en:
       arabic entries: stem prefix after clitic stripping (وال فال بال لل ال و ف ب ل)
       arabizi entries: consonant skeleton (7->h 3 9->q 5->x ch->$ kh->x ...), so sala7/salla7/sallah meet
  3. Segment clauses (punctuation, and/et/w/و, then/puis/ba3d/ثم, attached Arabic و/ف).
  4. Mark negated spans (imperative negation only: "don't deploy", "ne déploie pas", "ma t3amelch",
     "لا تنشر", "بدون"). Descriptive negation ("ne marche pas", "ma ye5demch", "ما يخدمش") is bug evidence.
  5. Mark discussion sentences ("what is", "c'est quoi", "chnowa", "شنوة", "explain") without an execution verb.
  6. Evaluate verb-object rules per clause; generic words (app, code, image alone, بحث alone) never reach
     the selection threshold on their own.
"""
import json
import re
import unicodedata
from functools import lru_cache
from pathlib import Path

TOKEN = re.compile(r"[^\W_]+", re.UNICODE)
AR_CHAR = re.compile(r"[ء-ي]")
FR_ACCENT = re.compile(r"[éèêëàâçùûîïôœ]", re.I)
DOMAIN = re.compile(r"\b[\w-]+\.(?:com|org|io|net|dev|co|tn|fr|ai|app|gov|edu)\b")
SENTENCE_END = re.compile(r"[.?!;\n]")
CLAUSE_PUNCT = re.compile(r"[,;.!?:\n]|\s-\s")

CONTRACTIONS = [(r"\b(what|who|where|how|that|it|there)'s\b", r"\1 is"), (r"\b(\w+)n't\b", r"\1 not"),
                (r"\b(we|you|they)'re\b", r"\1 are"), (r"\bi'm\b", "i am"), (r"\b(i|we|you|they)'d\b", r"\1 would"),
                (r"\bwon not\b", "will not"), (r"\bcan not\b", "can not"), (r"\bdo not\b", "do not")]
AR_MAP = {"ى": "ي", "ة": "ه", "ـ": "", "،": ",", "؛": ";", "؟": "?", "٪": "%"}
AR_MAP.update({chr(0x660 + i): str(i) for i in range(10)})
AR_MAP.update({chr(0x6F0 + i): str(i) for i in range(10)})
AR_TRANS = str.maketrans(AR_MAP)

AR_PREFIXES = ("وال", "فال", "بال", "كال", "لل", "ال", "و", "ف", "ب", "ل")
AR_SUFFIXES = ("", "ها", "هم", "ه", "ي", "لي", "نا", "ني", "ك", "كم", "وا", "ات", "ين", "ون", "يه", "تها", "وه", "ا", "لها", "لو")
TN_PREFIXES = ("fel", "bel", "lel", "el", "w", "l", "b", "f", "ma", "t", "n", "y")
TN_DIGITS = str.maketrans({"7": "h", "9": "q", "5": "x", "2": "", "8": "G", "6": "T"})
TN_DIGRAPHS = (("ch", "$"), ("sh", "$"), ("kh", "x"), ("gh", "G"), ("th", "T"), ("dh", "D"), ("ou", "u"))
NOT_ARABIZI = {"3d", "2d", "mp4", "mp3", "h264", "p95", "b2b", "2fa", "s3", "4k", "1080p", "720p", "ec2", "web3", "i18n", "k8s",
               "oauth2", "py3", "es6", "h1", "h2", "v2", "v3", "x10", "1080x1080", "500", "404", "413", "8", "10", "20", "30"}
ARABIZI_FUNCTION = {"el", "fel", "lel", "mta3", "mte3", "ba3d", "barka", "fama", "chnowa", "chnia", "bech", "3la", "3al", "hedha",
                    "hedhi", "hedhom", "nheb", "n7eb", "kifech", "barcha", "zeda", "mouch", "mech", "bla", "7aja", "elli", "wala",
                    "chneya", "lsa7bi", "kahaw", "brabi", "ken", "ki", "w", "mel", "men", "ya", "3lih", "jdid", "fiha", "bin", "ama"}
FR_FUNCTION = {"le", "la", "les", "des", "une", "un", "et", "pour", "avec", "est", "je", "tu", "nous", "vous", "qui", "que", "dans",
               "sur", "pas", "ce", "cette", "mon", "ma", "mes", "notre", "nos", "du", "au", "aux", "puis", "ensuite", "juste", "sans",
               "moi", "quoi", "comment", "fais", "crée", "cree"}
EN_FUNCTION = {"the", "a", "an", "and", "for", "with", "to", "of", "is", "my", "our", "this", "that", "it", "then", "please", "do",
               "don't", "what", "how", "from", "on", "in", "make", "build", "fix", "just"}
DESCRIPTIVE_FR = {"marche", "fonctionne", "charge", "affiche", "demarre", "compile", "repond", "ouvre", "passe", "lance", "s",
                  "arrive", "arrivent", "tourne", "envoie", "recoit", "sauvegarde", "apparait", "apparaissent", "trouve", "renvoie"}
EN_NEG_SINGLE = {"never", "without", "skip", "avoid", "dont"}
EN_BEHAVIOUR = {"load", "loads", "work", "works", "open", "opens", "show", "shows", "appear", "appears", "arrive", "arrives", "start",
                "starts", "render", "renders", "save", "saves", "respond", "responds", "send", "sends", "return", "returns", "display",
                "displays", "sync", "syncs", "run", "runs", "fire", "fires", "update", "updates", "connect", "connects", "trigger"}
EN_NECESSARY = {"needed", "necessary", "required", "wanted"}
FR_NEG_END = {"pas", "jamais", "plus", "rien", "aucun", "aucune", "personne", "point"}
FR_SUBJECT_PRONOUNS_IMPERATIVE = set()
TN_NECESSARY = {"lazem", "lezem", "lazm", "lazim", "lazma", "lezma", "lazmin", "darouri"}
AR_NECESSARY = {"لازم", "ضروري", "مهم", "لازمه"}
AR_BEHAVIOUR = {"تظهر", "تصل", "توصل", "تخدم", "تعمل", "تشتغل", "تفتح", "تتحمل", "تطلع", "تبان", "ترجع", "تتبعث", "تمشي"}
TN_BEHAVIOUR = {"tetla3ch", "tetla3", "ye5dem", "tekhdem", "te5dem", "yemchi", "temchi", "yet7al", "tet7al", "youslou", "twassel", "tban"}
SUBJECTLESS = {"please", "pls", "plz", "just", "ok", "okay", "so", "and", "but", "also", "then", "now", "hey", "stp", "svp", "s'il",
               "te", "plait", "juste", "et", "mais", "puis", "w", "ama", "ya", "3afak", "brabi", "taw", "tawa", "حتى", "فقط", "برك", "و",
               "you", "u", "tu", "vous", "enti", "inti", "انت", "انتي"}
CAUSATIVE_PROPS = {"N_FASTER"}
CAUSATIVE_VERBS = {"V_CREATE", "V_IMPROVE", "V_FIX", "V_CHANGE", "V_UPDATE"}
EVAL_QUESTION = re.compile(
    r"^(is|are|was|does|do|can|should|would|est ce|est-ce|c est|c'est|ca vaut|vaut il|هل|واش|wach|ach|chnowa|يا ترى|ايا|est il|est elle)\b.*"
    r"\b(free|paid|worth|useful|any good|good|safe|reliable|better|legit|expensive|cheap|gratuit|gratuite|payant|payante|utile|fiable|"
    r"vaut|cher|chere|bien|mieux|مجاني|مجانا|مفيد|مفيده|يستاهل|يسوى|باهي|امن|موثوق|بلاش|fabor|bla flous|ystahel|yestahel|behi|mlih|s7i7)\b")
SUBJECT_PRONOUNS = {"it", "they", "he", "she", "il", "elle", "ils", "elles", "howa", "hiya", "homa", "هو", "هي", "هوما"}
ROLE_VERB = {"verb", "verb_generic"}
ROLE_OBJECT = {"object", "object_generic"}


# ------------------------------------------------------------------ normalisation
def normalise(text):
    t = text.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    t = unicodedata.normalize("NFKD", t)
    t = "".join(ch for ch in t if not unicodedata.combining(ch))
    t = t.lower().translate(AR_TRANS)
    for pat, sub in CONTRACTIONS:
        t = re.sub(pat, sub, t)
    return re.sub(r"\s+", " ", t).strip()


def skeleton(word):
    w = re.sub(r"(.)\1+", r"\1", word.lower())
    for a, b in TN_DIGRAPHS:
        w = w.replace(a, b)
    w = w.translate(TN_DIGITS)
    return re.sub(r"[aeiouy]", "", w)


def is_arabic(tok):
    return bool(AR_CHAR.search(tok))


def has_arabizi_digit(tok):
    return tok not in NOT_ARABIZI and bool(re.search(r"[a-z]", tok)) and bool(re.search(r"[235789]", tok)) \
        and not re.fullmatch(r"[a-z]*\d+(px|ms|kb|mb|gb|s|k|x\d+)?", tok)


# ------------------------------------------------------------------ lexicon index
class Index:
    def __init__(self, lex):
        self.lex = lex
        self.role = {c: v["role"] for c, v in lex["concepts"].items()}
        self.latin_single, self.latin_prefix, self.latin_phrase = {}, [], []
        self.arabic_single, self.arabic_phrase = [], []
        self.tn_single, self.tn_phrase = [], []
        for c, v in lex["concepts"].items():
            for e in v["latin"]:
                scope = None
                if e[:3] in ("fr:", "en:"):
                    scope, e = e[:2], e[3:]
                toks = TOKEN.findall(normalise(e.rstrip("*")))
                pref = e.endswith("*")
                if not toks:
                    continue
                if len(toks) == 1 and pref:
                    self.latin_prefix.append((toks[0], c, scope))
                elif len(toks) == 1:
                    self.latin_single.setdefault(toks[0], []).append((c, scope))
                else:
                    self.latin_phrase.append((tuple(toks), c, scope, pref))
            for e in v["arabic"]:
                exact = e.startswith("=")
                toks = TOKEN.findall(normalise(e.lstrip("=")))
                if len(toks) == 1:
                    self.arabic_single.append((toks[0], c, exact or len(toks[0]) <= 2))
                elif toks:
                    self.arabic_phrase.append((tuple(toks), c))
            for e in v["arabizi"]:
                toks = TOKEN.findall(e.lower())
                if len(toks) == 1:
                    self.tn_single.append((skeleton(toks[0]), c, toks[0], bool(re.search(r"\d", toks[0]))))
                elif toks:
                    self.tn_phrase.append((tuple(skeleton(t) for t in toks), c))
        self.latin_phrase.sort(key=lambda x: -len(x[0]))
        self.arabic_phrase.sort(key=lambda x: -len(x[0]))
        self.tn_phrase.sort(key=lambda x: -len(x[0]))
        self.stop = set(lex["stopwords"])


@lru_cache(maxsize=4)
def load_index(path):
    with open(path, encoding="utf-8") as fh:
        return Index(json.load(fh))


def _ar_forms(tok):
    yield tok, ""
    for p in AR_PREFIXES:
        if tok.startswith(p) and len(tok) - len(p) >= 2:
            yield tok[len(p):], p


def _ar_match(form, stem, exact):
    if exact:
        return form == stem or (form.startswith(stem) and form[len(stem):] in AR_SUFFIXES)
    return form.startswith(stem) and len(form) - len(stem) <= 4


def _tn_forms(tok):
    yield skeleton(tok), ""
    for p in TN_PREFIXES:
        if tok.startswith(p) and len(tok) - len(p) >= 3:
            yield skeleton(tok[len(p):]), p


# consonant skeletons of Tunisian clitics/inflections that may follow a stem (object pronouns, plural, negation -ch)
TN_CLITIC_SK = {"", "h", "hm", "k", "km", "n", "l", "lk", "lh", "lhm", "ln", "lkm", "t", "w", "$", "y", "tk", "th", "tw", "lw",
                "w$", "h$", "k$", "t$", "n$", "hl", "l$"}


def _tn_match(form, entry_sk, has_digit, tok="", raw_entry=""):
    """Arabizi stem match on consonant skeletons. v4: what may follow the stem is restricted to clitic/inflection
    skeletons (no free prefix match: "tahni2a" no longer matches "ti7", "boutique" no longer matches "bouton"),
    and a two-consonant stem written with a digit only matches a token that contains that same digit."""
    if not form.startswith(entry_sk):
        return False
    rest = form[len(entry_sk):]
    if len(entry_sk) >= 3:
        return rest in TN_CLITIC_SK
    if len(entry_sk) == 2:
        if form == entry_sk:
            return True
        digits = [ch for ch in raw_entry if ch.isdigit()]
        return has_digit and bool(digits) and all(d in tok for d in digits) and rest in TN_CLITIC_SK
    return False


# ------------------------------------------------------------------ analysis
class Hit:
    __slots__ = ("concept", "role", "i", "j", "start", "end", "how", "conj_before", "suffix", "masked", "source")

    def __init__(self, concept, role, i, j, start, end, how, suffix=""):
        self.concept, self.role, self.i, self.j, self.start, self.end, self.how = concept, role, i, j, start, end, how
        self.conj_before, self.suffix, self.masked, self.source = False, suffix, None, False

    def as_dict(self):
        return {"concept": self.concept, "tokens": [self.i, self.j], "how": self.how, "masked": self.masked, "source": self.source}


def detect_languages(raw, toks):
    langs = []
    words = set(toks)
    if any(is_arabic(t) for t in toks):
        langs.append("ar")
    arabizi = any(has_arabizi_digit(t) for t in toks) or len(words & ARABIZI_FUNCTION - {"w", "ki", "ya", "men", "ken"}) >= 1
    if arabizi:
        langs.append("tn-latn")
    if FR_ACCENT.search(raw) or len(words & FR_FUNCTION) >= 1:
        langs.append("fr")
    if len(words & EN_FUNCTION) >= 1 or (not langs and any(re.fullmatch(r"[a-z]+", t) for t in toks)):
        langs.append("en")
    return langs


EMPTY_LEXICON = {"concepts": {}, "rules": [], "tools": {}, "stopwords": [], "creative_verbs": [], "execution_verbs": []}


def analyse(text, lexicon_path):
    idx = load_index(str(lexicon_path)) if lexicon_path is not None else Index(EMPTY_LEXICON)
    raw = text
    norm = normalise(text)
    tokens = [(m.group(0), m.start(), m.end()) for m in TOKEN.finditer(norm)]
    toks = [t for t, _, _ in tokens]
    langs = detect_languages(raw.lower(), toks)
    fr, en, tn = "fr" in langs, "en" in langs, ("tn-latn" in langs or "ar" in langs)

    def scope_ok(scope):
        return scope is None or (scope == "fr" and fr) or (scope == "en" and (en or not fr))

    hits, covered = [], set()
    # --- phrases (claim their tokens)
    n = len(toks)
    for i in range(n):
        for ptoks, c, scope, pref in idx.latin_phrase:
            k = len(ptoks)
            if i + k <= n and scope_ok(scope) and all(toks[i + q] == ptoks[q] for q in range(k - 1)) and \
                    (toks[i + k - 1].startswith(ptoks[-1]) if pref else toks[i + k - 1] == ptoks[-1]):
                hits.append(Hit(c, idx.role[c], i, i + k, tokens[i][1], tokens[i + k - 1][2], "latin-phrase"))
                covered.update(range(i, i + k))
        for ptoks, c in idx.arabic_phrase:
            k = len(ptoks)
            if i + k <= n and all(any(_ar_match(f, ptoks[q], False) for f, _ in _ar_forms(toks[i + q])) for q in range(k)):
                hits.append(Hit(c, idx.role[c], i, i + k, tokens[i][1], tokens[i + k - 1][2], "arabic-phrase"))
                covered.update(range(i, i + k))
        for psk, c in idx.tn_phrase:
            k = len(psk)
            if i + k <= n and all(not is_arabic(toks[i + q]) for q in range(k)) and (tn or any(has_arabizi_digit(toks[i + q]) for q in range(k))):
                ok = all(skeleton(toks[i + q]) == psk[q] for q in range(k - 1)) and \
                    any(_tn_match(f, psk[-1], True) for f, _ in _tn_forms(toks[i + k - 1]))
                if ok:
                    hits.append(Hit(c, idx.role[c], i, i + k, tokens[i][1], tokens[i + k - 1][2], "arabizi-phrase"))
                    covered.update(range(i, i + k))
    # --- single tokens
    for i, (tok, s, e) in enumerate(tokens):
        if i in covered:
            continue
        found = {}
        if is_arabic(tok):
            full = [(c, "") for stem, c, exact in idx.arabic_single if _ar_match(tok, stem, exact)]
            if full:
                for c, _ in full:
                    found.setdefault(c, ("arabic", "", ""))
            else:
                for form, p in list(_ar_forms(tok))[1:]:
                    for stem, c, exact in idx.arabic_single:
                        if _ar_match(form, stem, exact):
                            found.setdefault(c, ("arabic", p, form[len(stem):]))
            if tok == "و":
                found.setdefault("CONJ", ("arabic", "", ""))
        else:
            for c, scope in idx.latin_single.get(tok, []):
                if scope_ok(scope):
                    found.setdefault(c, ("latin", "", ""))
            for pre, c, scope in idx.latin_prefix:
                if tok.startswith(pre) and scope_ok(scope):
                    found.setdefault(c, ("latin", "", tok[len(pre):]))
            latin_word = bool(found)  # v4: a token that is already a known French/English word is not re-read as Arabizi
            if (tn or has_arabizi_digit(tok)) and not (latin_word and not has_arabizi_digit(tok)):
                function_word = tok in idx.stop or tok in ARABIZI_FUNCTION
                for form, p in _tn_forms(tok):
                    for esk, c, raw_e, digit in idx.tn_single:
                        if function_word and idx.role[c] not in ("marker", "disc"):
                            continue
                        if len(esk) < 2 or (len(esk) == 2 and not digit):
                            if tok == raw_e or tok[len(p):] == raw_e:
                                found.setdefault(c, ("arabizi", p, ""))
                        elif _tn_match(form, esk, digit, tok[len(p):], raw_e):
                            found.setdefault(c, ("arabizi", p, tok[len(p):][len(raw_e):] if tok[len(p):].startswith(raw_e) else tok[-3:]))
        for c, (how, prefix, suffix) in found.items():
            h = Hit(c, idx.role[c], i, i + 1, s, e, how, suffix)
            h.conj_before = prefix in ("و", "ف", "w")
            hits.append(h)
    for m in DOMAIN.finditer(norm):
        ti = next((q for q, (_, s, e) in enumerate(tokens) if s >= m.start()), 0)
        hits.append(Hit("N_WEB_TARGET", "object", ti, ti + 1, m.start(), m.end(), "domain"))

    # --- clause segmentation
    bounds = set()
    seq_at = set()
    for h in hits:
        if h.concept == "CONJ" and h.start > 0 and norm[h.start - 1] == "-" and norm[h.end:h.end + 1] == "-":
            continue  # "drag-and-drop", "rock-et-roll": a compound, not a clause boundary
        if h.concept in ("CONJ", "SEQ", "RELATIVE") and not any(o.i <= h.i and h.j <= o.j and (o.j - o.i) > (h.j - h.i) for o in hits if o is not h and o.concept not in ("CONJ", "SEQ")):
            bounds.add(h.i)
            if h.concept == "SEQ":
                seq_at.add(h.i)
        if h.conj_before:
            bounds.add(h.i)
    clauses, cur_start, seq_flag, via = [], 0, False, "start"
    punct_pos = [m.start() for m in CLAUSE_PUNCT.finditer(norm)]
    for i, (tok, s, e) in enumerate(tokens):
        by_punct = i > 0 and any(tokens[i - 1][2] <= p < s for p in punct_pos)
        if i > 0 and (i in bounds or by_punct):
            if cur_start < i:
                clauses.append([cur_start, i, seq_flag, via])
            via = "punct" if by_punct else ("seq" if i in seq_at else "conj")
            seq_flag = i in seq_at
            cur_start = i
    if cur_start < n:
        clauses.append([cur_start, n, seq_flag, via])
    # drop clauses made only of markers, carrying their SEQ flag forward
    marker_tok = {q for h in hits if h.concept in ("CONJ", "SEQ", "FILLER", "RELATIVE") for q in range(h.i, h.j)}
    relative_at = {h.i for h in hits if h.concept == "RELATIVE"}
    merged = []
    carry = False
    carry_via = None
    for a, b, sq, how in clauses:
        if all(q in marker_tok for q in range(a, b)):
            carry = carry or sq or any(q in seq_at for q in range(a, b))
            carry_via = carry_via or how
            continue
        rel = a in relative_at or (a - 1) in relative_at
        if not rel and merged and merged[-1]["relative"] and (carry_via or how) == "conj":
            rel = True  # "a pipeline that runs lint and tests": the relative clause continues across "and"
        merged.append({"i": a, "j": b, "seq_before": sq or carry, "relative": rel, "via": carry_via or how,
                       "start": tokens[a][1], "end": tokens[b - 1][2],
                       "text": norm[tokens[a][1]:tokens[b - 1][2]]})
        carry = False
        carry_via = None
    clauses = merged or [{"i": 0, "j": n, "seq_before": False, "start": 0, "end": len(norm), "text": norm}]

    def clause_of(i):
        for ci, cl in enumerate(clauses):
            if cl["i"] <= i < cl["j"]:
                return ci
        return len(clauses) - 1

    # --- negation: imperative ("don't X" -> X is not requested), descriptive ("X doesn't work" -> bug
    # evidence), lexical ("leave X alone", "inutile de X") and post-posed ("X mouch lazma", "X not needed").
    bug_cover = {q for h in hits if h.concept == "N_BUG" for q in range(h.i, h.j)}
    exec_names = set(idx.lex.get("execution_verbs", []))
    verb_at = {}
    for h in hits:
        if h.role in ROLE_VERB:
            verb_at.setdefault(h.i, set()).add(h.concept)
    masks = []

    def clause_bounds(i):
        cl = clauses[clause_of(i)]
        return cl["i"], cl["j"], cl

    def has_subject_before(i):
        """A content word (not a filler/pronoun/discourse marker) earlier in the clause => a subject."""
        a_, _, _ = clause_bounds(i)
        for q in range(a_, i):
            t = toks[q]
            if t in SUBJECTLESS or t in idx.stop and t not in SUBJECT_PRONOUNS:
                continue
            if q in verb_at and verb_at[q] & exec_names:
                return False  # "fix the bug but don't deploy": the earlier word is a verb of another request
            return True
        return False

    def mask_forward(i, why):
        _, _, cl = clause_bounds(i)
        masks.append({"start": tokens[i][1], "end": cl["end"], "reason": "negated", "marker": why})

    def mask_backward(i, why):
        a_, _, cl = clause_bounds(i)
        masks.append({"start": tokens[a_][1], "end": tokens[i][2], "reason": "negated", "marker": why})

    def descriptive(i, j, why):
        j = max(i + 1, min(j, n))
        hits.append(Hit("N_BUG", "object", i, j, tokens[i][1], tokens[j - 1][2], "descriptive-negation:" + why))

    for i, tok in enumerate(toks):
        if i in bug_cover:
            continue
        nxt = toks[i + 1] if i + 1 < n else ""
        nxt2 = toks[i + 2] if i + 2 < n else ""
        prv = toks[i - 1] if i > 0 else ""
        # ---- post-posed: "video mouch lazma", "X not needed", "X inutile", "X مش لازم"
        if (tok in ("mouch", "mech", "mich", "moch", "mush") and nxt in TN_NECESSARY and has_subject_before(i)) or \
                (tok in ("مش", "موش", "ماش", "ليس") and nxt in AR_NECESSARY and has_subject_before(i)) or \
                (tok == "not" and nxt in EN_NECESSARY and has_subject_before(i)) or \
                (tok in ("inutile", "superflu") and has_subject_before(i) and nxt not in ("de", "d")):
            mask_backward(i + 1 if nxt else i, tok + " " + nxt)
            continue
        # ---- lexical negation: leave X alone / keep X as is / sans toucher / ما تمسش / matmesech
        if tok == "leave" and "alone" in toks[i + 1:i + 6] or tok in ("keep",) and nxt2 in ("as", "unchanged") or \
                (tok == "sans" and nxt in ("toucher", "modifier", "changer")) or re.match(r"^ma?t(mes|mas|bad|9is)\w*(ch|sh)$", tok) or \
                (is_arabic(tok) and re.match(r"^(ما ?)?ت(مس|بدل|غير)\w*ش$", tok)):
            mask_forward(i, tok)
            continue
        # ---- English
        if tok == "do" and nxt == "not" or tok in ("dont", "never") or tok == "will" and nxt == "not" and nxt2 not in ("load", "open", "start", "work"):
            j = i + 2 if tok in ("do", "will") else i + 1
            verb = toks[j] if j < n else ""
            if verb in ("want", "need", "like") or prv in ("i", "we") and verb not in EN_BEHAVIOUR:
                mask_forward(i, "do not want")
            elif has_subject_before(i) or verb in EN_BEHAVIOUR:
                descriptive(i, j + 1, "en")
            else:
                mask_forward(i, "do not")
            continue
        if tok in ("does", "did", "is", "are", "was", "were", "can", "could", "has", "have") and nxt == "not":
            descriptive(i, i + 3, "en")  # "the menu does not open", "uploads are not working"
            continue
        if tok in ("without", "skip", "avoid") or (tok == "no" and nxt not in ("one", "idea", "longer", "matter", "results", "result")) \
                or (tok == "not" and prv in ("but", "and", "please", "though")) or (tok == "instead" and nxt == "of") or (tok == "rather" and nxt == "than"):
            if tok == "no" and nxt in ("longer",):
                descriptive(i, i + 3, "en")
            else:
                mask_forward(i, tok)
            continue
        if tok == "no" and nxt in ("longer",):
            descriptive(i, i + 3, "en")
            continue
        # ---- French
        if tok == "sans" or tok in ("evite", "eviter") or (tok == "pas" and nxt in ("de", "d", "besoin", "la", "le", "les") and prv not in ("ne", "n")) \
                or (tok == "au" and nxt == "lieu") or (tok == "inutile" and nxt in ("de", "d")):
            mask_forward(i, tok)
            continue
        if tok in ("ne", "n") and any(t in FR_NEG_END for t in toks[i + 1:i + 5]):
            verb = nxt
            if verb in ("veux", "voudrais", "veut", "souhaite"):
                mask_forward(i, "je ne veux pas")
            elif nxt == "plus" or nxt2 == "plus" or verb in DESCRIPTIVE_FR or has_subject_before(i) and prv not in FR_SUBJECT_PRONOUNS_IMPERATIVE:
                descriptive(i, i + 3, "fr")
            else:
                mask_forward(i, "ne ... pas")
            continue
        # ---- Arabic script (MSA + Tunisian)
        if tok in ("بدون", "دون", "بلا") or (tok in ("مش", "موش", "ماش") and nxt in AR_NECESSARY):
            mask_forward(i, tok)
            continue
        if tok in ("ما", "مايش") and nxt in ("عادش", "عاد", "عادت") or tok in ("ماعادش", "معادش", "عادش"):
            descriptive(i, i + 3, "ar-no-longer")
            continue
        if tok in ("لا", "ما", "لم", "لن") and nxt:
            if tok in ("لم", "لن") or nxt.startswith("ي") or nxt in AR_BEHAVIOUR or has_subject_before(i):
                descriptive(i, i + 2, "ar")  # "الصور لا تظهر", "لا يعمل", "لم يصل"
            elif nxt.startswith("ن"):
                mask_forward(i, "ar-1pl")  # "ما ننشروش": we won't
            elif nxt in ("اريد", "نريد", "نحب", "نحبش", "يلزم", "يلزمش"):
                mask_forward(i, "ar-want")
            else:
                mask_forward(i, tok)  # "لا تنشر", "ما تعملش"
            continue
        if is_arabic(tok) and re.match(r"^ما(ت|ن)\w+ش$", tok):
            if tok[2] == "ت" and has_subject_before(i):
                descriptive(i, i + 1, "ar")
            else:
                mask_forward(i, tok)
            continue
        if is_arabic(tok) and re.match(r"^ماي\w+ش$", tok):
            descriptive(i, i + 1, "ar")
            continue
        # ---- Tunisian Arabizi
        if tok == "bla" or (tok in ("mouch", "mech", "mich", "moch") and nxt in TN_NECESSARY):
            mask_forward(i, tok)
            continue
        if tok in ("ma3adech", "ma3adch", "m3adech", "ma3adech", "3adech") or tok == "ma" and nxt in ("3adech", "3adch", "3ad"):
            descriptive(i, i + 3, "tn-no-longer")
            continue
        if tok == "ma" and nxt and not is_arabic(nxt):
            if nxt.startswith("y") or nxt.startswith("i") or nxt in TN_BEHAVIOUR or has_subject_before(i):
                descriptive(i, i + 2, "tn")
            elif nxt.startswith("n"):
                mask_forward(i, "tn-1pl")  # "ma ndeployiwech": we won't deploy
            else:
                mask_forward(i, "tn")
            continue
        if not is_arabic(tok) and len(tok) > 4 and re.search(r"(ch|sh)$", tok) and re.match(r"^ma?[tny]", tok):
            person = tok[1] if tok[1] in "tny" else tok[2]
            if person == "y" or (person == "t" and has_subject_before(i)):
                descriptive(i, i + 1, "tn")
            else:
                mask_forward(i, tok)
            continue

    # --- discussion sentences
    disc_hits = [h for h in hits if h.role == "disc"]
    exec_verbs = set(idx.lex["execution_verbs"])
    if disc_hits:
        sent_bounds = [0] + [m.end() for m in SENTENCE_END.finditer(norm)] + [len(norm) + 1]
        for h in disc_hits:
            s0 = max(b for b in sent_bounds if b <= h.start)
            s1 = min(b for b in sent_bounds if b > h.start)
            h_clause_start = max((c["start"] for c in clauses if c["start"] <= h.start), default=s0)
            for cl in clauses:
                # the marker's own clause and the clauses after it in the sentence: an earlier clause is a request
                # of its own ("go over this diff and tell me what's risky")
                if cl["start"] >= max(s0, h_clause_start) and cl["end"] <= s1:
                    cl_hits = [x for x in hits if cl["i"] <= x.i < cl["j"]]
                    has_exec = any(x.concept in exec_verbs and not (x.i < h.j and x.j > h.i) for x in cl_hits
                                   if x.concept not in ("V_ANALYZE", "V_REVIEW"))
                    if not has_exec:
                        masks.append({"start": cl["start"], "end": cl["end"], "reason": "discussion", "marker": norm[h.start:h.end]})

    # --- evaluative questions about a tool, feature or concept ("is this free?", "c'est vraiment utile ?",
    #     "هل هذا مجاني؟", "wach ystahel?"): discussion, unless the sentence also asks for work
    qmark_sentences = [m.start() for m in re.finditer(r"[?؟]", raw)]
    if qmark_sentences:
        sent_bounds = [0] + [m.end() for m in SENTENCE_END.finditer(norm)] + [len(norm) + 1]
        for k in range(len(sent_bounds) - 1):
            a_, b_ = sent_bounds[k], min(sent_bounds[k + 1], len(norm))
            sent = norm[a_:b_].strip(" ?.!")
            if not EVAL_QUESTION.search(sent) or any(mk["start"] <= a_ < mk["end"] for mk in masks):
                continue
            sent_hits = [x for x in hits if a_ <= x.start < b_]
            if any(x.concept in exec_verbs and x.concept not in ("V_ANALYZE", "V_REVIEW") and not x.masked for x in sent_hits):
                continue
            masks.append({"start": a_, "end": b_, "reason": "discussion", "marker": "evaluative question"})
    for h in hits:
        for mk in masks:
            if mk["start"] <= h.start < mk["end"]:
                h.masked = mk["reason"] if h.masked in (None, "discussion") else h.masked
    # --- source material ("from these photos", "من الصور", "mel tsawer")
    src = [h for h in hits if h.concept == "SOURCE"]
    for h in hits:
        if h.role in ROLE_OBJECT and h.concept in ("N_IMAGE", "N_VIDEO", "N_DOC", "N_3D"):
            if any(0 < h.i - s.i <= 3 and clause_of(s.i) == clause_of(h.i) for s in src):
                h.source = True

    # --- anaphora: "test it", "teste-la", "7awelha", "حولها"
    anaphora = set()
    hyphen_obj = {m.start(1) for m in re.finditer(r"[^\W\d_]+-(la|le|les|lui|les-moi|moi)\b", norm)}
    for h in hits:
        if h.role not in ROLE_VERB:
            continue
        tok = toks[h.i]
        nxt = toks[h.j] if h.j < n else ""
        suffix = h.suffix or ""
        if nxt in ("it", "them", "la", "le", "les", "lui", "ha", "hom", "hiya") and (nxt != "le" or tokens[h.j][1] in hyphen_obj or tokens[h.j][1] - 1 in hyphen_obj or norm[tokens[h.j][1] - 1] == "-"):
            anaphora.add(h.i)
        elif any(abs(tokens[h.j - 1][2] + 1 - p) <= 1 for p in hyphen_obj):
            anaphora.add(h.i)
        elif not is_arabic(tok) and re.search(r"(ha|hom|hou|ou)$", tok) and len(tok) >= 5 and (h.how.startswith("arabizi") or tn):
            anaphora.add(h.i)
        elif is_arabic(tok) and re.search(r"(ها|هم)$", tok) and len(tok) >= 4:
            anaphora.add(h.i)
        elif is_arabic(tok) and suffix in ("ه", "وه"):
            anaphora.add(h.i)

    content = []
    covered_any = {q for h in hits for q in range(h.i, h.j)}
    for i, tok in enumerate(toks):
        if i in covered_any or tok in idx.stop or tok.isdigit():
            continue
        if (is_arabic(tok) and len(tok) >= 2) or (not is_arabic(tok) and len(tok) >= 3):
            content.append(i)

    tools = []
    for key, spec in idx.lex["tools"].items():
        m = re.search(r"(?<![\w.])" + re.escape(key) + r"(?![\w])", norm)
        if m:
            masked = next((mk["reason"] for mk in masks if mk["start"] <= m.start() < mk["end"]), None)
            tools.append({"tool": key, "label": spec["label"], "intents": spec["intents"], "masked": masked, "pos": m.start()})

    return {"raw": raw, "norm": norm, "tokens": tokens, "langs": langs, "hits": hits, "clauses": clauses,
            "clause_of": clause_of, "masks": masks, "anaphora": anaphora, "content": content, "tools": tools,
            "has_conj": bool(bounds) or bool(punct_pos), "has_seq": bool(seq_at), "index": idx}


# ------------------------------------------------------------------ rules
def evaluate_rules(ctx, keeps=()):
    """Best verb-object evidence per intent. Returns {intent: {"score", "pos", "clause", "evidence"}}.

    Attachment: a verb takes the nearest object after it in its clause (the nearest before it when none
    follows); when that object is generic (app, code) the next one is also considered. Later objects are
    modifiers ("tests for the module", "an image for the site") and do not pair with the verb.
    """
    idx = ctx["index"]
    lex = idx.lex
    hits = ctx["hits"]
    generic_objects = set(lex.get("generic_objects", ["G_APP", "N_CODE", "N_GENERIC_DESIGN"]))
    deliverables = set(lex.get("deliverable_objects", []))
    best = {}
    prev_verbs = []
    for ci, cl in enumerate(ctx["clauses"]):
        for keep_mode in (False, True):
            def visible(h):
                return h.masked is None or (keep_mode and h.masked == "discussion")
            in_cl = [h for h in hits if cl["i"] <= h.i < cl["j"] and visible(h)]
            verbs = [h for h in in_cl if h.role in ROLE_VERB]
            objects = sorted([h for h in in_cl if h.role in ROLE_OBJECT and not h.source], key=lambda h: h.i)
            inherited = implicit = False
            if not verbs and objects and prev_verbs and not cl.get("relative"):
                verbs, inherited = prev_verbs, True
            if not verbs and any(h.concept == "FILLER" for h in in_cl) and any(o.concept in deliverables for o in objects):
                verbs, implicit = [Hit("V_IMPLICIT", "verb", cl["i"], cl["i"], cl["start"], cl["start"], "implicit")], True

            props = [o for o in objects if o.concept in CAUSATIVE_PROPS]

            def attached(v):
                """Objects this verb governs (nearest first)."""
                # "make the endpoint faster" / "rendha asra3": a causative verb with a property object changes a
                # property of what it names; it does not create that thing
                if not (inherited or implicit) and v.concept in CAUSATIVE_VERBS and any(o.i >= v.j for o in props):
                    return [o for o in props if o.i >= v.j][:1]
                if inherited or implicit:
                    pool = objects
                else:
                    after = [o for o in objects if o.i >= v.j]
                    before = [o for o in objects if o.j <= v.i][::-1]
                    pool = after or before
                out = []
                for o in pool:
                    out.append(o)
                    if o.concept not in generic_objects:
                        # same-token objects (one word, two concepts) stay together
                        out += [x for x in pool if x is not o and x.i == o.i and x not in out]
                        break
                return out
            ana = [v for v in verbs if v.i in ctx["anaphora"]]
            other_specific = [o for o in objects if o.concept not in generic_objects]
            content = [q for q in ctx["content"] if cl["i"] <= q < cl["j"] and not any(
                mk["start"] <= ctx["tokens"][q][1] < mk["end"] for mk in ctx["masks"] if not (keep_mode and mk["reason"] == "discussion"))]
            app_hits = [o for o in objects if o.concept == "G_APP"]
            modifier = [q for q in content for a in app_hits if q in (a.i - 1, a.i + 1) or
                        (q == a.i + 2 and a.i + 1 < len(ctx["tokens"]) and ctx["tokens"][a.i + 1][0] in ("de", "mta3", "mte3", "for", "pour", "d"))]
            for rule in lex["rules"]:
                intent = rule["intent"]
                if keep_mode != (intent in keeps):
                    continue
                vset = [v for v in verbs if rule["verbs"] is None or v.concept in rule["verbs"]]
                if rule["verbs"] is not None and not vset:
                    continue
                chosen = None
                if rule["objects"] is None:
                    if rule["verbs"] is None:
                        continue
                    chosen = (vset[0], None, "verb")
                else:
                    for oname in rule["objects"]:
                        if oname == "ANAPHORA":
                            cand = [v for v in vset if v in ana] if rule["verbs"] is not None else []
                            if cand:
                                chosen = (cand[0], cand[0], "anaphora")
                        elif oname == "CONTENT":
                            if content and not other_specific and (rule["verbs"] is None or vset):
                                chosen = (vset[0] if vset else None, None, "content")
                        elif oname == "G_APP+CONTENT":
                            v = next((v for v in vset if any(a in attached(v) for a in app_hits)), None)
                            if modifier and v is not None:
                                chosen = (v, app_hits[0], "generic+modifier")
                        elif oname == "N_CURRENT+N_RESEARCH":
                            cur_o = next((o for o in objects if o.concept == "N_CURRENT"), None)
                            res_o = next((o for o in objects if o.concept == "N_RESEARCH"), None)
                            if cur_o is not None and res_o is not None:
                                chosen = (None, res_o, "current-facts question")
                        elif rule["verbs"] is None:
                            o = next((o for o in objects if o.concept == oname), None)
                            if o is not None:
                                chosen = (None, o, "object")
                        else:
                            for v in vset:
                                o = next((o for o in attached(v) if o.concept == oname), None)
                                if o is not None:
                                    chosen = (v, o, "object")
                                    break
                        if chosen:
                            break
                if not chosen:
                    continue
                v, o, kind = chosen
                w = rule["w"]
                anchor = o if o is not None else v
                pos = anchor.start if anchor is not None else cl["start"]
                vtxt = ctx["norm"][v.start:v.end] if v is not None and v.end > v.start else ("implicit" if implicit else "")
                desc = f"{v.concept if v is not None else '-'}({vtxt}{' inherited' if inherited and v is not None else ''}) + " \
                       f"{(o.concept + '(' + ctx['norm'][o.start:o.end] + ')') if o is not None and o is not v else kind}"
                cur = best.get(intent)
                if cur is None or w > cur["score"] or (w == cur["score"] and pos < cur["pos"]):
                    best[intent] = {"score": w, "pos": pos, "clause": ci, "evidence": desc,
                                    "generic_object": o is not None and o.concept in generic_objects}
        prev_verbs = [h for h in hits if cl["i"] <= h.i < cl["j"] and h.masked is None and h.role == "verb"] or \
            (prev_verbs if not cl.get("relative") and not any(cl["i"] <= h.i < cl["j"] and h.role in ROLE_OBJECT for h in hits) else [])
    return best


def creative_verb_present(ctx, pos=None):
    """A creation/editing verb is present (in the same clause as `pos` when given)."""
    names = set(ctx["index"].lex["creative_verbs"])
    if pos is None:
        return any(h.concept in names and h.masked is None for h in ctx["hits"])
    ti = next((i for i, (_, s, e) in enumerate(ctx["tokens"]) if e > pos), len(ctx["tokens"]) - 1)
    ci = ctx["clause_of"](ti)
    cl = ctx["clauses"][ci]
    return any(h.concept in names and h.masked is None and cl["i"] <= h.i < cl["j"] for h in ctx["hits"])


def masked(ctx, start, end, keep=False):
    for mk in ctx["masks"]:
        if keep and mk["reason"] == "discussion":
            continue
        if mk["start"] <= start < mk["end"] or (start < mk["start"] < end):
            return mk["reason"]
    return None
