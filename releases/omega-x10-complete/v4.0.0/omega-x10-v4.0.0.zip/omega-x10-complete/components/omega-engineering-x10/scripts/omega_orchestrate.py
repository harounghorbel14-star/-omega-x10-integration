#!/usr/bin/env python3
"""Capability-aware orchestration state for multi-step requests. Standard library only.

The router plans; this file keeps an honest ledger while the agent executes:

  omega.py run init "<task>" [--state FILE]   plan the steps, mark BLOCKED ones, skip their dependents
  omega.py run next                           steps whose prerequisites are done and still verified
  omega.py run start N                        mark step N running; prints the verified inputs it may use
  omega.py run done N --artifact PATH [...]   record outputs (must exist, non-empty; sha256 stored)
  omega.py run done N --note "text"           a step with no file output (e.g. an answer given in chat)
  omega.py run fail N --reason "text"         failure; every dependent step becomes SKIPPED
  omega.py run report [--json]                truthful partial-completion summary (exit 3 if incomplete)

Rules enforced here, not left to good intentions:
  * a step starts only when every prerequisite is DONE and its recorded artifacts still match their hashes;
  * a step whose route is BLOCKED never starts; a step that needs a consent-gated connector starts only
    when that connector is in OMEGA_AUTHORIZED;
  * a failed or blocked prerequisite skips its dependents; independent steps continue;
  * nothing here runs tools, calls services or spends credits.
"""
import hashlib
import json
import os
import time
from pathlib import Path

DEFAULT_STATE = ".omega-run.json"
TERMINAL = {"done", "failed", "blocked", "skipped"}


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def _load(state):
    p = Path(state)
    if not p.exists():
        raise SystemExit(f"no run state at {p}; start with: omega.py run init \"<task>\"")
    return json.loads(p.read_text(encoding="utf-8"))


def _save(state, data):
    p = Path(state)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, p)


def _consent_needed(step):
    use = step.get("use", "")
    if use.startswith("connector: "):
        return step.get("connector_key")
    return None


def init(route_result, state=DEFAULT_STATE):
    steps = []
    num = {}
    for k, s in enumerate(route_result.get("steps", []), 1):
        num[s["id"]] = k
    sel = {r["id"]: r for r in route_result.get("selected", [])}
    for k, s in enumerate(route_result.get("steps", []), 1):
        r = sel.get(s["id"], {})
        key = None
        if r.get("use", "").startswith("connector: "):
            name = r["use"].split(": ", 1)[1]
            key = next((o.get("key") for o in r.get("options", []) if o["name"] == name), name.lower())
        steps.append({"n": k, "id": s["id"], "label": s.get("label", s["id"]), "subtask": s.get("subtask", ""),
                      "depends_on": [num[d] for d in s.get("depends_on", []) if d in num],
                      "route_status": s.get("status"), "use": s.get("use"), "limit": r.get("limit"),
                      "connector_key": key, "status": "pending", "artifacts": [], "note": None, "reason": None,
                      "started": None, "finished": None})
    data = {"task": route_result.get("task"), "decision": route_result.get("decision"), "created": time.time(), "steps": steps}
    if route_result.get("decision") == "clarify":
        data["clarify_question"] = route_result.get("clarify_question")
    for st in steps:
        if st["route_status"] == "BLOCKED":
            st["status"], st["reason"] = "blocked", f"route BLOCKED: {st['use']}"
            _skip_dependents(data, st["n"], f"prerequisite step {st['n']} ({st['id']}) is blocked")
    _save(state, data)
    return data


def _skip_dependents(data, n, why):
    changed = True
    dead = {n}
    while changed:
        changed = False
        for st in data["steps"]:
            if st["n"] not in dead and any(d in dead for d in st["depends_on"]) and st["status"] not in ("done",):
                if st["status"] not in ("skipped", "failed", "blocked"):
                    st["status"], st["reason"] = "skipped", why
                dead.add(st["n"])
                changed = True


def _verify(st):
    """Recorded artifacts still exist with the same content."""
    for a in st["artifacts"]:
        p = Path(a["path"])
        if not p.exists():
            return f"artifact missing: {a['path']}"
        if _sha(p) != a["sha256"]:
            return f"artifact changed since step {st['n']} finished: {a['path']}"
    return None


def ready(data):
    out = []
    by_n = {s["n"]: s for s in data["steps"]}
    for st in data["steps"]:
        if st["status"] != "pending":
            continue
        deps = [by_n[d] for d in st["depends_on"]]
        if all(d["status"] == "done" for d in deps):
            out.append(st)
    return out


def start(data, n, state=DEFAULT_STATE, authorized=None):
    by_n = {s["n"]: s for s in data["steps"]}
    st = by_n.get(n)
    if st is None:
        raise SystemExit(f"no step {n}")
    if st["status"] != "pending":
        raise SystemExit(f"step {n} is {st['status']}, not pending")
    for d in st["depends_on"]:
        dep = by_n[d]
        if dep["status"] != "done":
            raise SystemExit(f"step {n} waits for step {d} ({dep['id']}: {dep['status']})")
        problem = _verify(dep)
        if problem:
            dep["status"], dep["reason"] = "failed", problem
            _skip_dependents(data, d, f"prerequisite step {d} failed verification")
            _save(state, data)
            raise SystemExit(f"cannot start step {n}: {problem}")
    key = _consent_needed(st)
    auth = authorized if authorized is not None else {a.strip().lower() for a in os.environ.get("OMEGA_AUTHORIZED", "").split(",") if a.strip()}
    if key and key not in auth:
        raise SystemExit(f"step {n} would use {st['use']}, which needs the user's consent (OMEGA_AUTHORIZED={key})")
    st["status"], st["started"] = "running", time.time()
    _save(state, data)
    return [a for d in st["depends_on"] for a in by_n[d]["artifacts"]]


def done(data, n, artifacts=(), note=None, state=DEFAULT_STATE):
    by_n = {s["n"]: s for s in data["steps"]}
    st = by_n.get(n)
    if st is None or st["status"] != "running":
        raise SystemExit(f"step {n} is not running (status: {st['status'] if st else 'missing'})")
    if not artifacts and not note:
        raise SystemExit("a finished step needs --artifact PATH (verified) or --note describing a non-file result")
    recs = []
    for a in artifacts:
        p = Path(a)
        if not p.is_file() or p.stat().st_size == 0:
            raise SystemExit(f"artifact {a} does not exist or is empty; step {n} is not done")
        recs.append({"path": str(p.resolve()), "sha256": _sha(p), "bytes": p.stat().st_size})
    st["artifacts"], st["note"], st["status"], st["finished"] = recs, note, "done", time.time()
    _save(state, data)
    return st


def fail(data, n, reason, state=DEFAULT_STATE):
    by_n = {s["n"]: s for s in data["steps"]}
    st = by_n.get(n)
    if st is None or st["status"] in TERMINAL:
        raise SystemExit(f"step {n} cannot fail from status {st['status'] if st else 'missing'}")
    st["status"], st["reason"], st["finished"] = "failed", reason, time.time()
    _skip_dependents(data, n, f"prerequisite step {n} ({st['id']}) failed: {reason}")
    _save(state, data)
    return st


def report(data):
    counts = {}
    for st in data["steps"]:
        counts[st["status"]] = counts.get(st["status"], 0) + 1
    total = len(data["steps"])
    complete = total > 0 and counts.get("done", 0) == total
    lines = [f"Task: {data['task']}", f"Steps: {total}  " + "  ".join(f"{k}={v}" for k, v in sorted(counts.items())),
             "Result: COMPLETE" if complete else ("Result: NOT STARTED (clarification needed)" if not total else "Result: PARTIAL - not every step finished")]
    if data.get("clarify_question"):
        lines.append(f"Ask: {data['clarify_question']}")
    for st in data["steps"]:
        dep = f" after {st['depends_on']}" if st["depends_on"] else ""
        lines.append(f"  {st['n']}. {st['id']:<20} {st['status'].upper():<8}{dep}  [{st['route_status']}] {st['use']}")
        for a in st["artifacts"]:
            lines.append(f"       artifact {a['path']} ({a['bytes']} B, sha256 {a['sha256'][:12]}...)")
        if st["note"]:
            lines.append(f"       note: {st['note']}")
        if st["reason"]:
            lines.append(f"       reason: {st['reason']}")
        if st.get("limit"):
            lines.append(f"       limit: {st['limit']}")
    return {"complete": complete, "counts": counts, "text": "\n".join(lines)}
