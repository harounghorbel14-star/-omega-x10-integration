#!/usr/bin/env python3
"""Train the OMEGA X10 contextual classifier (registry/classifier.json) from DEVELOPMENT data only.

Development-time tool: needs numpy + scikit-learn (inference in omega_classify.py is standard library only).
Deterministic: fixed data order, lbfgs solver, no randomness in training; cross-validation folds are fixed by id hash.

  python3 omega_train.py --data ../tests/corpus/dev.jsonl ... --out ../registry/classifier.json
  python3 omega_train.py --data ... --cv 5          # report k-fold exact match for a grid of settings

Never pass a validation or blind set to --data. The trainer refuses files whose name contains "val" or "blind4"
unless --allow-name is given for a deliberately retired set (the Phase 3 blind set is retired to development data).
"""
import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
os.environ["OMEGA_CLASSIFIER"] = "off"  # features use the rule layer only

import omega  # noqa: E402
import omega_classify as cl  # noqa: E402

TRAIN_INTENTS = ["implementation", "debugging", "tdd", "code-review", "security", "ui-ux-design", "web-research", "image",
                 "video-animation", "3d", "browser-automation", "deployment-release", "performance", "planning", "documents",
                 "repository-architecture", "app-replication", "git-workflow"]
HEADS = TRAIN_INTENTS + ["out:" + o for o in cl.OUTCOMES]


def load_cases(paths, allow):
    cases = []
    for p in paths:
        p = Path(p)
        if ("val" in p.name or "blind4" in p.name) and p.name not in allow:
            raise SystemExit(f"refusing held-out-looking file {p}: training uses development data only")
        if p.suffix == ".jsonl":
            for line in p.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    cases.append(json.loads(line))
        else:  # Phase 2 bench format
            for c in json.loads(p.read_text(encoding="utf-8"))["cases"]:
                exp = c["expect"]
                if exp and exp[0] in ("none", "clarify"):
                    cases.append({"id": c["id"], "prompt": c["prompt"], "expect": [exp[0]], "optional": []})
                    continue
                req = c.get("include") or exp[:1]
                cases.append({"id": c["id"], "prompt": c["prompt"], "expect": [list(req)],
                              "optional": sorted(set(exp) - set(req)), "forbid": c.get("forbid", [])})
    return cases


def targets(case):
    """y[h] in {0,1} and mask[h] in {0,1} (0 = not penalised either way)."""
    exp = case["expect"]
    first = exp[0]
    y = {h: 0 for h in HEADS}
    m = {h: 1 for h in HEADS}
    outcome = "route" if isinstance(first, list) else first
    y["out:" + outcome] = 1
    for o in exp[1:]:
        oo = "route" if isinstance(o, list) else o
        if oo != outcome:
            m["out:" + oo] = 0
    if isinstance(first, list):
        for i in first:
            if i in y:
                y[i] = 1
    for o in exp[1:]:
        if isinstance(o, list):
            for i in o:
                if i in m and not y[i]:
                    m[i] = 0
    for i in case.get("optional", []):
        if i in m and not y[i]:
            m[i] = 0
    return y, m


def featurise(cases):
    rows = []
    for c in cases:
        reg, th, lang, ctx, ranking, _ = omega._rule_layer(c["prompt"])
        rows.append(cl.features(ctx, {r["id"]: r["score"] for r in ranking}, lang))
    return rows


def fit(rows, ys, ms, C, min_df):  # noqa: C901
    import numpy as np
    from scipy.sparse import csr_matrix
    from sklearn.linear_model import LogisticRegression
    df = {}
    for r in rows:
        for k in r:
            df[k] = df.get(k, 0) + 1
    vocab = sorted(k for k, n in df.items() if n >= min_df and k != "bias")
    index = {k: i for i, k in enumerate(vocab)}
    data, ri, ci = [], [], []
    for n, r in enumerate(rows):
        for k, v in r.items():
            j = index.get(k)
            if j is not None:
                data.append(v)
                ri.append(n)
                ci.append(j)
    X = csr_matrix((data, (ri, ci)), shape=(len(rows), len(vocab)))
    W = np.zeros((len(vocab), len(HEADS)))
    b = np.zeros(len(HEADS))
    for h, head in enumerate(HEADS):
        y = np.array([t[head] for t in ys])
        sw = np.array([m[head] for m in ms], dtype=float)
        if y[sw > 0].sum() == 0 or y[sw > 0].sum() == (sw > 0).sum():
            b[h] = -6.0 if y[sw > 0].sum() == 0 else 6.0
            continue
        clf = LogisticRegression(C=C, solver="lbfgs", max_iter=2000, class_weight=None)
        clf.fit(X, y, sample_weight=sw)
        W[:, h] = clf.coef_[0]
        b[h] = clf.intercept_[0]
    weights = {}
    for j, k in enumerate(vocab):
        row = [[h, round(float(W[j, h]), 3)] for h in range(len(HEADS)) if abs(W[j, h]) >= PRUNE]
        if row:
            weights[k] = row
    return {"format": "omega-classifier/1", "heads": HEADS, "bias": [round(float(x), 4) for x in b], "weights": weights}


PRUNE = 0.02  # weights below this magnitude are dropped (model size; measured no accuracy change on validation)
DEFAULT_POLICY = {"tau": 0.5, "tau_low": 0.3, "tau_override": 0.85}


def decide(p, pol):
    out = {o: p["out:" + o] for o in cl.OUTCOMES}
    intents = {h: v for h, v in p.items() if not h.startswith("out:")}
    taus = pol.get("tau_i", {})
    chosen = [h for h, v in sorted(intents.items(), key=lambda x: -x[1]) if v >= taus.get(h, pol["tau"])]
    best = max(out, key=out.get)
    if best == "route" or (chosen and intents[chosen[0]] >= pol["tau_override"]):
        if not chosen:
            top = max(intents, key=intents.get)
            if intents[top] >= pol["tau_low"]:
                chosen = [top]
        if chosen:
            return "plan", set(chosen)
        return ("clarify" if out["clarify"] >= out["none"] else "none"), set()
    return best, set()


def exact(case, dec, chosen):
    for o in case["expect"]:
        if isinstance(o, str):
            if dec == o:
                return True
        elif dec == "plan":
            req = set(o)
            if req <= chosen <= req | set(case.get("optional", [])):
                return True
    return False


def fold_of(cid, k):
    return int(hashlib.sha256(cid.encode()).hexdigest(), 16) % k


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", nargs="+", required=True)
    ap.add_argument("--allow-name", nargs="*", default=[])
    ap.add_argument("--out")
    ap.add_argument("--cv", type=int, default=0)
    ap.add_argument("--C", type=float, nargs="+", default=[4.0])
    ap.add_argument("--min-df", type=int, default=2)
    ap.add_argument("--policy", default=json.dumps(DEFAULT_POLICY))
    a = ap.parse_args(argv)
    cases = load_cases(a.data, set(a.allow_name))
    ids = [c["id"] for c in cases]
    assert len(ids) == len(set(ids)), "duplicate ids in training data"
    rows = featurise(cases)
    tm = [targets(c) for c in cases]
    ys, ms = [t[0] for t in tm], [t[1] for t in tm]
    pol = json.loads(a.policy)
    if a.cv:
        for C in a.C:
            preds = [None] * len(cases)
            for f in range(a.cv):
                tr = [i for i in range(len(cases)) if fold_of(ids[i], a.cv) != f]
                te = [i for i in range(len(cases)) if fold_of(ids[i], a.cv) == f]
                m = fit([rows[i] for i in tr], [ys[i] for i in tr], [ms[i] for i in tr], C, a.min_df)
                for i in te:
                    preds[i] = cl.predict(rows[i], m)
            grid = []
            for tau in (0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6):
                for tl in (0.15, 0.2, 0.3):
                    for to in (0.7, 0.8, 0.9, 1.01):
                        pp = {"tau": tau, "tau_low": min(tl, tau), "tau_override": to}
                        ok = sum(exact(c, *decide(preds[i], pp)) for i, c in enumerate(cases))
                        grid.append((ok, pp))
            grid.sort(key=lambda g: -g[0])
            best_pol = dict(grid[0][1])
            best_pol["tau_i"] = {}
            score = grid[0][0]
            for _round in range(2):
                for h in TRAIN_INTENTS:
                    for t in (0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7):
                        trial = dict(best_pol, tau_i=dict(best_pol["tau_i"], **{h: t}))
                        ok = sum(exact(c, *decide(preds[i], trial)) for i, c in enumerate(cases))
                        if ok > score:
                            score, best_pol = ok, trial
            print(f"  per-intent taus: cv {score}/{len(cases)} ({score/len(cases):.1%}) {json.dumps(best_pol)}")
            ok_default = sum(exact(c, *decide(preds[i], pol)) for i, c in enumerate(cases))
            print(f"C={C}: cv exact {ok_default}/{len(cases)} ({ok_default/len(cases):.1%}) with policy {pol}; "
                  f"best {grid[0][0]}/{len(cases)} ({grid[0][0]/len(cases):.1%}) {grid[0][1]}")
            if a.out is None:
                json.dump({"C": C, "grid_top": grid[:5]}, sys.stdout)
                print()
    if a.out:
        m = fit(rows, ys, ms, a.C[0], a.min_df)
        m["policy"] = pol
        digest = hashlib.sha256()
        for p in a.data:
            digest.update(Path(p).read_bytes())
        m["trained_on"] = {"files": [Path(p).name for p in a.data], "n": len(cases), "data_sha256": digest.hexdigest(),
                           "C": a.C[0], "min_df": a.min_df,
                           "rules_fingerprint": hashlib.sha256(b"".join((HERE / n).read_bytes() for n in ("omega.py", "omega_lang.py")) +
                                                               b"".join((HERE.parent / "registry" / n).read_bytes() for n in ("intents.json", "lexicon.json"))).hexdigest()}
        Path(a.out).write_text(json.dumps(m, ensure_ascii=False, separators=(",", ":"), sort_keys=True), encoding="utf-8")
        print(f"wrote {a.out}: {len(m['weights'])} features x {len(HEADS)} heads, n={len(cases)}")


if __name__ == "__main__":
    main()
