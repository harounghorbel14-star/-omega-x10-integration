#!/usr/bin/env python3
"""OMEGA X10 v4 workflow engine: validated DAG specs, a real executor and an integrity ledger. Standard library only.

A workflow spec (JSON) lists steps. Each step declares:
  id                 unique identifier ([A-Za-z0-9_.-], <= 64 chars)
  action             what the step does (free text, shown in reports)
  capability         the capability it needs (e.g. "tdd", "tool:pytest"); checked against the available set
  fallback_capability, fallback_command   optional degraded path -> status LIMITED
  prerequisites      step ids that must be COMPLETE (and still verified) before this step starts
  inputs             {name: "step-id.output-name"}  explicit references to verified outputs of prerequisites
  command            argv list (never a shell string); placeholders {in:NAME} {out:NAME} {workdir} {python}
  outputs            {name: {"path": "relative/path", "validate": {...}}}  validated after every attempt
  evidence           {"stdout_contains": "..."} for a step without file outputs (exit code alone never suffices)
  retry              {"max_attempts": 1..5}        bounded; every attempt is recorded
  timeout_s          0 < t <= 3600 (default 60)
  requires_confirmation  false | "destructive" | "external" | "financial" | "publishing" | "deployment"
  optional           true -> a missing capability SKIPS the step and dependents continue without its outputs

Validators: exists, min_bytes, max_bytes, type (text|json|png|jpeg|gif|mp4|zip|pdf|svg|html|csv), json_keys,
contains, not_contains, regex, sha256, utf8.

Statuses: per step READY, LIMITED, BLOCKED, RUNNING, COMPLETE, FAILED, SKIPPED (+ PENDING before planning);
per workflow COMPLETE, PARTIAL, FAILED, BLOCKED.

  omega_workflow.py validate SPEC
  omega_workflow.py run SPEC --workdir DIR [--capabilities a,b] [--confirm step1,step2] [--resume] [--json]
  omega_workflow.py status --workdir DIR [--json]
  omega_workflow.py from-route "<task>" [--out SPEC]     skeleton spec from the router's plan (no commands)

Exit codes: 0 COMPLETE, 2 invalid spec/usage, 3 PARTIAL, 4 FAILED, 5 BLOCKED.
Nothing here deploys, publishes or spends credits by itself: it runs only the argv commands written in the spec,
and steps marked requires_confirmation run only when their id is passed in --confirm (or OMEGA_CONFIRM).
"""
import argparse
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path

LEDGER = ".omega-ledger.json"
STEP_STATUSES = ("PENDING", "READY", "LIMITED", "BLOCKED", "RUNNING", "COMPLETE", "FAILED", "SKIPPED")
TERMINAL = {"COMPLETE", "FAILED", "SKIPPED", "BLOCKED"}
CONFIRM_KINDS = {"destructive", "external", "financial", "publishing", "deployment"}
ID_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
MAGIC = {"png": b"\x89PNG\r\n\x1a\n", "jpeg": b"\xff\xd8\xff", "gif": b"GIF8", "zip": b"PK\x03\x04", "pdf": b"%PDF-"}
SECRET_RE = re.compile(r"(?i)(api[_-]?key|token|secret|password|passwd|authorization)(\s*[:=]\s*|\s+)(\S+)")
EXIT = {"COMPLETE": 0, "PARTIAL": 3, "FAILED": 4, "BLOCKED": 5}
MAX_LOG = 2000


class SpecError(ValueError):
    pass


# ------------------------------------------------------------------ helpers
def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def redact(text):
    return SECRET_RE.sub(lambda m: m.group(1) + m.group(2) + "[REDACTED]", text or "")


def _tail(b):
    s = b.decode("utf-8", "replace") if isinstance(b, (bytes, bytearray)) else (b or "")
    return redact(s[-MAX_LOG:])


def _now():
    return round(time.time(), 3)


def _safe_rel(path, workdir):
    """Resolve a spec path inside workdir; reject absolute paths and traversal (.., symlinks out)."""
    if not isinstance(path, str) or not path or os.path.isabs(path) or "\x00" in path:
        raise SpecError(f"output path must be a non-empty relative path: {path!r}")
    full = (Path(workdir) / path).resolve()
    root = Path(workdir).resolve()
    if full != root and root not in full.parents:
        raise SpecError(f"output path escapes the workdir: {path!r}")
    return full


# ------------------------------------------------------------------ spec validation
def validate_spec(spec):
    """Return (steps_by_id, topological order). Raises SpecError listing every problem found."""
    problems = []
    if not isinstance(spec, dict) or not isinstance(spec.get("steps"), list) or not spec["steps"]:
        raise SpecError("spec must be an object with a non-empty 'steps' list")
    by_id = {}
    for k, st in enumerate(spec["steps"]):
        if not isinstance(st, dict):
            problems.append(f"step #{k + 1} is not an object")
            continue
        sid = st.get("id")
        if not isinstance(sid, str) or not ID_RE.match(sid):
            problems.append(f"step #{k + 1}: invalid id {sid!r}")
            continue
        if sid in by_id:
            problems.append(f"duplicate step id {sid!r}")
            continue
        by_id[sid] = st
    for sid, st in by_id.items():
        pre = st.get("prerequisites", [])
        if not isinstance(pre, list) or not all(isinstance(p, str) for p in pre):
            problems.append(f"{sid}: prerequisites must be a list of step ids")
            pre = []
        for p in pre:
            if p not in by_id:
                problems.append(f"{sid}: unknown prerequisite {p!r}")
            if p == sid:
                problems.append(f"{sid}: depends on itself")
        cmd = st.get("command")
        if cmd is not None and (not isinstance(cmd, list) or not cmd or not all(isinstance(c, str) for c in cmd)):
            problems.append(f"{sid}: command must be a non-empty argv list of strings (no shell strings)")
        fcmd = st.get("fallback_command")
        if fcmd is not None and (not isinstance(fcmd, list) or not fcmd or not all(isinstance(c, str) for c in fcmd)):
            problems.append(f"{sid}: fallback_command must be an argv list")
        outs = st.get("outputs", {})
        if not isinstance(outs, dict):
            problems.append(f"{sid}: outputs must be an object")
            outs = {}
        for name, o in outs.items():
            if not isinstance(o, dict) or not isinstance(o.get("path"), str):
                problems.append(f"{sid}: output {name!r} needs a 'path'")
                continue
            p = o["path"]
            if os.path.isabs(p) or ".." in Path(p).parts or "\x00" in p:
                problems.append(f"{sid}: output {name!r} path must stay inside the workdir: {p!r}")
        if cmd is not None and not outs and not st.get("evidence"):
            problems.append(f"{sid}: declares no outputs and no evidence; exit code 0 alone cannot prove completion")
        for name, ref in (st.get("inputs") or {}).items():
            if not isinstance(ref, str) or ref.count(".") < 1:
                problems.append(f"{sid}: input {name!r} must reference 'step-id.output-name'")
                continue
            src, out = ref.rsplit(".", 1)
            if src not in by_id:
                problems.append(f"{sid}: input {name!r} references unknown step {src!r}")
            elif src not in pre:
                problems.append(f"{sid}: input {name!r} uses {src!r} which is not a prerequisite")
            elif out not in (by_id[src].get("outputs") or {}):
                problems.append(f"{sid}: input {name!r} references undeclared output {ref!r}")
        r = st.get("retry", {"max_attempts": 1})
        if not isinstance(r, dict) or not isinstance(r.get("max_attempts", 1), int) or not 1 <= r.get("max_attempts", 1) <= 5:
            problems.append(f"{sid}: retry.max_attempts must be an integer 1..5")
        t = st.get("timeout_s", 60)
        if not isinstance(t, (int, float)) or not 0 < t <= 3600:
            problems.append(f"{sid}: timeout_s must be in (0, 3600]")
        rc = st.get("requires_confirmation", False)
        if rc not in (False, None) and rc not in CONFIRM_KINDS:
            problems.append(f"{sid}: requires_confirmation must be false or one of {sorted(CONFIRM_KINDS)}")
    order, cycle = _toposort(by_id)
    if cycle:
        problems.append("dependency cycle: " + " -> ".join(cycle))
    for d in spec.get("final_deliverables", []) or []:
        if not isinstance(d, str) or "." not in d or d.rsplit(".", 1)[0] not in by_id:
            problems.append(f"final deliverable {d!r} must reference 'step-id.output-name'")
    if problems:
        raise SpecError("; ".join(problems))
    return by_id, order


def _toposort(by_id):
    """Kahn's algorithm, stable by declaration order. Returns (order, cycle_path_or_None)."""
    ids = list(by_id)
    indeg = {s: 0 for s in ids}
    for s in ids:
        for p in by_id[s].get("prerequisites", []) or []:
            if p in by_id:
                indeg[s] += 1
    order, ready = [], [s for s in ids if indeg[s] == 0]
    while ready:
        s = ready.pop(0)
        order.append(s)
        for t in ids:
            if s in (by_id[t].get("prerequisites", []) or []):
                indeg[t] -= 1
                if indeg[t] == 0:
                    ready.append(t)
    if len(order) == len(ids):
        return order, None
    left = [s for s in ids if s not in order]
    # find one concrete cycle path for the message
    path, seen, cur = [], set(), left[0]
    while cur not in seen:
        seen.add(cur)
        path.append(cur)
        cur = next(p for p in by_id[cur].get("prerequisites", []) if p in left)
    return order, path[path.index(cur):] + [cur]


def levels(by_id, order):
    """Parallelisable groups: steps in the same level have no dependency between them."""
    lvl = {}
    for s in order:
        pre = [p for p in by_id[s].get("prerequisites", []) or []]
        lvl[s] = 1 + max((lvl[p] for p in pre), default=-1)
    out = {}
    for s in order:
        out.setdefault(lvl[s], []).append(s)
    return [out[k] for k in sorted(out)]


# ------------------------------------------------------------------ output validation
def validate_output(path, rules):
    """Return None when the file satisfies every rule, else the first failure."""
    p = Path(path)
    rules = rules or {}
    if not p.is_file():
        return f"missing: {p.name}"
    size = p.stat().st_size
    if size < rules.get("min_bytes", 1):
        return f"{p.name}: {size} bytes < min_bytes {rules.get('min_bytes', 1)}"
    if "max_bytes" in rules and size > rules["max_bytes"]:
        return f"{p.name}: {size} bytes > max_bytes {rules['max_bytes']}"
    data = p.read_bytes()
    kind = rules.get("type")
    if kind in MAGIC and not data.startswith(MAGIC[kind]):
        return f"{p.name}: not a valid {kind} file (bad signature)"
    if kind == "mp4" and data[4:8] != b"ftyp":
        return f"{p.name}: not a valid mp4 (no ftyp box)"
    text = None
    if kind in ("text", "json", "svg", "html", "csv") or any(k in rules for k in ("contains", "not_contains", "regex", "json_keys", "utf8")):
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            return f"{p.name}: not valid UTF-8 text"
    if kind == "json" or "json_keys" in rules:
        try:
            obj = json.loads(text)
        except ValueError as exc:
            return f"{p.name}: invalid JSON ({exc})"
        missing = [k for k in rules.get("json_keys", []) if not isinstance(obj, dict) or k not in obj]
        if missing:
            return f"{p.name}: JSON missing keys {missing}"
    if kind == "svg" and "<svg" not in text:
        return f"{p.name}: no <svg> element"
    if kind == "html" and "<html" not in text.lower() and "<!doctype" not in text.lower():
        return f"{p.name}: not an HTML document"
    if kind == "csv" and (not text.strip() or "," not in text.splitlines()[0]):
        return f"{p.name}: not CSV (no comma in header)"
    for c in ([rules["contains"]] if isinstance(rules.get("contains"), str) else rules.get("contains", [])):
        if c not in text:
            return f"{p.name}: does not contain {c!r}"
    for c in ([rules["not_contains"]] if isinstance(rules.get("not_contains"), str) else rules.get("not_contains", [])):
        if c in text:
            return f"{p.name}: contains forbidden {c!r}"
    if "regex" in rules:
        try:
            if not re.search(rules["regex"], text):
                return f"{p.name}: does not match {rules['regex']!r}"
        except re.error as exc:
            return f"{p.name}: invalid validation regex ({exc})"
    if "sha256" in rules and sha256(p) != rules["sha256"]:
        return f"{p.name}: sha256 mismatch"
    return None


# ------------------------------------------------------------------ ledger
def _ledger_path(workdir):
    return Path(workdir) / LEDGER


def load_ledger(workdir):
    p = _ledger_path(workdir)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise SpecError(f"ledger {p} is corrupted ({exc}); move it aside to start over") from exc


def save_ledger(workdir, led):
    p = _ledger_path(workdir)
    tmp = p.with_name(p.name + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(led, indent=1, ensure_ascii=False, sort_keys=True), encoding="utf-8")
    os.replace(tmp, p)


def _event(led, sid, kind, **kw):
    led["events"].append({"t": _now(), "step": sid, "event": kind, **kw})


# ------------------------------------------------------------------ planning (capabilities and confirmation)
def plan(spec, capabilities, confirmed, led):
    by_id, order = validate_spec(spec)
    caps = set(capabilities)
    for sid in order:
        st, rec = by_id[sid], led["steps"][sid]
        if rec["status"] in TERMINAL or rec["status"] == "RUNNING":
            continue
        need = st.get("capability")
        mode = "primary"
        if need and need not in caps:
            fb = st.get("fallback_capability")
            if fb and fb in caps and st.get("fallback_command"):
                mode = "fallback"
            elif st.get("optional"):
                _set(led, sid, "SKIPPED", reason=f"optional capability {need!r} not available")
                continue
            else:
                _set(led, sid, "BLOCKED", reason=f"required capability {need!r} not available")
                continue
        rc = st.get("requires_confirmation")
        if rc and sid not in confirmed:
            _set(led, sid, "BLOCKED", reason=f"needs explicit confirmation ({rc}); re-run with --confirm {sid}")
            continue
        _set(led, sid, "LIMITED" if mode == "fallback" else "READY",
             reason=f"fallback {st.get('fallback_capability')!r} instead of {need!r}" if mode == "fallback" else None)
        rec["mode"] = mode
    _propagate(by_id, order, led)
    return by_id, order


def _set(led, sid, status, reason=None):
    rec = led["steps"][sid]
    if rec["status"] != status or rec.get("reason") != reason:
        rec["status"], rec["reason"] = status, reason
        _event(led, sid, "status", status=status, reason=reason)


def _blocking(by_id, led, sid):
    """The first prerequisite that prevents sid from ever running, or None."""
    for p in by_id[sid].get("prerequisites", []) or []:
        ps = led["steps"][p]
        if ps["status"] in ("FAILED", "BLOCKED"):
            return p, ps["status"]
        if ps["status"] == "SKIPPED" and not by_id[p].get("optional"):
            return p, "SKIPPED"
    return None


def _propagate(by_id, order, led):
    for sid in order:
        rec = led["steps"][sid]
        if rec["status"] in ("READY", "LIMITED", "PENDING"):
            b = _blocking(by_id, led, sid)
            if b:
                _set(led, sid, "SKIPPED", reason=f"prerequisite {b[0]} is {b[1]}")


# ------------------------------------------------------------------ execution
def _subst(argv, inputs, outputs, workdir, dropped=()):
    """Fill placeholders. An argument naming an input from a skipped optional step is removed, together with
    a directly preceding --flag, so the tool runs without that input instead of receiving a dangling path."""
    out = []
    for a in argv:
        if any("{in:" + d + "}" in a for d in dropped):
            if out and out[-1].startswith("--"):
                out.pop()
            continue
        a = a.replace("{workdir}", str(workdir)).replace("{python}", sys.executable)
        for k, v in inputs.items():
            a = a.replace("{in:" + k + "}", v)
        for k, v in outputs.items():
            a = a.replace("{out:" + k + "}", v)
        if re.search(r"\{(in|out):[^}]+\}", a):
            raise SpecError(f"unresolved placeholder in argument {a!r}")
        out.append(a)
    return out


def _verify_artifacts(rec):
    for a in rec.get("artifacts", {}).values():
        p = Path(a["path"])
        if not p.is_file():
            return f"artifact missing: {p.name}"
        if sha256(p) != a["sha256"]:
            return f"artifact changed after completion: {p.name}"
    return None


def _reset_downstream(by_id, order, led, sid, why):
    """A producer must re-run: it and everything that consumed its outputs go back to PENDING."""
    dirty = {sid}
    for s in order:
        if s in dirty or any(p in dirty for p in by_id[s].get("prerequisites", []) or []):
            dirty.add(s)
            rec = led["steps"][s]
            if rec["status"] in ("COMPLETE", "SKIPPED", "FAILED"):
                rec["artifacts"], rec["attempts"] = {}, 0  # history is kept; the retry budget starts again
                _set(led, s, "PENDING", reason=why if s == sid else f"upstream {sid} re-runs")


def run_step(st, rec, by_id, led, workdir, env):
    inputs, dropped = {}, set()
    for name, ref in (st.get("inputs") or {}).items():
        src, out = ref.rsplit(".", 1)
        srec = led["steps"][src]
        if srec["status"] == "SKIPPED" and by_id[src].get("optional"):
            dropped.add(name)
            continue
        inputs[name] = srec["artifacts"][out]["path"]
    outputs = {name: str(_safe_rel(o["path"], workdir)) for name, o in (st.get("outputs") or {}).items()}
    argv = st.get("fallback_command") if rec.get("mode") == "fallback" else st.get("command")
    if argv is None:
        _set(led, st["id"], "BLOCKED", reason="no command: this step is performed by the agent; record it with the run ledger instead")
        return
    argv = _subst(argv, inputs, outputs, workdir, dropped)
    max_attempts = (st.get("retry") or {}).get("max_attempts", 1)
    timeout = st.get("timeout_s", 60)
    while rec["attempts"] < max_attempts:
        rec["attempts"] += 1
        for o in outputs.values():  # stale outputs from an earlier attempt can never satisfy validation
            Path(o).parent.mkdir(parents=True, exist_ok=True)
            if Path(o).exists():
                Path(o).unlink()
        _set(led, st["id"], "RUNNING", reason=f"attempt {rec['attempts']}/{max_attempts}")
        save_ledger(workdir, led)
        t0 = time.time()
        att = {"n": rec["attempts"], "argv": [redact(a) for a in argv], "started": _now()}
        try:
            proc = subprocess.run(argv, cwd=workdir, env=env, capture_output=True, timeout=timeout, check=False)  # noqa: S603 - argv list, no shell
            att.update(exit_code=proc.returncode, stdout=_tail(proc.stdout), stderr=_tail(proc.stderr))
            problem = None if proc.returncode == 0 else f"exit code {proc.returncode}"
        except subprocess.TimeoutExpired as exc:
            att.update(exit_code=None, stdout=_tail(exc.stdout), stderr=_tail(exc.stderr), timeout=True)
            problem = f"timed out after {timeout}s"
        except OSError as exc:
            att.update(exit_code=None, error=f"{exc.__class__.__name__}: {exc}")
            problem = f"could not start: {exc.__class__.__name__}"
        att["duration_s"] = round(time.time() - t0, 3)
        if problem is None:
            for name, o in (st.get("outputs") or {}).items():
                problem = validate_output(outputs[name], o.get("validate"))
                if problem:
                    problem = f"output {name!r} invalid: {problem}"
                    break
        if problem is None and st.get("evidence", {}).get("stdout_contains"):
            if st["evidence"]["stdout_contains"] not in att.get("stdout", ""):
                problem = f"stdout lacks required evidence {st['evidence']['stdout_contains']!r}"
        att["result"] = "ok" if problem is None else problem
        rec["history"].append(att)
        if problem is None:
            rec["artifacts"] = {name: {"path": outputs[name], "sha256": sha256(outputs[name]),
                                       "bytes": Path(outputs[name]).stat().st_size} for name in outputs}
            rec["exit_code"] = att["exit_code"]
            rec["finished"] = _now()
            _set(led, st["id"], "COMPLETE", reason="fallback path" if rec.get("mode") == "fallback" else None)
            return
        _event(led, st["id"], "attempt_failed", problem=problem)
    rec["exit_code"] = rec["history"][-1].get("exit_code") if rec["history"] else None
    _set(led, st["id"], "FAILED", reason=rec["history"][-1]["result"] if rec["history"] else "no attempt")


def new_ledger(spec, spec_bytes):
    return {"format": "omega-ledger/1", "spec_sha256": hashlib.sha256(spec_bytes).hexdigest(), "name": spec.get("name"),
            "created": _now(), "events": [],
            "steps": {st["id"]: {"status": "PENDING", "reason": None, "attempts": 0, "history": [], "artifacts": {},
                                 "exit_code": None, "mode": None, "finished": None} for st in spec["steps"]}}


def execute(spec_path, workdir, capabilities=(), confirmed=(), resume=False, env=None):
    spec_bytes = Path(spec_path).read_bytes()
    try:
        spec = json.loads(spec_bytes)
    except ValueError as exc:
        raise SpecError(f"spec is not valid JSON: {exc}") from exc
    by_id, order = validate_spec(spec)
    workdir = Path(workdir).resolve()
    workdir.mkdir(parents=True, exist_ok=True)
    led = load_ledger(workdir) if resume else None
    if led is not None and led.get("spec_sha256") != hashlib.sha256(spec_bytes).hexdigest():
        raise SpecError("the spec changed since this run started; start a new workdir (results would not be traceable)")
    if led is None:
        led = new_ledger(spec, spec_bytes)
    else:
        _event(led, None, "resume")
        for sid in order:  # interrupted or stale steps are redone, never trusted
            rec = led["steps"][sid]
            if rec["status"] == "RUNNING":
                rec["artifacts"], rec["attempts"] = {}, 0  # an interruption is not a tool failure
                _set(led, sid, "PENDING", reason="interrupted while running; re-run")
            elif rec["status"] == "COMPLETE":
                problem = _verify_artifacts(rec)
                if problem:
                    _reset_downstream(by_id, order, led, sid, f"stale: {problem}")
            elif rec["status"] in ("BLOCKED", "SKIPPED", "FAILED"):
                rec["attempts"] = 0 if rec["status"] != "FAILED" else rec["attempts"]
                if rec["status"] != "FAILED":
                    _set(led, sid, "PENDING", reason="re-planned on resume")
    run_env = {k: v for k, v in (env if env is not None else os.environ).items()
               if k in ("PATH", "HOME", "LANG", "LC_ALL", "PYTHONPATH", "SYSTEMROOT", "TMPDIR", "TEMP", "TMP") or k.startswith("OMEGA_FAKE")}
    plan(spec, capabilities, set(confirmed), led)
    save_ledger(workdir, led)
    for sid in order:
        rec = led["steps"][sid]
        if rec["status"] not in ("READY", "LIMITED"):
            continue
        b = _blocking(by_id, led, sid)
        if b:
            _set(led, sid, "SKIPPED", reason=f"prerequisite {b[0]} is {b[1]}")
            continue
        stale = None
        for p in by_id[sid].get("prerequisites", []) or []:
            if led["steps"][p]["status"] == "COMPLETE":
                stale = _verify_artifacts(led["steps"][p])
                if stale:
                    _set(led, p, "FAILED", reason=f"integrity check before {sid}: {stale}")
                    break
        if stale:
            _propagate(by_id, order, led)
            save_ledger(workdir, led)
            continue
        run_step(by_id[sid], rec, by_id, led, workdir, run_env)
        _propagate(by_id, order, led)
        save_ledger(workdir, led)
    summary = summarise(spec, by_id, order, led)
    led["summary"] = summary
    save_ledger(workdir, led)
    return summary, led


def summarise(spec, by_id, order, led):
    counts = {}
    for sid in order:
        counts[led["steps"][sid]["status"]] = counts.get(led["steps"][sid]["status"], 0) + 1
    required = [s for s in order if not by_id[s].get("optional")]
    done_req = [s for s in required if led["steps"][s]["status"] == "COMPLETE"]
    deliver_problems = []
    for ref in spec.get("final_deliverables", []) or []:
        src, out = ref.rsplit(".", 1)
        rec = led["steps"][src]
        art = rec["artifacts"].get(out)
        if rec["status"] != "COMPLETE" or not art:
            deliver_problems.append(f"{ref}: not produced")
            continue
        rules = by_id[src]["outputs"][out].get("validate")
        problem = validate_output(art["path"], rules) or (None if sha256(art["path"]) == art["sha256"] else "changed after completion")
        if problem:
            deliver_problems.append(f"{ref}: {problem}")
    ran = any(led["steps"][s]["history"] for s in order)
    if len(done_req) == len(required) and not deliver_problems:
        status = "COMPLETE"
    elif done_req:
        status = "PARTIAL"
    elif any(led["steps"][s]["status"] == "FAILED" for s in order) or ran:
        status = "FAILED"
    else:
        status = "BLOCKED"
    return {"status": status, "counts": counts, "required": len(required), "complete_required": len(done_req),
            "deliverable_problems": deliver_problems, "levels": levels(by_id, order),
            "steps": [{"id": s, "status": led["steps"][s]["status"], "reason": led["steps"][s]["reason"],
                       "attempts": led["steps"][s]["attempts"], "exit_code": led["steps"][s]["exit_code"],
                       "artifacts": {k: {"sha256": v["sha256"], "bytes": v["bytes"], "path": v["path"]}
                                     for k, v in led["steps"][s]["artifacts"].items()}} for s in order]}


def render(summary):
    lines = [f"Workflow: {summary['status']}  ({summary['complete_required']}/{summary['required']} required steps complete)  "
             + "  ".join(f"{k}={v}" for k, v in sorted(summary["counts"].items()))]
    for s in summary["steps"]:
        ex = "" if s["exit_code"] is None else f" exit={s['exit_code']}"
        lines.append(f"  {s['id']:<24} {s['status']:<9} attempts={s['attempts']}{ex}" + (f"  - {s['reason']}" if s["reason"] else ""))
        for k, a in s["artifacts"].items():
            lines.append(f"      {k}: {Path(a['path']).name} {a['bytes']} B sha256 {a['sha256'][:16]}")
    for p in summary["deliverable_problems"]:
        lines.append(f"  deliverable problem: {p}")
    lines.append("  parallel groups: " + " | ".join(",".join(g) for g in summary["levels"]))
    return "\n".join(lines)


# ------------------------------------------------------------------ router bridge
CONFIRM_BY_INTENT = {"deployment-release": "deployment", "git-workflow": "publishing", "browser-automation": "external"}


def from_route(res):
    """Skeleton spec from a router result: ids, capabilities, prerequisites, confirmation gates. Commands are
    left out on purpose (the agent decides them); such steps are tracked with the run ledger."""
    steps = []
    for k, s in enumerate(res.get("steps", []), 1):
        sid = f"{k}-{s['id']}"
        pre = [f"{res['plan'].index(d) + 1}-{d}" for d in s.get("depends_on", []) if d in res["plan"]]
        steps.append({"id": sid, "action": s.get("subtask") or s["id"], "capability": s["id"], "prerequisites": pre,
                      "route_status": s.get("status"), "use": s.get("use"),
                      "requires_confirmation": CONFIRM_BY_INTENT.get(s["id"], False), "retry": {"max_attempts": 1},
                      "timeout_s": 600})
    return {"name": res.get("task"), "decision": res.get("decision"), "steps": steps}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    v = sub.add_parser("validate")
    v.add_argument("spec")
    r = sub.add_parser("run")
    r.add_argument("spec")
    r.add_argument("--workdir", required=True)
    r.add_argument("--capabilities", default=os.environ.get("OMEGA_CAPABILITIES", ""))
    r.add_argument("--confirm", default=os.environ.get("OMEGA_CONFIRM", ""))
    r.add_argument("--resume", action="store_true")
    r.add_argument("--json", action="store_true")
    s = sub.add_parser("status")
    s.add_argument("--workdir", required=True)
    s.add_argument("--json", action="store_true")
    f = sub.add_parser("from-route")
    f.add_argument("task")
    f.add_argument("--out")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "validate":
            spec = json.loads(Path(a.spec).read_text(encoding="utf-8"))
            by_id, order = validate_spec(spec)
            print("valid: " + " -> ".join(order))
            print("parallel groups: " + " | ".join(",".join(g) for g in levels(by_id, order)))
            return 0
        if a.cmd == "run":
            caps = [c.strip() for c in a.capabilities.split(",") if c.strip()]
            conf = [c.strip() for c in a.confirm.split(",") if c.strip()]
            summary, _ = execute(a.spec, a.workdir, caps, conf, resume=a.resume)
            print(json.dumps(summary, indent=1) if a.json else render(summary))
            return EXIT[summary["status"]]
        if a.cmd == "status":
            led = load_ledger(a.workdir)
            if not led or "summary" not in led:
                print("no finished run in this workdir")
                return 2
            print(json.dumps(led["summary"], indent=1) if a.json else render(led["summary"]))
            return EXIT[led["summary"]["status"]]
        if a.cmd == "from-route":
            sys.path.insert(0, str(Path(__file__).resolve().parent))
            import omega  # noqa: PLC0415
            spec = from_route(omega.route(a.task))
            text = json.dumps(spec, indent=1, ensure_ascii=False)
            if a.out:
                Path(a.out).write_text(text, encoding="utf-8")
            print(text)
            return 0
    except (SpecError, OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal.default_int_handler)
    sys.exit(main())
