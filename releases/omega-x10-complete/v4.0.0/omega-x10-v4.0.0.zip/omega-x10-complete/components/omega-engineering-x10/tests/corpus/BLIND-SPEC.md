# Final blind set: pre-registered specification

Committed together with the development and validation sets, **before any Phase 3 router change**.
The blind prompts themselves do not exist yet when this file is committed.

## Protocol

1. Develop the router using `dev.jsonl` only (inspect failures, add rules).
2. Choose thresholds on `validation.jsonl` only (sweep; no rule edits based on validation errors).
3. Commit the candidate router. Its commit hash is recorded here (`router_commit`) before step 4.
4. Write `blind/blind.jsonl` to this specification, **without consulting `registry/lexicon.json` or `registry/intents.json`**, then run the near-duplicate check against dev and validation and commit the blind file.
5. Evaluate every router (Phase 1, Phase 2, Phase 3) on the blind set **once**. Record the results in the report, unedited.
6. No router, lexicon or threshold change after step 5 may be reported as a blind result.

Step 4 is written after the router freeze on purpose: the blind prompts cannot have shaped the lexicon. The remaining risk is that the author unconsciously writes prompts the router handles. That risk is measured, not removed: the report gives the blind set's out-of-lexicon token rate next to dev's.

## Composition (125 prompts)

25 per language: `en`, `fr`, `ar` (Arabic script: MSA and Tunisian), `tn` (Tunisian Arabizi), `mixed` (code-switching).

| Category | Per language | Content |
|---|---:|---|
| single | 10 | at least 8 distinct intents per language, including `documents` |
| multi | 5 | at least 3 with a real dependency (`ordered: true`) |
| ambiguous | 3 | gold `clarify` |
| negated | 3 | a negated request plus a real one |
| discussion | 2 | asks about a tool or concept; must not execute it |
| trap | 2 | a generic or misleading keyword (app, image, design, code, بحث …) |

## Rules

- No paraphrase of a dev or validation prompt. Pairs with character-trigram Jaccard ≥ 0.6 are rewritten before the freeze.
- Arabizi prompts use at least 5 spellings of common words that do not appear in dev or validation.
- Gold labels use the same intent ids and the same `expect` / `optional` / `ordered` encoding as `dev.jsonl`.

router_commit: 48d56f1
router_fingerprint (sha256 of omega.py + omega_lang.py + intents.json + lexicon.json, concatenated): 4e8c90f17482983aee48c154ceec4fcd11034a6c480883306847ba6c7e9dc879
