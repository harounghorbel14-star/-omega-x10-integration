# Routing corpora

## v4 corpora (current)

| Set | File | Size | Authors | Role |
|---|---|---:|---|---|
| dev4 | `v4/dev4.jsonl` | 400 | isolated agents, guide only | development (error analysis, training) |
| val4 | `v4/val4.jsonl` | 297 | isolated agents, guide only | threshold/policy selection; folded into training after selection |
| train4–train7 | `v4/train4.jsonl` … `v4/train7.jsonl` | 4,775 | isolated agents, guide only | classifier training |
| blind4a | `v4/blind4a/blind4a.jsonl` | 896 | 5 fresh isolated agents | blind round 1: evaluated once on frozen candidate C1, then retired to development data |
| **blind4b** | `v4/blind4b/blind4b.jsonl` | **872** | 5 fresh isolated agents | **blind round 2 (final)**: written after C2 was frozen (commit bbea294), frozen at commit 439e0a4, evaluated once |

All authors received only `v4/LABELING-GUIDE.md`. Blind sets were de-duplicated (character-trigram Jaccard ≥ 0.6) against every development file before freezing (`blind4b/HYGIENE.txt`: 1000 → 872).

### Final blind result (blind4b, router fingerprint 5db7c2547c297d7608f2dcc2f946e578c9fad0e02d812996e127b9dc73f5e64a, single run)

| Router | Exact match | Strict (+order) | Negation subset | Ambiguity subset | Multi-step | Unsupported tool |
|---|---:|---:|---:|---:|---:|---:|
| v3.0.0 | 50.3% | 49.8% | 50.0% | 50.0% | — | 0 |
| C1 (round-1 candidate) | 78.7% | 77.6% | 87.5% | 89.1% | — | 0 |
| **C2 = v4.0.0** | **82.1%** (95% CI 79–84) | 80.7% | 89.3% | 87.0% | 72.8% | 0 |

Paired tests: C2 vs v3 291 gained / 14 lost; C2 vs C1 47 gained / 17 lost (exact binomial p = 0.0002). C1 scored 77.1% on blind4a (n=896) in round 1.

**The routing acceptance gate (100% exact match) is NOT PASSED.** blind4b is now used: it is development data for any later version.

```bash
cd components/omega-engineering-x10/tests
python3 -I routing_eval.py --set blind4b --errors
python3 -I eval_audit.py --set-file corpus/v4/blind4b/blind4b.jsonl --eval-json OUT.json   # independent re-judging
```

## v3 corpora (Phase 3, historical)

Three strictly separate sets. All use the same JSONL encoding (see `components/omega-engineering-x10/tests/routing_eval.py`):
`expect` lists acceptable outcomes (`"clarify"`, `"none"`, or an ordered list of intent ids), `optional` lists extra intents that are allowed, and `ordered` marks plans whose order is a real dependency.

| Set | File | Size | Role | Frozen at |
|---|---|---:|---|---|
| A. Development | `dev.jsonl` | 143 | rules and lexicon were developed against it | commit 60bf25c, before any v3 change |
| B. Validation | `validation.jsonl` | 100 | threshold selection (aggregate metrics only) | commit 60bf25c |
| C. Final blind | `blind/blind.jsonl` | 125 | one measurement, after the router freeze | commit d2fc26f (router frozen at 48d56f1) |

Each set covers `en`, `fr`, `ar` (Arabic script, MSA and Tunisian), `tn` (Tunisian Arabizi) and `mixed` (code-switching), across these categories: single, multi, ambiguous, negated, discussion, trap. The protocol is in `components/omega-engineering-x10/tests/corpus/BLIND-SPEC.md`. No pair across sets has a character-trigram Jaccard of 0.6 or more (enforced by `test_multilingual.py`).

## Pre-registered blind result (router 48d56f1, single run)

| Router | Exact match | Exact on route-gold | Wrong clarify | False security | Unsupported tool |
|---|---:|---:|---:|---:|---:|
| v1 (Phase 1) | 14.4% | 9.5% | 0.0% | 2.5% | 100% |
| v2 (Phase 2) | 31.2% | 23.2% | 35.8% | 0.0% | 0% |
| v3 (Phase 3) | **68.0%** (95% CI 59–76) | 65.3% | 7.4% | 0.8% | 0% |

On paired items v3 fixed 50 that v2 missed and broke 4 that v2 got right (exact binomial p < 1e-6).

**Rules for future work:** the blind set has been used. Tuning against it, or reporting a new router's score on it as "blind", is not allowed. Measure a new router version on a new blind set written after that version is frozen, and treat this set as development data from then on.

## Reproduce

```bash
cd components/omega-engineering-x10/tests
python3 -I routing_eval.py --set dev
python3 -I routing_eval.py --set validation
python3 -I routing_eval.py --set blind --errors
```
