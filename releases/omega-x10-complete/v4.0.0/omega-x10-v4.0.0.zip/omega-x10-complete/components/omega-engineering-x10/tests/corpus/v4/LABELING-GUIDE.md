# Routing corpus: authoring and labeling guide

You are writing realistic requests that a user might type to an AI engineering/creative assistant, and labeling which workflow(s) each request needs. Your prompts will be used to TEST a routing system you have never seen. Write naturally, the way real people type: varied vocabulary, colloquialisms, typos sometimes, short and long requests. Do not try to make prompts easy or hard for any particular system.

## Output format

JSON Lines (one JSON object per line, UTF-8, no trailing commas). Fields:

```json
{"id": "<prefix>-<lang>-<nnn>", "lang": "en|fr|ar|tn|mixed", "cat": "<category>", "difficulty": "easy|medium|hard",
 "prompt": "<the user request>", "expect": [<acceptable outcomes>], "optional": [<allowed extra intents>], "ordered": true|false}
```

- `expect` is a list of acceptable outcomes. Each outcome is either the string `"clarify"`, the string `"none"`, or a JSON list of intent ids **in execution order**, e.g. `["image", "video-animation"]`.
- `optional`: intents that would also be acceptable in addition to the required ones (natural side-steps). Usually `[]`.
- `ordered`: `true` when the order of the required intents is a real dependency (step 2 uses step 1's result). Only meaningful for multi-intent outcomes.

## Intent ids (use exactly these)

| id | use when the user wants... |
|---|---|
| implementation | code written or changed: build/add/modify an app, website, API, endpoint, feature, component, script, form, filter, button, integration, refactor |
| debugging | something that malfunctions investigated or fixed: errors, crashes, "X doesn't work / stopped / is missing", "find out why", flaky behaviour |
| tdd | tests written, added or run (unit, integration, e2e, regression tests) |
| code-review | code, a PR or a diff reviewed |
| security | a security audit, vulnerability check, hardening, leaked secrets handling, "is X secure/safe" about their system |
| ui-ux-design | UI/UX design: mockups, wireframes, screen/flow design, layout, colours, typography, design system, landing page design |
| web-research | external/current information looked up: news, latest versions, prices, comparisons with sources, reviews, gathering opinions, monitoring a topic |
| image | a still image created or edited: logo, icon, poster, banner, illustration, thumbnail, photo retouch, background removal |
| video-animation | a video, animation, GIF, reel, clip, motion graphics created or edited (incl. animating an image/logo) |
| 3d | 3D models, scenes, rendering, Blender/Unity/Unreal/three.js asset work |
| browser-automation | a website operated on their behalf: log in, navigate, click, fill a form, scrape, download/export data from a site or dashboard, screenshots of web pages |
| deployment-release | deploy, redeploy, release, publish a package, ship to production, CI/CD pipelines, rollback, containers for deployment |
| performance | speed, latency, memory or load optimisation, profiling, "make X faster" |
| planning | a plan, roadmap, milestones, task breakdown, spec for a project |
| documents | a document, report, memo, proposal, CV, spreadsheet/Excel, slide deck/presentation created |
| repository-architecture | an explanation/map of THEIR codebase structure, where something is used |
| app-replication | an existing third-party app recreated as their own version |
| git-workflow | commits, branches, pull requests, merges, rebases |

## Decision outcomes

- `"clarify"`: the request is genuinely ambiguous: it is unclear WHAT to do or ON WHAT ("fix it", "make it better", "look at this", "do the thing"). If one reading is clearly most likely, use e.g. `["clarify", ["debugging"]]`.
- `"none"`: nothing should be executed by a workflow: a general question answered directly, short personal prose (message, bio, caption, poem, tweet, email, cover letter, toast), or discussing/asking about a tool or concept.

## Labeling rules (follow strictly)

1. **Questions/discussion about a tool or concept** ("what is X", "is X worth learning", "is X free", "difference between X and Y", "how does X work") → `["none", ["web-research"]]`.
2. **Short personal prose** → `["none", "clarify"]`.
3. **Negated actions are NOT in the gold label.** "Don't deploy, just fix the bug" → `[["debugging"]]`.
4. **Describing a malfunction is debugging**, even with no verb ("the images don't load on Safari", "notifications stopped arriving").
5. **Landing page / homepage creation** → `[["ui-ux-design"], ["implementation"]]` with `"optional": ["ui-ux-design", "implementation"]`.
6. **"Export data from a website/dashboard"** → browser-automation; **"add an export feature"** → implementation.
7. **"Make X faster"** → performance (not implementation).
8. **Requests naming a specific external tool** ("use Canva to make a poster", "deploy with Railway") are labeled with the normal intent (image, deployment-release); category `unsupported`.
9. **Multi-step requests**: list every required intent in execution order and set `ordered: true` when later steps consume earlier results. Do not list trivial non-workflow actions (sending, telling, explaining the result).
10. Use `optional` for natural side-steps (e.g. fixing a memory leak may also be performance).

## Categories (`cat`)

| cat | meaning |
|---|---|
| single | one clear workflow |
| multi | two or more workflows (2 to 5 steps) |
| ambiguous | genuinely unclear (gold includes "clarify") |
| negated | contains an instruction NOT to do something, or a negated description |
| discussion | asks about/discusses a tool or concept rather than requesting work |
| trap | contains a generic or misleading keyword (app, code, image, design, search, page, profile, report...) used in a non-obvious way |
| unsupported | explicitly names an external tool/service to use |
| adversarial | typos, odd casing, emojis, very long rambling requests, mixed punctuation, but still a clear intent |

## Languages

- `en`: English. `fr`: French. `ar`: Arabic script, both Modern Standard Arabic and Tunisian dialect written in Arabic letters.
- `tn`: Tunisian Arabic written in Latin letters ("Arabizi"), using digits for Arabic sounds (3, 7, 9, 5, 2), with natural spelling variation and French loanwords.
- `mixed`: code-switching within one prompt (any mix of Arabizi, Arabic script, French, English).

## Quality rules

- Every prompt must be different in wording; do not produce near-duplicates or simple word swaps of another prompt in your file.
- Do not translate the same prompt into several languages.
- Vary domains (web apps, mobile apps, data, marketing, school projects, e-commerce, games, personal tasks).
- Vary length (3 to 40 words) and register (formal, casual, terse).
- Label honestly according to the rules above, even when a request is hard.
