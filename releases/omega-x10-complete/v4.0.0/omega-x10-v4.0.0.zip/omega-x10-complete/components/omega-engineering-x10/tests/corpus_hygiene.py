#!/usr/bin/env python3
"""Corpus hygiene: drop exact duplicates inside a file and near-duplicates (char-trigram Jaccard >= 0.6) of a
reference set. Used to keep held-out sets disjoint from development data. Prints every dropped id.

  python3 corpus_hygiene.py TARGET.jsonl --against A.jsonl B.jsonl [--write]
"""
import argparse, json, re, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import omega_lang as L  # noqa: E402


def tri(s):
    s = re.sub(r"\s+", " ", L.normalise(s))
    return {s[i:i + 3] for i in range(len(s) - 2)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("target")
    ap.add_argument("--against", nargs="*", default=[])
    ap.add_argument("--write", action="store_true")
    ap.add_argument("--threshold", type=float, default=0.6)
    a = ap.parse_args()
    rows = [json.loads(l) for l in open(a.target, encoding="utf-8") if l.strip()]
    ref = []
    for p in a.against:
        ref += [(json.loads(l)["id"], tri(json.loads(l)["prompt"])) for l in open(p, encoding="utf-8") if l.strip()]
    keep, seen, dropped = [], [], []
    for c in rows:
        t = tri(c["prompt"])
        hit = next(((rid, j) for rid, r in ref for j in [len(t & r) / max(1, len(t | r))] if j >= a.threshold), None)
        if hit is None:
            hit = next(((sid, j) for sid, s in seen for j in [len(t & s) / max(1, len(t | s))] if j >= 0.9), None)
        if hit:
            dropped.append((c["id"], hit[0], round(hit[1], 2)))
            continue
        keep.append(c)
        seen.append((c["id"], t))
    for d in dropped:
        print("drop", *d)
    print(f"{a.target}: kept {len(keep)}/{len(rows)}")
    if a.write:
        with open(a.target, "w", encoding="utf-8") as fh:
            for c in keep:
                fh.write(json.dumps(c, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
