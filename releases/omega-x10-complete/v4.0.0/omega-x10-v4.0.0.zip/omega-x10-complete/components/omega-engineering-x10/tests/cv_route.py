#!/usr/bin/env python3
"""Full-pipeline k-fold cross-validation: for each fold, train the classifier on the other folds and route the
held-out prompts through the complete router (rules + classifier + fusion + planning). Development tool.

  python3 cv_route.py --data FILE... [--k 5] [--json OUT]
Environment variables starting with OMEGA_ are passed through, so fusion variants can be compared.
"""
import argparse
import json
import os
import sys
import tempfile
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))
sys.path.insert(0, str(HERE))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", nargs="+", required=True)
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--C", type=float, default=16.0)
    ap.add_argument("--policy", default=None, help="JSON policy; default: the bundled model's policy")
    ap.add_argument("--json")
    ap.add_argument("--model-dir", help="cache fold models here (reused when data, C and features are unchanged)")
    a = ap.parse_args()
    import omega_train as T  # sets OMEGA_CLASSIFIER=off for featurisation
    cases = T.load_cases(a.data, {Path(p).name for p in a.data})
    rows = T.featurise(cases)
    tm = [T.targets(c) for c in cases]
    os.environ["OMEGA_CLASSIFIER"] = "on"
    import routing_eval as R
    bundled = json.loads((HERE.parent / "registry" / "classifier.json").read_text())
    pol = json.loads(a.policy) if a.policy else bundled["policy"]
    env = {"OMEGA_SKILL_ROOTS": str(R.FIXTURE_SKILLS), "OMEGA_SESSION_TOOLS": "", "OMEGA_AUTHORIZED": ""}
    mod = R.load_router(R.DEFAULT_OMEGA, env)
    inv = R.fixture_inventory()
    import hashlib
    digest = hashlib.sha256(json.dumps([c["id"] for c in cases]).encode() + str(a.C).encode() +
                            json.dumps(rows[:50], sort_keys=True).encode()).hexdigest()[:16]
    tmp = Path(a.model_dir) if a.model_dir else Path(tempfile.mkdtemp(prefix="omega-cv-"))
    tmp.mkdir(parents=True, exist_ok=True)
    results = []
    for f in range(a.k):
        tr = [i for i, c in enumerate(cases) if T.fold_of(c["id"], a.k) != f]
        te = [i for i, c in enumerate(cases) if T.fold_of(c["id"], a.k) == f]
        mp = tmp / f"fold{f}-{digest}.json"
        if mp.exists():
            m = json.loads(mp.read_text())
        else:
            m = T.fit([rows[i] for i in tr], [tm[i][0] for i in tr], [tm[i][1] for i in tr], a.C, 2)
        m["policy"] = pol
        mp.write_text(json.dumps(m))
        os.environ["OMEGA_CLASSIFIER_MODEL"] = str(mp)
        for i in te:
            c = cases[i]
            if "lang" not in c:  # Phase 2 bench cases: not scored here (different judging semantics)
                continue
            pred = R.predict(mod, c["prompt"], inv)
            results.append({**c, "pred": pred, "judge": R.judge(c, pred)})
        print(f"fold {f}: {len(te)} cases", file=sys.stderr)
    n = len(results)
    ex = sum(r["judge"]["exact"] for r in results)
    st = sum(r["judge"]["strict_exact"] for r in results)
    by = defaultdict(lambda: [0, 0])
    for r in results:
        for key in ("cat:" + r.get("cat", "?"), "lang:" + r.get("lang", "?")):
            by[key][0] += r["judge"]["exact"]
            by[key][1] += 1
    print(f"cv-route exact {ex}/{n} ({ex / n:.1%})  strict {st}/{n} ({st / n:.1%})")
    print("  " + "  ".join(f"{k} {v[0] / v[1]:.0%}" for k, v in sorted(by.items())))
    if a.json:
        Path(a.json).write_text(json.dumps({"exact": ex, "strict": st, "n": n, "rows": results}, ensure_ascii=False))


if __name__ == "__main__":
    main()
