#!/usr/bin/env python3
"""Independent audit of a routing evaluation (guards against false scores).

  python3 eval_audit.py --set-file corpus/v4/blind4b/blind4b.jsonl --eval-json EVAL.json --label C2 \
      --fingerprint FINGERPRINT.json --train FILE...

Checks, each PASS/FAIL with numbers:
  1. denominator: every frozen case appears exactly once in the evaluation, nothing extra, nothing skipped;
  2. re-judging: exact match recomputed here with a separate implementation from the stored predictions
     (none / clarify must be decided exactly; a plan needs required <= predicted <= required + optional);
  3. no leakage: no evaluated prompt (normalised) or id occurs in the router sources, registry or classifier
     vocabulary as a whole-prompt string, and no evaluated prompt is in a training file;
  4. labels: every gold outcome uses known intents / "none" / "clarify"; every category is non-empty;
  5. unsupported tools: no plan selects a tool reported unavailable;
  6. fingerprint: the router files hash to the fingerprint recorded at evaluation time.
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "scripts"))
import omega_lang as L  # noqa: E402


def norm(s):
    return re.sub(r"\s+", " ", L.normalise(s)).strip()


def rejudge(case, pred):
    dec, sel = pred["decision"], set(pred["selected"])
    for o in case["expect"]:
        if isinstance(o, str):
            if dec == o:
                return True
        elif dec in ("route", "multi") and set(o) <= sel <= set(o) | set(case.get("optional", [])):
            return True
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--set-file", required=True)
    ap.add_argument("--eval-json", required=True)
    ap.add_argument("--label")
    ap.add_argument("--fingerprint")
    ap.add_argument("--train", nargs="*", default=[])
    a = ap.parse_args()
    cases = [json.loads(x) for x in open(a.set_file, encoding="utf-8") if x.strip()]
    ev = json.load(open(a.eval_json, encoding="utf-8"))
    rows = ev["rows"][a.label] if a.label else next(iter(ev["rows"].values()))
    results, ok_all = [], True

    def check(name, ok, detail):
        nonlocal ok_all
        ok_all &= bool(ok)
        results.append(f"{'PASS' if ok else 'FAIL'}  {name}: {detail}")

    ids = [c["id"] for c in cases]
    rid = [r["id"] for r in rows]
    check("denominator", sorted(ids) == sorted(rid) and len(set(rid)) == len(rid),
          f"{len(cases)} frozen cases, {len(rows)} evaluated, {len(set(rid))} unique")
    by = {c["id"]: c for c in cases}
    mine = sum(rejudge(by[r["id"]], r["pred"]) for r in rows)
    theirs = sum(r["judge"]["exact"] for r in rows)
    diff = [r["id"] for r in rows if rejudge(by[r["id"]], r["pred"]) != r["judge"]["exact"]]
    check("re-judged exact match", mine == theirs and not diff, f"independent {mine}/{len(rows)} vs evaluator {theirs}/{len(rows)}; "
          f"disagreements {diff[:5]}")
    gold_changed = [r["id"] for r in rows if r["expect"] != by[r["id"]]["expect"] or r["prompt"] != by[r["id"]]["prompt"]]
    check("gold/prompt unchanged between frozen file and evaluation", not gold_changed, f"{len(gold_changed)} differences")
    blob = ""
    for p in list((ROOT / "scripts").glob("*.py")) + [ROOT / "registry" / n for n in ("intents.json", "lexicon.json")]:
        blob += norm(p.read_text(encoding="utf-8")) + "\n"
    leaked = [c["id"] for c in cases if len(norm(c["prompt"])) > 25 and norm(c["prompt"]) in blob]
    id_leak = [i for i in ids if i in blob]
    check("no prompt or id hard-coded in router sources/registry", not leaked and not id_leak,
          f"{len(leaked)} prompts, {len(id_leak)} ids found")
    train_prompts = set()
    for t in a.train:
        for x in open(t, encoding="utf-8"):
            if x.strip():
                train_prompts.add(norm(json.loads(x)["prompt"]))
    in_train = [c["id"] for c in cases if norm(c["prompt"]) in train_prompts]
    check("no evaluated prompt in training data", not in_train, f"{len(in_train)} of {len(cases)} found in {len(a.train)} training files")
    intents = {i["id"] for i in json.load(open(ROOT / "registry" / "intents.json"))["intents"]}
    bad = [c["id"] for c in cases for o in c["expect"] if not (o in ("none", "clarify") or (isinstance(o, list) and set(o) <= intents and o))]
    cats = {}
    for c in cases:
        cats[c.get("cat")] = cats.get(c.get("cat"), 0) + 1
    need = {"single", "multi", "ambiguous", "negated", "discussion", "trap", "unsupported", "adversarial"}
    check("labels well-formed, all categories present", not bad and need <= set(cats), f"bad {bad[:5]}; categories {cats}")
    unsup = [r["id"] for r in rows if r["pred"].get("unsupported")]
    check("zero unsupported-tool selections", not unsup, f"{len(unsup)} cases")
    if a.fingerprint:
        fp = json.load(open(a.fingerprint))
        bad_files = [f for f, h in fp["files"].items() if hashlib.sha256((ROOT / f).read_bytes()).hexdigest() != h]
        check("router files match the fingerprint recorded at evaluation", not bad_files, f"mismatched {bad_files}")
    print("\n".join(results))
    print(f"\naudit: {'PASSED' if ok_all else 'FAILED'}  (exact match {mine}/{len(rows)} = {mine / len(rows):.1%})")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
