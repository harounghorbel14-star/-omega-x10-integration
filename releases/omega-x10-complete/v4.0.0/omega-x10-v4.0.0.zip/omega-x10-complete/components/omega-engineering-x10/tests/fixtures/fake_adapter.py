#!/usr/bin/env python3
"""Fake external classifier for adapter tests: offline, deterministic. Mode from argv[1]; writes a marker file."""
import json
import sys
from pathlib import Path

mode, marker = sys.argv[1], Path(sys.argv[2])
marker.write_text("called")
req = json.loads(sys.stdin.read())
if mode == "fail":
    sys.exit(3)
if mode == "garbage":
    print("not json")
elif mode == "unknown-intent":
    print(json.dumps({"decision": "route", "intents": ["teleportation"], "confidence": 0.99}))
else:
    print(json.dumps({"decision": "route", "intents": ["documents"], "confidence": 0.95}))
