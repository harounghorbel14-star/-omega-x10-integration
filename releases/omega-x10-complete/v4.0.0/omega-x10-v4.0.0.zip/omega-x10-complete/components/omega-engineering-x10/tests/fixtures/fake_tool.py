#!/usr/bin/env python3
"""Deterministic fake tool for workflow tests. Never touches the network or anything outside its arguments.

  fake_tool.py MODE --out PATH [--in PATH ...] [--content TEXT] [--state DIR] [--fail-times N] [--sleep S]

Modes: ok (write content, exit 0), fail (exit 1, no output), exit0-no-output, empty (0-byte output),
corrupt-json (invalid JSON), json (valid JSON with keys status,inputs), png (tiny valid PNG signature file),
flaky (fail the first --fail-times calls, counted in --state, then ok), slow (sleep --sleep then ok),
crash (exit 137), echo-secret (prints a fake token on stdout), concat (output = inputs concatenated).
"""
import argparse
import json
import sys
import time
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("mode")
ap.add_argument("--out", action="append", default=[])
ap.add_argument("--in", dest="inp", action="append", default=[])
ap.add_argument("--content", default="OK")
ap.add_argument("--state")
ap.add_argument("--fail-times", type=int, default=1)
ap.add_argument("--sleep", type=float, default=0)
a = ap.parse_args()


def write(data):
    for o in a.out:
        Path(o).parent.mkdir(parents=True, exist_ok=True)
        Path(o).write_bytes(data if isinstance(data, bytes) else data.encode())


m = a.mode
if m == "ok":
    write(a.content + "\n")
elif m == "fail":
    print("simulated failure", file=sys.stderr)
    sys.exit(1)
elif m == "exit0-no-output":
    print("pretending success")
elif m == "empty":
    write(b"")
elif m == "corrupt-json":
    write("{not json")
elif m == "json":
    write(json.dumps({"status": "ok", "inputs": [Path(i).read_text() for i in a.inp]}))
elif m == "png":
    write(b"\x89PNG\r\n\x1a\n" + b"\x00" * 32)
elif m == "flaky":
    st = Path(a.state) / "flaky.count"
    st.parent.mkdir(parents=True, exist_ok=True)
    n = int(st.read_text()) if st.exists() else 0
    st.write_text(str(n + 1))
    if n < a.fail_times:
        print(f"flaky failure {n + 1}", file=sys.stderr)
        sys.exit(2)
    write(a.content + "\n")
elif m == "slow":
    time.sleep(a.sleep)
    write(a.content + "\n")
elif m == "crash":
    sys.exit(137)
elif m == "echo-secret":
    print("api_key=sk-THIS-IS-FAKE-123")
    write(a.content + "\n")
elif m == "concat":
    write("".join(Path(i).read_text() for i in a.inp) + a.content + "\n")
else:
    print("unknown mode", file=sys.stderr)
    sys.exit(64)
