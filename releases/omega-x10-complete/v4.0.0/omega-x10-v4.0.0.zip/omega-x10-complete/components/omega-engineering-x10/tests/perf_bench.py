#!/usr/bin/env python3
"""Router latency / memory benchmark and regex-pathology probe. Standard library only.

  python3 perf_bench.py [--set corpus/v4/val4.jsonl] [--json OUT]
"""
import argparse
import json
import os
import statistics
import sys
import time
import tracemalloc
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--set", default=str(HERE / "corpus" / "v4" / "val4.jsonl"))
    ap.add_argument("--json")
    a = ap.parse_args()
    os.environ.setdefault("OMEGA_SESSION_TOOLS", "")
    t0 = time.perf_counter()
    tracemalloc.start()
    import omega  # noqa: PLC0415
    omega.route("warm up: fix the login bug")
    cold = time.perf_counter() - t0
    prompts = [json.loads(x)["prompt"] for x in open(a.set, encoding="utf-8") if x.strip()]
    lat = []
    for p in prompts:
        s = time.perf_counter()
        omega.route(p)
        lat.append((time.perf_counter() - s) * 1000)
    cur, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    lat.sort()
    patho = {
        "10k 'a'": "a" * 10000,
        "5k 'ma '": "ma " * 5000,
        "nested punctuation": "(((" * 2000 + "fix" + ")))" * 2000,
        "2k arabic clitics": "وبالتطبيقات " * 2000,
        "mixed digits arabizi": "7a9a3a5a2a " * 2000,
        "long no-space url": "https://" + "x/" * 5000,
    }
    pt = {}
    for name, txt in patho.items():
        s = time.perf_counter()
        omega.route(txt)
        pt[name] = round((time.perf_counter() - s) * 1000, 1)
    out = {"n": len(prompts), "cold_start_ms": round(cold * 1000, 1), "p50_ms": round(statistics.median(lat), 2),
           "p95_ms": round(lat[int(0.95 * (len(lat) - 1))], 2), "max_ms": round(lat[-1], 2), "mean_ms": round(statistics.mean(lat), 2),
           "peak_traced_mb": round(peak / 1e6, 1), "pathological_inputs_ms": pt, "python": sys.version.split()[0]}
    print(json.dumps(out, indent=1, ensure_ascii=False))
    if a.json:
        Path(a.json).write_text(json.dumps(out, indent=1, ensure_ascii=False))
    return 0 if max(pt.values()) < 30000 else 1


if __name__ == "__main__":
    sys.exit(main())
