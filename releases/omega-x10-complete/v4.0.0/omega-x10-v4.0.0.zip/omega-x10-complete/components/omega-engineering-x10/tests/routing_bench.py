#!/usr/bin/env python3
"""Routing regression bench. Standard library only.

  python3 routing_bench.py                         # current router, all case files
  python3 routing_bench.py --omega PATH/omega.py   # any router version (e.g. the original)
  python3 routing_bench.py --cases FILE [--cases FILE ...] [--json] [--verbose]

Works with both router generations:
  * current: route() returns {"decision", "primary", "selected": [...]}
  * legacy:  route() returns {"routes": [...]}; every listed route counts as selected,
             the first one is primary, and it can never ask for clarification.
Exit code: 0 when every case passes, 1 otherwise.
"""
import argparse
import importlib.util
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_OMEGA = HERE.parent / "scripts" / "omega.py"
DEFAULT_CASES = sorted(HERE.glob("routing_cases*.json"))


def load_router(path):
    spec = importlib.util.spec_from_file_location(f"omega_{abs(hash(str(path)))}", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def normalise(res):
    if "decision" in res:
        return res["primary"] or res["decision"], [s["id"] for s in res["selected"]]
    ids = [r["id"] for r in res.get("routes", [])]
    return (ids[0] if ids else "none"), ids


def check(case, primary, selected):
    problems = []
    if primary not in case["expect"]:
        problems.append(f"primary={primary} not in {case['expect']}")
    for need in case.get("include", []):
        if need not in selected:
            problems.append(f"missing {need}")
    for bad in case.get("forbid", []):
        if bad in selected:
            problems.append(f"forbidden {bad} selected")
    for bad in case.get("forbid_primary", []):
        if primary == bad:
            problems.append(f"forbidden primary {bad}")
    return problems


def run(omega_path, case_files):
    return run_module(load_router(omega_path), case_files)


def run_module(mod, case_files):
    rows = []
    for cf in case_files:
        for case in json.loads(Path(cf).read_text())["cases"]:
            res = mod.route(case["prompt"])
            primary, selected = normalise(res)
            problems = check(case, primary, selected)
            rows.append({"file": Path(cf).name, "id": case["id"], "group": case["group"], "prompt": case["prompt"],
                         "primary": primary, "selected": selected, "pass": not problems, "problems": problems})
    return rows


def summarise(rows):
    groups = {}
    for r in rows:
        g = groups.setdefault(r["group"], [0, 0])
        g[0] += r["pass"]
        g[1] += 1
    return groups


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--omega", default=str(DEFAULT_OMEGA))
    ap.add_argument("--cases", action="append")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args(argv)
    files = a.cases or [str(p) for p in DEFAULT_CASES]
    rows = run(a.omega, files)
    passed = sum(r["pass"] for r in rows)
    if a.json:
        print(json.dumps({"router": a.omega, "passed": passed, "total": len(rows), "groups": summarise(rows), "rows": rows}, indent=1))
    else:
        print(f"router: {a.omega}")
        for r in rows:
            if a.verbose or not r["pass"]:
                mark = "PASS" if r["pass"] else "FAIL"
                print(f"  {mark} {r['id']:<8} primary={r['primary']:<22} selected={r['selected']}  {'; '.join(r['problems'])}")
        for g, (p, t) in summarise(rows).items():
            print(f"  {g:<18} {p}/{t}")
        print(f"TOTAL {passed}/{len(rows)} ({100 * passed / len(rows):.1f}%)")
    return 0 if passed == len(rows) else 1


if __name__ == "__main__":
    sys.exit(main())
