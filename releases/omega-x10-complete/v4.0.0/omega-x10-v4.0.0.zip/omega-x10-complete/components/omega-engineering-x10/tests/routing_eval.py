#!/usr/bin/env python3
"""Multilingual routing evaluation. Standard library only.

  python3 routing_eval.py --set dev                      # current router
  python3 routing_eval.py --set validation --omega PATH  # any router generation (phase 1/2/3)
  python3 routing_eval.py --set blind --compare A.py B.py C.py --labels p1 p2 p3
  python3 routing_eval.py --set dev --json out.json --errors

Case format (JSONL): {"id","lang","cat","prompt","expect","optional","ordered"}
  expect: list of acceptable outcomes; each is "clarify", "none", or an ordered list of intent ids.
  optional: extra intents that are allowed but not required.
  ordered: the plan order of the required intents matters (a real dependency).

Exact match: some outcome o fits. For "clarify"/"none" the router must decide exactly that.
For a plan, required(o) <= predicted <= required(o) + optional.
Tool availability uses a fixed skill list (tests/fixtures/skill_inventory.json, materialised in a temp dir) so numbers are reproducible.
"""
import argparse
import importlib.util
import json
import math
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
CORPUS = HERE / "corpus"
SETS = {"dev": CORPUS / "dev.jsonl", "validation": CORPUS / "validation.jsonl", "blind": CORPUS / "blind" / "blind.jsonl",
        "dev4": CORPUS / "v4" / "dev4.jsonl", "train4": CORPUS / "v4" / "train4.jsonl", "train5": CORPUS / "v4" / "train5.jsonl", "train6": CORPUS / "v4" / "train6.jsonl", "train7": CORPUS / "v4" / "train7.jsonl", "val4": CORPUS / "v4" / "val4.jsonl", "blind4a": CORPUS / "v4" / "blind4a" / "blind4a.jsonl",
        "blind4": CORPUS / "v4" / "blind4" / "blind4.jsonl", "blind4b": CORPUS / "v4" / "blind4b" / "blind4b.jsonl"}
FIXTURE_LIST = HERE / "fixtures" / "skill_inventory.json"


def _materialise_fixture():
    """Build a throwaway skill root from the fixture list (removed at exit)."""
    import atexit
    import shutil
    import tempfile
    root = Path(tempfile.mkdtemp(prefix="omega-fixture-skills-"))
    atexit.register(shutil.rmtree, root, True)
    for name in json.loads(FIXTURE_LIST.read_text(encoding="utf-8"))["skills"]:
        (root / name).mkdir()
        (root / name / ("SKILL" + ".md")).write_text(f"---\nname: {name}\ndescription: routing fixture\n---\n", encoding="utf-8")
    return root


FIXTURE_SKILLS = _materialise_fixture()
DEFAULT_OMEGA = HERE.parent / "scripts" / "omega.py"


# ------------------------------------------------------------------ loading
def load_cases(path):
    with open(path, encoding="utf-8") as fh:
        return [json.loads(line) for line in fh if line.strip()]


def load_router(path, env=None):
    os.environ.update(env or {})
    spec = importlib.util.spec_from_file_location(f"router_{abs(hash(str(path)))}", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if hasattr(mod, "skill_inventory"):
        mod.skill_inventory.cache_clear()
    return mod


def fixture_inventory():
    return {p.name for p in FIXTURE_SKILLS.iterdir() if (p / "SKILL.md").exists()} if FIXTURE_SKILLS.is_dir() else set()


def predict(mod, prompt, inventory):
    """Normalise any router generation to: decision, selected ids, plan order, executor checks."""
    res = mod.route(prompt)
    if "decision" in res:  # phase 2 / phase 3
        sel = [s["id"] for s in res["selected"]]
        plan = [p["id"] if isinstance(p, dict) else p for p in res.get("plan", sel)]
        unsupported = []
        for s in res["selected"]:
            st, use = s.get("status"), s.get("use", "")
            if st == "READY" and use.startswith("skill: ") and use[7:] not in inventory:
                unsupported.append(s["id"])
            elif st == "READY" and use.startswith("connector") and not s.get("authorized", False):
                unsupported.append(s["id"])
            elif st in ("FALLBACK", "LIMITED") and s.get("fallback_missing"):
                unsupported.append(s["id"])
        return {"decision": res["decision"], "selected": sel, "plan": plan, "unsupported": unsupported,
                "n_exec": len(sel)}
    ids = [r["id"] for r in res.get("routes", [])]  # phase 1: every listed route is a recommendation
    unsupported = [r["id"] for r in res.get("routes", []) if r.get("primary", "").split(" ")[0] not in inventory]
    return {"decision": "route" if ids else "none", "selected": ids, "plan": ids, "unsupported": unsupported,
            "n_exec": len(ids)}


# ------------------------------------------------------------------ scoring one case
def judge(case, pred):
    optional = set(case.get("optional", []))
    best = None
    for o in case["expect"]:
        if isinstance(o, str):
            ok = pred["decision"] == o and not pred["selected"]
            cand = {"outcome": o, "exact": ok, "required": [], "tp": 0, "fp": len(pred["selected"]), "fn": 0}
        else:
            req, sel = set(o), set(pred["selected"])
            ok = pred["decision"] in ("route", "multi") and req <= sel <= req | optional
            cand = {"outcome": o, "exact": ok, "required": list(o), "tp": len(req & sel),
                    "fp": len(sel - req - optional), "fn": len(req - sel)}
        key = (cand["exact"], cand["tp"] - cand["fp"] - cand["fn"])
        if best is None or key > (best["exact"], best["tp"] - best["fp"] - best["fn"]):
            best = cand
    allowed = set(optional)
    for o in case["expect"]:
        if isinstance(o, list):
            allowed |= set(o)
    best["false_security"] = "security" in pred["selected"] and "security" not in allowed
    gold_is_route = isinstance(best["outcome"], list)
    best["unwarranted_clarify"] = pred["decision"] == "clarify" and all(isinstance(o, list) for o in case["expect"])
    best["missed_clarify"] = case["expect"] == ["clarify"] and pred["decision"] != "clarify"
    best["order_ok"] = None
    if case.get("ordered") and gold_is_route and len(best["required"]) > 1:
        req = list(dict.fromkeys(best["required"]))  # a label listing an intent twice keeps its first position
        seq = [p for p in pred["plan"] if p in req]
        best["order_ok"] = best["exact"] and seq == req
    # strict exact: exact AND, for ordered multi-step gold, the plan order matches
    best["strict_exact"] = best["exact"] and best["order_ok"] is not False
    external = {"deployment-release", "git-workflow", "browser-automation"}
    best["unrequested_external"] = sorted((set(pred["selected"]) & external) - allowed)
    return best


# ------------------------------------------------------------------ aggregate metrics
def wilson(k, n, z=1.96):
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def pct(k, n):
    lo, hi = wilson(k, n)
    return {"k": k, "n": n, "rate": round(k / n, 4) if n else None, "ci95": [round(lo, 3), round(hi, 3)]}


def primary_label(outcome_or_pred):
    if isinstance(outcome_or_pred, str):
        return outcome_or_pred
    return outcome_or_pred[0] if outcome_or_pred else "none"


def evaluate(mod, cases, inventory):
    rows = []
    for case in cases:
        pred = predict(mod, case["prompt"], inventory)
        j = judge(case, pred)
        rows.append({**case, "pred": pred, "judge": j})
    n = len(rows)
    m = {"n": n, "exact": pct(sum(r["judge"]["exact"] for r in rows), n),
         "strict_exact": pct(sum(r["judge"]["strict_exact"] for r in rows), n)}
    neg = [r for r in rows if r.get("cat") == "negated"]
    amb = [r for r in rows if r.get("cat") == "ambiguous"]
    m["critical_negation_subset"] = pct(sum(r["judge"]["strict_exact"] for r in neg), len(neg))
    m["ambiguity_subset"] = pct(sum(r["judge"]["exact"] for r in amb), len(amb))
    m["unrequested_external_action"] = pct(sum(bool(r["judge"]["unrequested_external"]) for r in rows), n)
    for key, field in (("by_lang", "lang"), ("by_cat", "cat"), ("by_difficulty", "difficulty")):
        groups = defaultdict(list)
        for r in rows:
            groups[r.get(field, "n/a")].append(r["judge"]["exact"])
        m[key] = {g: pct(sum(v), len(v)) for g, v in sorted(groups.items())}
    ordered = [r for r in rows if r["judge"]["order_ok"] is not None]
    m["ordering_end_to_end"] = pct(sum(r["judge"]["order_ok"] for r in ordered), len(ordered))
    set_ok = [r for r in ordered if r["judge"]["exact"]]
    m["ordering_given_correct_set"] = pct(sum(r["judge"]["order_ok"] for r in set_ok), len(set_ok))
    not_sec = [r for r in rows if "security" not in set(r.get("optional", [])) | {i for o in r["expect"] if isinstance(o, list) for i in o}]
    m["false_security"] = pct(sum(r["judge"]["false_security"] for r in not_sec), len(not_sec))
    m["clarify_rate"] = pct(sum(r["pred"]["decision"] == "clarify" for r in rows), n)
    route_gold = [r for r in rows if all(isinstance(o, list) for o in r["expect"])]
    m["unwarranted_clarify"] = pct(sum(r["judge"]["unwarranted_clarify"] for r in route_gold), len(route_gold))
    clar_gold = [r for r in rows if r["expect"] == ["clarify"]]
    m["missed_clarify"] = pct(sum(r["judge"]["missed_clarify"] for r in clar_gold), len(clar_gold))
    n_exec = sum(r["pred"]["n_exec"] for r in rows)
    m["unsupported_tool_selection"] = pct(sum(len(r["pred"]["unsupported"]) for r in rows), n_exec)
    # per-intent precision / recall / F1 (micro counts per intent)
    tp, fp, fn = Counter(), Counter(), Counter()
    for r in rows:
        req = set(r["judge"]["required"])
        allowed = req | set(r.get("optional", []))
        sel = set(r["pred"]["selected"])
        for i in sel & req:
            tp[i] += 1
        for i in sel - allowed:
            fp[i] += 1
        for i in req - sel:
            fn[i] += 1
    per = {}
    for i in sorted(set(tp) | set(fp) | set(fn)):
        p = tp[i] / (tp[i] + fp[i]) if tp[i] + fp[i] else 0.0
        rc = tp[i] / (tp[i] + fn[i]) if tp[i] + fn[i] else 0.0
        f1 = 2 * p * rc / (p + rc) if p + rc else 0.0
        per[i] = {"support": tp[i] + fn[i], "tp": tp[i], "fp": fp[i], "fn": fn[i],
                  "precision": round(p, 3), "recall": round(rc, 3), "f1": round(f1, 3)}
    m["per_intent"] = per
    supported = [v for v in per.values() if v["support"] >= 5]
    m["macro_f1_support_ge5"] = round(sum(v["f1"] for v in supported) / len(supported), 3) if supported else None
    conf = defaultdict(Counter)
    for r in rows:
        conf[primary_label(r["judge"]["outcome"])][primary_label(r["pred"]["plan"]) if r["pred"]["selected"] else r["pred"]["decision"]] += 1
    m["confusion_primary"] = {g: dict(c) for g, c in sorted(conf.items())}
    # A router that always asks must not score well: accuracy on route-gold items only.
    m["exact_on_route_gold"] = pct(sum(r["judge"]["exact"] for r in route_gold), len(route_gold))
    return m, rows


def mcnemar(rows_a, rows_b):
    """Exact two-sided binomial test on discordant pairs (paired comparison on the same items)."""
    b = sum(1 for x, y in zip(rows_a, rows_b) if x["judge"]["exact"] and not y["judge"]["exact"])
    c = sum(1 for x, y in zip(rows_a, rows_b) if not x["judge"]["exact"] and y["judge"]["exact"])
    n = b + c
    if n == 0:
        return {"a_only": b, "b_only": c, "p_value": 1.0}
    k = min(b, c)
    p = min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n)
    return {"a_only": b, "b_only": c, "p_value": round(p, 6)}


def fmt_pct(x):
    return f"{100 * x['rate']:.1f}% ({x['k']}/{x['n']}, CI {100 * x['ci95'][0]:.0f}-{100 * x['ci95'][1]:.0f})" if x["n"] else "n/a"


def report(label, m):
    lines = [f"## {label}", f"exact match            {fmt_pct(m['exact'])}",
             f"strict exact (+order)  {fmt_pct(m['strict_exact'])}",
             f"exact on route-gold    {fmt_pct(m['exact_on_route_gold'])}",
             f"critical negation set  {fmt_pct(m['critical_negation_subset'])}",
             f"ambiguity subset       {fmt_pct(m['ambiguity_subset'])}",
             f"unrequested external   {fmt_pct(m['unrequested_external_action'])}",
             f"macro F1 (support>=5)  {m['macro_f1_support_ge5']}",
             f"ordering end-to-end    {fmt_pct(m['ordering_end_to_end'])}",
             f"ordering | set right  {fmt_pct(m['ordering_given_correct_set'])}",
             f"false security         {fmt_pct(m['false_security'])}",
             f"clarify rate           {fmt_pct(m['clarify_rate'])}",
             f"unwarranted clarify    {fmt_pct(m['unwarranted_clarify'])}",
             f"missed clarify         {fmt_pct(m['missed_clarify'])}",
             f"unsupported tool sel.  {fmt_pct(m['unsupported_tool_selection'])}",
             "by language:  " + "  ".join(f"{k} {100 * v['rate']:.0f}% ({v['k']}/{v['n']})" for k, v in m["by_lang"].items()),
             "by category:  " + "  ".join(f"{k} {100 * v['rate']:.0f}% ({v['k']}/{v['n']})" for k, v in m["by_cat"].items()),
             "by difficulty:" + "  ".join(f"{k} {100 * v['rate']:.0f}% ({v['k']}/{v['n']})" for k, v in m["by_difficulty"].items())]
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--set", choices=sorted(SETS), required=True)
    ap.add_argument("--omega", default=str(DEFAULT_OMEGA))
    ap.add_argument("--compare", nargs="+")
    ap.add_argument("--labels", nargs="+")
    ap.add_argument("--json")
    ap.add_argument("--errors", action="store_true")
    a = ap.parse_args(argv)
    cases = load_cases(SETS[a.set])
    env = {"OMEGA_SKILL_ROOTS": str(FIXTURE_SKILLS), "OMEGA_SESSION_TOOLS": "", "OMEGA_AUTHORIZED": ""}
    inventory = fixture_inventory()
    paths = a.compare or [a.omega]
    labels = a.labels or [Path(p).parent.parent.parent.parent.name or p for p in paths]
    out, all_rows = {}, []
    for label, path in zip(labels, paths):
        mod = load_router(path, env)
        m, rows = evaluate(mod, cases, inventory)
        out[label] = m
        all_rows.append(rows)
        print(report(f"{label} on {a.set} ({len(cases)} prompts)", m))
        if a.errors:
            for r in rows:
                if not r["judge"]["exact"]:
                    print(f"   x {r['id']:<9} {r['lang']:<5} {r['cat']:<10} pred={r['pred']['decision']}:{r['pred']['plan']}  gold={r['expect']}  | {r['prompt']}")
        print()
    if len(all_rows) > 1:
        out["paired"] = {}
        for i in range(len(all_rows) - 1):
            key = f"{labels[i]} vs {labels[-1]}"
            out["paired"][key] = mcnemar(all_rows[i], all_rows[-1])
            print(f"paired exact-match test {key}: {out['paired'][key]}")
    if a.json:
        Path(a.json).write_text(json.dumps({"set": a.set, "n": len(cases), "results": out,
                                            "rows": {l: [{k: r[k] for k in ('id', 'lang', 'cat', 'prompt', 'expect', 'pred', 'judge')} for r in rows]
                                                     for l, rows in zip(labels, all_rows)}},
                                           ensure_ascii=False, indent=1), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
