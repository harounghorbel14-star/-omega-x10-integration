#!/usr/bin/env python3
"""Orchestration ledger tests: dependencies, verified hand-off, failure propagation, consent, reports."""
import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
spec = importlib.util.spec_from_file_location("omega_orchestrate_t", SCRIPTS / "omega_orchestrate.py")
orch = importlib.util.module_from_spec(spec)
spec.loader.exec_module(orch)


def plan(*steps, decision="multi"):
    """steps: (id, status, use, depends_on)"""
    return {"task": "t", "decision": decision,
            "steps": [{"id": i, "label": i, "subtask": i, "depends_on": d, "status": st, "use": u} for i, st, u, d in steps],
            "selected": [{"id": i, "use": u, "options": [{"name": "Canva", "key": "canva"}]} for i, st, u, d in steps]}


class Ledger(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.state = str(self.dir / "run.json")

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def file(self, name, data=b"x" * 10):
        p = self.dir / name
        p.write_bytes(data)
        return str(p)

    def test_dependency_order_and_verified_handoff(self):
        d = orch.init(plan(("image", "FALLBACK", "fb", []), ("video-animation", "FALLBACK", "fb", ["image"])), self.state)
        self.assertEqual([s["n"] for s in orch.ready(d)], [1])
        with self.assertRaises(SystemExit):
            orch.start(d, 2, self.state)
        orch.start(d, 1, self.state)
        orch.done(d, 1, [self.file("a.png")], state=self.state)
        self.assertEqual([s["n"] for s in orch.ready(d)], [2])
        inputs = orch.start(d, 2, self.state)
        self.assertEqual([Path(i["path"]).name for i in inputs], ["a.png"])
        orch.done(d, 2, [self.file("v.mp4")], state=self.state)
        self.assertTrue(orch.report(d)["complete"])

    def test_done_requires_real_output(self):
        d = orch.init(plan(("image", "FALLBACK", "fb", [])), self.state)
        orch.start(d, 1, self.state)
        with self.assertRaises(SystemExit):
            orch.done(d, 1, [], state=self.state)
        with self.assertRaises(SystemExit):
            orch.done(d, 1, [str(self.dir / "missing.png")], state=self.state)
        with self.assertRaises(SystemExit):
            orch.done(d, 1, [self.file("empty.png", b"")], state=self.state)

    def test_failure_skips_dependents_but_not_independent_steps(self):
        d = orch.init(plan(("web-research", "READY", "skill", []), ("image", "FALLBACK", "fb", []),
                           ("video-animation", "FALLBACK", "fb", ["image"])), self.state)
        orch.start(d, 2, self.state)
        orch.fail(d, 2, "crash", self.state)
        st = {s["id"]: s["status"] for s in d["steps"]}
        self.assertEqual(st, {"web-research": "pending", "image": "failed", "video-animation": "skipped"})
        self.assertEqual([s["n"] for s in orch.ready(d)], [1])
        self.assertFalse(orch.report(d)["complete"])

    def test_blocked_route_never_starts_and_blocks_dependents(self):
        d = orch.init(plan(("image", "FALLBACK", "fb", []), ("video-animation", "BLOCKED", "needs ffmpeg", ["image"]),
                           ("deployment-release", "FALLBACK", "fb", ["video-animation"])), self.state)
        st = {s["id"]: s["status"] for s in d["steps"]}
        self.assertEqual(st, {"image": "pending", "video-animation": "blocked", "deployment-release": "skipped"})
        with self.assertRaises(SystemExit):
            orch.start(d, 2, self.state)

    def test_tampered_artifact_stops_downstream(self):
        d = orch.init(plan(("image", "FALLBACK", "fb", []), ("video-animation", "FALLBACK", "fb", ["image"])), self.state)
        orch.start(d, 1, self.state)
        f = self.file("a.png")
        orch.done(d, 1, [f], state=self.state)
        Path(f).write_bytes(b"changed!!!")
        with self.assertRaises(SystemExit):
            orch.start(d, 2, self.state)
        self.assertEqual([s["status"] for s in d["steps"]], ["failed", "skipped"])

    def test_consent_gated_connector_needs_authorisation(self):
        d = orch.init(plan(("image", "READY", "connector: Canva", [])), self.state)
        with self.assertRaises(SystemExit):
            orch.start(d, 1, self.state, authorized=set())
        orch.start(d, 1, self.state, authorized={"canva"})
        self.assertEqual(d["steps"][0]["status"], "running")

    def test_clarify_creates_no_steps(self):
        d = orch.init({"task": "help", "decision": "clarify", "clarify_question": "What?", "steps": [], "selected": []}, self.state)
        rep = orch.report(d)
        self.assertFalse(rep["complete"])
        self.assertIn("clarification", rep["text"])

    def test_cli_end_to_end_partial_exit_code(self):
        env = {**os.environ, "OMEGA_SESSION_TOOLS": "", "OMEGA_AUTHORIZED": ""}
        cmd = [sys.executable, "-I", str(SCRIPTS / "omega.py"), "run"]
        out = subprocess.run(cmd + ["init", "a3melli image w ba3d 7awelha video", "--state", self.state], capture_output=True, text=True, env=env, timeout=60)
        self.assertEqual(out.returncode, 0, out.stderr)
        self.assertIn("video-animation", out.stdout)
        subprocess.run(cmd + ["start", "1", "--state", self.state], check=True, capture_output=True, env=env, timeout=60)
        r = subprocess.run(cmd + ["done", "1", "--artifact", self.file("i.png"), "--state", self.state], capture_output=True, text=True, env=env, timeout=60)
        self.assertEqual(r.returncode, 0, r.stderr)
        rep = subprocess.run(cmd + ["report", "--state", self.state], capture_output=True, text=True, env=env, timeout=60)
        self.assertEqual(rep.returncode, 3)
        self.assertIn("PARTIAL", rep.stdout)


if __name__ == "__main__":
    unittest.main()
