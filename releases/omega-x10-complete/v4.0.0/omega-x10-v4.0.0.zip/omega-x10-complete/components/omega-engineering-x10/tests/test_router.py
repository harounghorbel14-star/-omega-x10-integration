#!/usr/bin/env python3
"""Unit tests for omega.py routing, doctor and integrity checks. Standard library only.

  python3 -m unittest discover -s components/omega-engineering-x10/tests -v
"""
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
OMEGA = HERE.parent / "scripts" / "omega.py"
sys.path.insert(0, str(HERE))
import routing_bench  # noqa: E402


def load_omega():
    spec = importlib.util.spec_from_file_location("omega_under_test", OMEGA)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class RouterMechanics(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.o = load_omega()

    def test_generic_words_alone_never_select_a_route(self):
        for prompt in ["app", "my app", "the website", "build the app", "make the page", "our project", "help", "tool"]:
            res = self.o.route(prompt)
            self.assertEqual(res["selected"], [], prompt)
            self.assertIn(res["decision"], ("clarify", "none"), prompt)

    def test_app_never_triggers_security_without_security_evidence(self):
        for prompt in ["build a todo app", "deploy the app", "my app is slow", "create a landing page for my app", "app"]:
            ids = [s["id"] for s in self.o.route(prompt)["selected"]]
            self.assertNotIn("security", ids, prompt)

    def test_clarify_always_has_a_question(self):
        res = self.o.route("make it better")
        self.assertEqual(res["decision"], "clarify")
        self.assertTrue(res["clarify_question"].endswith("?"))

    def test_result_explains_itself(self):
        res = self.o.route("fix a race condition bug in a React task app and add regression tests")
        self.assertEqual(res["decision"], "multi")
        self.assertGreater(len(res["selected"][0]["why"]), 0)
        self.assertTrue(0 < res["confidence"] < 1)
        self.assertIn("react", res["stack"])
        self.assertIn("app", res["ignored_generic_words"])
        self.assertEqual(res["plan"], ["debugging", "tdd"])
        text = self.o.explain(res)
        self.assertIn("Decision: MULTI-INTENT", text)
        self.assertIn("race condition", text)

    def test_negative_evidence_is_reported(self):
        res = self.o.route("log in to the supplier portal and download last month's invoices")
        self.assertEqual(res["primary"], "browser-automation")
        scores = {s["id"]: s for s in self.o.route("log in to the portal")["selected"]}
        self.assertNotIn("security", scores)

    def test_clause_boundaries_are_respected(self):
        ids = [s["id"] for s in self.o.route("write the API, add tests, and deploy it")["selected"]]
        self.assertEqual(sorted(ids), ["deployment-release", "implementation", "tdd"])

    def test_same_evidence_is_counted_once(self):
        tdd = next(s for s in self.o.route("add regression tests")["selected"] if s["id"] == "tdd")
        self.assertEqual([h["match"] for h in tdd["why"] if h["layer"] == "regex"], ["add regression tests"])


class Availability(unittest.TestCase):
    def setUp(self):
        self.o = load_omega()
        self.empty = tempfile.mkdtemp()
        self.env = mock.patch.dict(os.environ, {"OMEGA_SKILL_ROOTS": self.empty})
        self.env.start()
        self.o.skill_inventory.cache_clear()

    def tearDown(self):
        self.env.stop()
        self.o.skill_inventory.cache_clear()
        shutil.rmtree(self.empty, ignore_errors=True)

    def test_connectors_alone_never_make_a_route_ready(self):
        img = self.o.route("design a logo icon for my startup")["selected"][0]
        self.assertEqual(img["id"], "image")
        self.assertNotEqual(img["status"], "READY")
        self.assertTrue(any(op["kind"] == "connector" and op["available"] is None for op in img["options"]))

    def test_photorealistic_request_is_flagged_as_beyond_the_fallback(self):
        img = self.o.route("generate a photorealistic picture of a lighthouse at dusk")["selected"][0]
        self.assertIn(img["status"], ("LIMITED", "BLOCKED"))
        self.assertIn("cannot produce photographic", img["limit"])

    def test_missing_fallback_tools_block_the_route(self):
        with mock.patch.object(self.o, "_need_met", return_value=False):
            vid = self.o.route("edit this video into a 30 second teaser with captions")["selected"][0]
        self.assertEqual(vid["status"], "BLOCKED")
        self.assertIn("ffmpeg", vid["use"])

    def test_installed_skill_makes_route_ready(self):
        d = Path(self.empty) / "deep-research"
        d.mkdir()
        (d / "SKILL.md").write_text("---\nname: deep-research\ndescription: x\n---\n")
        self.o.skill_inventory.cache_clear()
        res = self.o.route("research current best practices for securing localStorage data")
        self.assertEqual(res["selected"][0]["status"], "READY")
        self.assertIn("deep-research", res["selected"][0]["use"])


class Integrity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.o = load_omega()

    def test_registry_is_clean(self):
        self.assertEqual(self.o.check_routes(), [])

    def test_every_internal_reference_in_this_package_resolves(self):
        ok, missing = self.o.check_references()
        self.assertEqual(missing, [])
        self.assertGreater(ok, 30)

    def test_check_intents_catches_bad_regex_and_generic_selectors(self):
        tmp = Path(tempfile.mkdtemp())
        try:
            for f in (HERE.parent / "registry").glob("*.json"):
                shutil.copy(f, tmp / f.name)
            reg = json.loads((tmp / "intents.json").read_text())
            reg["intents"][0]["signals"].append({"re": "(unclosed", "w": 2.5, "kind": "term"})
            reg["intents"][1]["signals"].append({"re": r"\bapp\b", "w": 4.0, "kind": "phrase"})
            (tmp / "intents.json").write_text(json.dumps(reg))
            with mock.patch.object(self.o, "REG", tmp):
                problems = self.o.check_intents()
            self.assertTrue(any("bad regex" in p for p in problems), problems)
            self.assertTrue(any("generic word 'app'" in p for p in problems), problems)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_reference_scanner_handles_plain_glob_placeholder_and_links(self):
        tmp = Path(tempfile.mkdtemp())
        try:
            (tmp / "references" / "stage-a").mkdir(parents=True)
            (tmp / "references" / "stage-a" / "stage-a.md").write_text("x")
            (tmp / "README.md").write_text(
                "`references/stage-a/stage-a.md` `references/stage-*/stage-*.md` `references/stage-<n>/stage-<n>.md`\n"
                "`references/missing.py` `sources/stage-<n>/SKILL.md` [ok](references/stage-a/) [bad](references/nope.md)\n")
            ok, missing = self.o.check_references(tmp)
            self.assertEqual(ok, 4)
            self.assertEqual(sorted(m.split(" -> ")[1] for m in missing),
                             ["(references/nope.md)", "references/missing.py", "sources/stage-<n>/SKILL.md"])
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_doctor_exits_1_on_a_fatal_problem_and_names_it(self):
        pkg = HERE.parent.parent.parent
        if not (pkg / "SKILL.md").exists():
            self.skipTest("component installed standalone")
        tmp = Path(tempfile.mkdtemp()) / "pkg"
        try:
            shutil.copytree(pkg, tmp, ignore=shutil.ignore_patterns(".git", "__pycache__"))
            md = tmp / "components" / "omega-ai-engineer" / "references" / "workflows" / "omega-image-studio.md"
            md.write_text(md.read_text() + "\nSee `references/does-not-exist.py`.\n")
            script = tmp / "components" / "omega-engineering-x10" / "scripts" / "omega.py"
            out = subprocess.run([sys.executable, "-I", str(script), "doctor", "--offline", "--json"], capture_output=True, text=True, timeout=120)
            self.assertEqual(out.returncode, 1, out.stderr)
            data = json.loads(out.stdout)
            refs = next(c for c in data["checks"] if c["check"] == "internal file references")
            self.assertFalse(refs["ok"])
            self.assertTrue(any("does-not-exist.py" in m for m in refs["missing"]))
        finally:
            shutil.rmtree(tmp.parent, ignore_errors=True)


class RoutingBench(unittest.TestCase):
    """Accuracy guard. Floors are the recorded results; lowering one needs a written reason."""

    FLOORS = {"routing_cases.json": 54, "routing_cases_heldout.json": 40, "routing_cases_heldout2.json": 34,
              "routing_cases_heldout3.json": 18}

    def test_floors(self):
        for name, floor in self.FLOORS.items():
            rows = routing_bench.run(str(OMEGA), [str(HERE / name)])
            passed = sum(r["pass"] for r in rows)
            self.assertGreaterEqual(passed, floor, f"{name}: {passed} < recorded {floor}")

    def test_blind_set_misroutes_stay_rare(self):
        rows = routing_bench.run(str(OMEGA), [str(HERE / "routing_cases_heldout3.json")])
        misroutes = [r for r in rows if not r["pass"] and (r["primary"] not in ("none", "clarify")
                                                           or any("forbidden" in p for p in r["problems"]))]
        self.assertLessEqual(len(misroutes), 3, [r["id"] for r in misroutes])


if __name__ == "__main__":
    unittest.main()
