"""v4 regression tests for every Phase 3 failure class (A-H), each with positive, negative, adversarial and
paraphrase cases. Each case states the acceptable plans (ordered), or NOROUTE (answer/clarify, run nothing),
CLARIFY or NONE. These prompts were written for this suite; none is copied from a validation or blind set.

Expected outcome notation:
  ["a", "b"]  exact plan, in order        NOROUTE  decision is none or clarify (nothing executes)
  CLARIFY     decision must be clarify    NONE     decision must be none
  {"has": [...], "not": [...]}  required / forbidden intents in the plan
"""
import os
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))
os.environ.setdefault("OMEGA_SKILL_ROOTS", str(HERE / "fixtures" / "_none"))
import omega as O  # noqa: E402

NOROUTE, CLARIFY, NONE = "NOROUTE", "CLARIFY", "NONE"

CASES = {
    "A-negation": [
        # positive: descriptive negation is a malfunction report
        ("Images don't load", ["debugging"]),
        ("the checkout button doesn't respond on iOS", ["debugging"]),
        ("لا تصل الإشعارات للمستخدمين", ["debugging"]),
        ("الصور ما تطلعش في الصفحة", ["debugging"]),
        ("el site ma tetla3ch 3and el clients", ["debugging"]),
        ("les mails n'arrivent plus depuis hier", ["debugging"]),
        # negative: imperative negation removes the intent
        ("Do not create an image", NOROUTE),
        ("Leave the existing file alone", NOROUTE),
        ("ma ndeployiwech lyoum", NOROUTE),
        ("fix the login bug but do not deploy", ["debugging"]),
        ("corrige le bug, ne déploie rien", ["debugging"]),
        ("ma tdeployich taw, sala7 el bug mta3 el pagination", ["debugging"]),
        ("el video mouch lazma, a3mel ken el logo", ["image"]),
        ("لا تنشر التطبيق، فقط صلح الخطأ", ["debugging"]),
        # adversarial: negation far from the verb, mixed scripts
        ("please DON'T push anything to prod!!! just write the unit tests", ["tdd"]),
        ("sans toucher au design, ajoute un filtre par date", ["implementation"]),
        # paraphrase
        ("no need for a video, just the poster", ["image"]),
        ("pas besoin de déployer, écris juste les tests", ["tdd"]),
    ],
    "B-vocabulary": [
        ("notifications stopped arriving after the update", ["debugging"]),
        ("propose une palette de couleurs pour mon app", ["ui-ux-design"]),
        ("fais une maquette de l'écran de profil", ["ui-ux-design"]),
        ("nos5a mta3 Airbnb ama lel kra fi Tounes", ["app-replication"]),
        ("صلحها الدالة اللي تحسب المجموع، تطلع نتيجة غالطة", ["debugging"]),
        ("go over this diff and tell me what's risky", ["code-review"]),
    ],
    "C-verb-object": [
        ("make this endpoint faster", ["performance"]),
        ("export the document as a PDF report", ["documents"]),
        ("find why the payment bug happens", ["debugging"]),
        ("find current info about the latest Next.js release", ["web-research"]),
        ("implement the password reset flow", ["implementation"]),
        ("write tests for the cart total", ["tdd"]),
        # negative: same verbs, different objects
        ("find the file where the router is defined", {"not": ["web-research"]}),
        ("export data from the Shopify admin dashboard", {"has": ["browser-automation"], "not": ["implementation"]}),
    ],
    "D-multi-step": [
        ("fix the crash, then add regression tests, then deploy to staging", ["debugging", "tdd", "deployment-release"]),
        ("deploy it after you fix the crash and add a test", ["debugging", "tdd", "deployment-release"]),
        ("before deploying, run the tests", ["tdd", "deployment-release"]),
        ("a3melli logo w ba3d 7awlou video", ["image", "video-animation"]),
        ("recherche les meilleurs frameworks puis rédige un rapport comparatif", ["web-research", "documents"]),
        ("صمم واجهة التطبيق ثم برمجها", ["ui-ux-design", "implementation"]),
    ],
    "E-arabizi-collisions": [
        ("ajoute un bouton contact en bas de page", {"has": ["implementation"], "not": ["performance", "debugging"]}),
        ("boutique en ligne pour mes bijoux, je veux le site complet", {"not": ["debugging", "performance"]}),
        ("tahni2a l omi b 3id miledha", NOROUTE),
        ("scraping des prix sur un site concurrent", {"has": ["browser-automation"], "not": ["security"]}),
        ("el app ti7 ki n7el el page", ["debugging"]),
    ],
    "F-prefix-overmatch": [
        ("liste des hébergeurs gratuits pour étudiants", {"not": ["deployment-release"]}),
        ("write a short bio for my GitHub profile", NOROUTE),
        ("profile the API, it's slow under load", ["performance"]),
        ("héberge mon site sur OVH", ["deployment-release"]),
    ],
    "G-discussion-vs-action": [
        ("Is this tool worth using?", NONE),
        ("Is this feature free?", NONE),
        ("C'est vraiment utile ?", NONE),
        ("هل هذا مجاني؟", NONE),
        ("Explain how browser automation works", NONE),
        ("what is the difference between Docker and Kubernetes", NONE),
        ("Use browser automation to download my invoices from the portal", ["browser-automation"]),
        ("is figma still free in 2026?", NONE),
    ],
    "H-clarification": [
        ("fix it", CLARIFY),
        ("make it better", CLARIFY),
        ("do the thing we talked about", CLARIFY),
        ("sala7ha", CLARIFY),
        # clear requests must not be asked to clarify
        ("add a dark mode toggle to the settings page of my React app", {"has": ["implementation"]}),
        ("write a commit message and push my branch", ["git-workflow"]),
    ],
}


def judge(res, want):
    d, plan = res["decision"], res["plan"]
    if want == NOROUTE:
        return d in ("none", "clarify")
    if want == CLARIFY:
        return d == "clarify"
    if want == NONE:
        return d == "none"
    if isinstance(want, dict):
        return d in ("route", "multi") and set(want.get("has", [])) <= set(plan) and not set(want.get("not", [])) & set(plan) \
            if want.get("has") else not set(want.get("not", [])) & set(plan)
    return d in ("route", "multi") and plan == want


class FailureClasses(unittest.TestCase):
    pass


def _make(cls, k, prompt, want):
    def t(self):
        res = O.route(prompt)
        self.assertTrue(judge(res, want), f"[{cls}] {prompt!r}: got {res['decision']} {res['plan']} (want {want}); "
                                          f"layers={res['layers']['rules']}, fusion={res['layers']['classifier'].get('fusion')}")
    return t


for _cls, _cases in CASES.items():
    for _k, (_p, _w) in enumerate(_cases):
        setattr(FailureClasses, f"test_{_cls.replace('-', '_')}_{_k:02d}", _make(_cls, _k, _p, _w))


class LayerFallbacks(unittest.TestCase):
    def test_rules_only_mode_is_explicit(self):
        os.environ["OMEGA_CLASSIFIER"] = "off"
        try:
            res = O.route("fix the login crash")
            self.assertFalse(res["layers"]["classifier"]["used"])
            self.assertEqual(res["plan"], ["debugging"])
        finally:
            os.environ.pop("OMEGA_CLASSIFIER", None)

    def test_classifier_layer_reports_probabilities_and_evidence(self):
        res = O.route("write unit tests for the parser")
        clf = res["layers"]["classifier"]
        self.assertIn("tdd", clf["chosen"])
        self.assertTrue(clf["evidence"]["tdd"])

    def test_malformed_pattern_never_crashes(self):
        self.assertIsNone(O._rx("(unclosed"))
        self.assertIsNone(O._search("[z-a]", "text"))


if __name__ == "__main__":
    unittest.main()


class ExternalAdapter(unittest.TestCase):
    """The optional LLM/embedding adapter is never used without explicit consent and always falls back offline."""

    def setUp(self):
        import tempfile
        self.marker = Path(tempfile.mkdtemp()) / "called"
        self.saved = {k: os.environ.get(k) for k in ("OMEGA_ADAPTER_CMD", "OMEGA_ADAPTER_CONSENT")}

    def tearDown(self):
        for k, v in self.saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    def cmd(self, mode):
        import json
        return json.dumps([sys.executable, str(HERE / "fixtures" / "fake_adapter.py"), mode, str(self.marker)])

    def test_not_called_without_consent(self):
        os.environ["OMEGA_ADAPTER_CMD"] = self.cmd("ok")
        os.environ.pop("OMEGA_ADAPTER_CONSENT", None)
        res = O.route("hmm")
        self.assertFalse(res["layers"]["adapter"]["used"])
        self.assertIn("not 'granted'", res["layers"]["adapter"]["why"])
        self.assertFalse(self.marker.exists())

    def test_default_is_off(self):
        os.environ.pop("OMEGA_ADAPTER_CMD", None)
        self.assertIn("not configured", O.route("fix the crash")["layers"]["adapter"]["why"])

    def test_failure_falls_back_offline(self):
        os.environ.update(OMEGA_ADAPTER_CMD=self.cmd("fail"), OMEGA_ADAPTER_CONSENT="granted")
        res = O.route("fix the login crash")
        self.assertTrue(self.marker.exists())
        self.assertFalse(res["layers"]["adapter"]["used"])
        self.assertEqual(res["plan"], ["debugging"])

    def test_invalid_output_ignored(self):
        for mode in ("garbage", "unknown-intent"):
            os.environ.update(OMEGA_ADAPTER_CMD=self.cmd(mode), OMEGA_ADAPTER_CONSENT="granted")
            res = O.route("fix the login crash")
            self.assertFalse(res["layers"]["adapter"]["used"], mode)
            self.assertEqual(res["plan"], ["debugging"])

    def test_confident_offline_decision_is_not_overridden(self):
        os.environ.update(OMEGA_ADAPTER_CMD=self.cmd("ok"), OMEGA_ADAPTER_CONSENT="granted")
        res = O.route("write unit tests for the parser module")
        self.assertTrue(res["layers"]["adapter"]["used"])
        self.assertFalse(res["layers"]["adapter"]["override"])
        self.assertEqual(res["plan"], ["tdd"])


class RegexPathology(unittest.TestCase):
    """Fuzz: no input may crash the router or take pathological time (catastrophic backtracking)."""

    def test_fuzz_and_pathological_inputs(self):
        import random
        import time
        rnd = random.Random(4)
        alphabet = "abcdefghijklmnopqrstuvwxyz 0123456789'-.,!?;:()[]{}*+\\|/éèàçوالمنتجحسبي3795٫؟" + "‏‮\t\n"
        cases = ["a" * 6000, "fix " * 1500, "!" * 5000, "ما " * 2000, "don't " * 800, "(" * 3000, "a-" * 3000,
                 "deploy it after " * 300, "http://" + "x." * 2000 + "com", "\x00\x01\x02 fix the bug"]
        cases += ["".join(rnd.choice(alphabet) for _ in range(rnd.randint(1, 400))) for _ in range(300)]
        worst = 0.0
        for c in cases:
            t = time.perf_counter()
            res = O.route(c)
            worst = max(worst, time.perf_counter() - t)
            self.assertIn(res["decision"], ("route", "multi", "clarify", "none"))
        self.assertLess(worst, 5.0, f"slowest input took {worst:.2f}s")
