"""v4 workflow engine tests: the declared multi-step gate matrix plus focused unit checks."""
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))
sys.path.insert(0, str(HERE))
import omega_workflow as W  # noqa: E402
import workflow_gate as G  # noqa: E402


class Gate(unittest.TestCase):
    def test_declared_matrix_passes_every_criterion(self):
        results, crit, _ = G.run_matrix()
        failed = [r for r in results if not r["pass"]]
        self.assertEqual(failed, [])
        for k, (ok, n) in crit.items():
            self.assertEqual(ok, n, k)
            self.assertGreater(n, 0, k)


class Units(unittest.TestCase):
    def test_cycle_message_names_the_cycle(self):
        with self.assertRaisesRegex(W.SpecError, "cycle: a -> b -> a|cycle: b -> a -> b"):
            W.validate_spec({"steps": [G.step("a", pre=["b"]), G.step("b", pre=["a"])]})

    def test_levels_group_independent_steps(self):
        by_id, order = W.validate_spec({"steps": [G.step("a"), G.step("b"), G.step("c", pre=["a", "b"])]})
        self.assertEqual(W.levels(by_id, order), [["a", "b"], ["c"]])

    def test_output_validators(self):
        d = Path(tempfile.mkdtemp())
        (d / "x.json").write_text('{"k": 1}')
        self.assertIsNone(W.validate_output(d / "x.json", {"type": "json", "json_keys": ["k"]}))
        self.assertIn("missing keys", W.validate_output(d / "x.json", {"json_keys": ["z"]}))
        (d / "y.png").write_bytes(b"GIF89a....")
        self.assertIn("bad signature", W.validate_output(d / "y.png", {"type": "png"}))
        self.assertIn("missing", W.validate_output(d / "nope", {}))
        (d / "e.txt").write_text("")
        self.assertIn("min_bytes", W.validate_output(d / "e.txt", {}))
        self.assertIn("invalid validation regex", W.validate_output(d / "x.json", {"regex": "("}))

    def test_safe_rel_rejects_escape(self):
        d = tempfile.mkdtemp()
        for bad in ("../x", "/etc/passwd", "a/../../x", ""):
            with self.assertRaises(W.SpecError):
                W._safe_rel(bad, d)

    def test_redaction(self):
        self.assertNotIn("sk-123", W.redact("token=sk-123 and password: hunter2"))
        self.assertNotIn("hunter2", W.redact("token=sk-123 and password: hunter2"))

    def test_from_route_gates_deploy(self):
        import omega  # noqa: PLC0415
        spec = W.from_route(omega.route("fix the crash then deploy to production"))
        gate = {s["capability"]: s["requires_confirmation"] for s in spec["steps"]}
        self.assertEqual(gate.get("deployment-release"), "deployment")


if __name__ == "__main__":
    unittest.main()
