#!/usr/bin/env python3
"""Threshold selection on the validation set (aggregates only; no per-item output).

  python3 threshold_sweep.py [--apply]

Objective: exact match on validation, minus 0.5 x unwarranted-clarify rate (so a router that asks
about everything cannot win), with every Phase-2 routing set as a no-regression guard.
--apply writes the chosen thresholds into registry/intents.json.
"""
import argparse
import copy
import itertools
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import routing_bench  # noqa: E402
import routing_eval  # noqa: E402

GRID = {"select_min": [2.0, 2.5, 3.0, 3.5], "secondary_ratio": [0.3, 0.4, 0.5, 0.6], "clarify_min_signal": [1.0, 1.5]}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args(argv)
    env = {"OMEGA_SKILL_ROOTS": str(routing_eval.FIXTURE_SKILLS), "OMEGA_SESSION_TOOLS": "", "OMEGA_AUTHORIZED": ""}
    mod = routing_eval.load_router(routing_eval.DEFAULT_OMEGA, env)
    base = mod.load("intents.json")
    original_load = mod.load
    val = routing_eval.load_cases(routing_eval.SETS["validation"])
    inv = routing_eval.fixture_inventory()
    phase2 = sorted(HERE.glob("routing_cases*.json"))
    results = []
    for combo in itertools.product(*GRID.values()):
        th = dict(zip(GRID, combo))
        reg = copy.deepcopy(base)
        reg["thresholds"].update(th)
        mod.load = lambda name, _r=reg: _r if name == "intents.json" else original_load(name)
        m, _ = routing_eval.evaluate(mod, val, inv)
        guard = sum(r["pass"] for r in routing_bench.run_module(mod, [str(p) for p in phase2]))
        obj = m["exact"]["rate"] - 0.5 * (m["unwarranted_clarify"]["rate"] or 0)
        results.append((obj, guard, th, m["exact"]["rate"], m["unwarranted_clarify"]["rate"], m["missed_clarify"]["rate"]))
    mod.load = original_load
    guard_max = max(r[1] for r in results)
    ok = [r for r in results if r[1] == guard_max]
    ok.sort(key=lambda r: (-r[0], abs(r[2]["select_min"] - 2.5) + abs(r[2]["secondary_ratio"] - 0.4)))
    print(f"{'objective':>9} {'exact':>6} {'unw.clar':>8} {'miss.clar':>9} {'phase2':>6}  thresholds")
    for r in sorted(results, key=lambda r: -r[0])[:12]:
        print(f"{r[0]:9.3f} {r[3]:6.3f} {r[4]:8.3f} {r[5]:9.3f} {r[1]:6d}  {r[2]}")
    best = ok[0]
    print("\nchosen (max objective among full Phase-2 guard, nearest to current on ties):", best[2])
    if a.apply:
        p = HERE.parent / "registry" / "intents.json"
        d = json.loads(p.read_text(encoding="utf-8"))
        d["thresholds"].update(best[2])
        p.write_text(json.dumps(d, indent=1, ensure_ascii=False), encoding="utf-8")
        print("written to", p)
    return 0


if __name__ == "__main__":
    sys.exit(main())
