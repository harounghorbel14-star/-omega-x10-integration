#!/usr/bin/env bash
# Reproduce registry/classifier.json (deterministic). Needs numpy + scikit-learn at training time only.
# Data: development corpora; the v4 validation set was folded in only after model selection (see CHANGELOG).
# The blind sets (corpus/v4/blind4*) are never training data for the candidate they evaluate. blind4a was
# evaluated once on candidate C1 and then retired to development data for C2 (evaluated on the fresh blind4b).
set -euo pipefail
cd "$(dirname "$0")"
T=corpus
POL='{"tau": 0.5, "tau_low": 0.15, "tau_override": 0.9, "rule_backed_min_p": 0.1, "clause_tau": 0.7, "rule_concrete_min_p": 0.05, "tau_i": {"implementation": 0.6, "debugging": 0.7, "tdd": 0.6, "code-review": 0.4, "security": 0.65, "ui-ux-design": 0.35, "web-research": 0.45, "image": 0.7, "browser-automation": 0.25, "performance": 0.7, "planning": 0.25, "documents": 0.45, "repository-architecture": 0.45, "git-workflow": 0.4}}'
DATA=("$T/dev.jsonl" "$T/blind/blind.jsonl" "$T/v4/dev4.jsonl" "$T/v4/train4.jsonl" "$T/v4/train5.jsonl" "$T/v4/train6.jsonl" "$T/v4/train7.jsonl" "$T/v4/blind4a/blind4a.jsonl"
      "$T/validation.jsonl" "$T/v4/val4.jsonl" routing_cases*.json ${EXTRA_DATA:-})
python3 ../scripts/omega_train.py --data "${DATA[@]}" --allow-name validation.jsonl val4.jsonl blind4a.jsonl ${EXTRA_ALLOW:-} \
  --C 16 --policy "$POL" --out ../registry/classifier.json "$@"
