#!/usr/bin/env python3
"""Multi-step acceptance gate: a declared matrix of workflow scenarios run against the real executor
(scripts/omega_workflow.py) with deterministic fake tools (tests/fixtures/fake_tool.py). Standard library only.

Every scenario states the expected workflow status and per-step statuses. Independently of those expectations,
the gate audits the ledger of every run for the invariants below, so a wrong expectation cannot hide a defect:
  prerequisite_enforcement  no step started before all its prerequisites were COMPLETE
  dependent_prevention      no step ran when a required (transitive) prerequisite FAILED/BLOCKED/SKIPPED
  artifact_integrity        every COMPLETE step's artifacts exist and match their recorded sha256
  no_false_complete         a COMPLETE step always has validated outputs or evidence (never exit code alone)
  status_reporting          workflow and step statuses equal the declared expectation
  invalid_spec_detection    malformed specs (cycles, unknown/duplicate ids, traversal, shell strings...) are rejected
  happy_path_success        workflows with every tool available and valid inputs end COMPLETE
  routing_steps             router plans for the declared multi-step prompts (ids and order) match

  python3 workflow_gate.py [--json OUT] [--keep DIR]
"""
import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
sys.path.insert(0, str(SCRIPTS))
import omega_workflow as W  # noqa: E402

FAKE = str(HERE / "fixtures" / "fake_tool.py")
PY = sys.executable


def step(sid, mode="ok", pre=(), inputs=None, validate=None, out="out/{sid}.txt", **kw):
    inputs = inputs or {}
    cmd = [PY, FAKE, mode, "--out", "{out:main}", "--content", f"{sid}-OK"]
    for name in inputs:
        cmd += ["--in", "{in:" + name + "}"]
    for k in ("state", "fail_times", "sleep"):
        if k in kw:
            cmd += ["--" + k.replace("_", "-"), str(kw.pop(k))]
    s = {"id": sid, "action": sid, "capability": kw.pop("capability", "tool:python"), "prerequisites": list(pre),
         "inputs": inputs, "command": cmd,
         "outputs": {"main": {"path": out.format(sid=sid), "validate": validate or {"min_bytes": 1, "contains": f"{sid}-OK"}}}}
    s.update(kw)
    return s


def chain(names, modes=None, **kw):
    modes = modes or {}
    steps = []
    for k, n in enumerate(names):
        pre = [names[k - 1]] if k else []
        inp = {"prev": names[k - 1] + ".main"} if k else {}
        m = modes.get(n, "concat" if k else "ok")
        val = {"min_bytes": 1, "contains": f"{n}-OK"}
        steps.append(step(n, m, pre, inp, val, **kw.get(n, {})))
    return steps


CAPS = ["tool:python"]


def scenarios(tmp):
    S = []

    def add(name, steps, expect, steps_expect=None, caps=CAPS, confirm=(), happy=False, final=None, tags=()):
        S.append({"name": name, "spec": {"name": name, "steps": steps, **({"final_deliverables": final} if final else {})},
                  "caps": caps, "confirm": list(confirm), "expect": expect, "steps_expect": steps_expect or {},
                  "happy": happy, "tags": list(tags)})

    add("chain-2", chain(["a", "b"]), "COMPLETE", {"a": "COMPLETE", "b": "COMPLETE"}, happy=True, final=["b.main"])
    add("chain-3", chain(["a", "b", "c"]), "COMPLETE", happy=True, final=["c.main"])
    add("diagnose-fix-unit-integration-report", chain(["diagnose", "fix", "unit_tests", "integration_tests", "report"]),
        "COMPLETE", happy=True, final=["report.main"])
    add("chain-10", chain([f"s{i}" for i in range(1, 11)]), "COMPLETE", happy=True, final=["s10.main"])
    research = [step("research", "json", validate={"type": "json", "json_keys": ["status"]}, out="out/research.json"),
                step("compare", "json", ["research"], {"src": "research.main"}, {"type": "json", "json_keys": ["inputs"]}, out="out/compare.json"),
                step("synthesize", "concat", ["compare"], {"src": "compare.main"}),
                step("document", "concat", ["synthesize"], {"src": "synthesize.main"})]
    add("research-compare-synthesize-document", research, "COMPLETE", happy=True, final=["document.main"])
    media = [step("generate_image", "png", validate={"type": "png", "min_bytes": 16}, out="out/img.png"),
             step("validate_image", "ok", ["generate_image"], {"img": "generate_image.main"}),
             step("convert_to_video", "concat", ["validate_image"], {"v": "validate_image.main"}),
             step("inspect_video", "concat", ["convert_to_video"], {"v": "convert_to_video.main"})]
    add("image-validate-video-inspect", media, "COMPLETE", happy=True, final=["inspect_video.main"])
    add("implement-tests-run(flaky)-fix-rebuild",
        chain(["implement", "write_tests", "run_tests", "fix_regressions", "rebuild"], modes={"run_tests": "flaky"},
              run_tests={"state": str(tmp / "flaky1"), "fail_times": 1, "retry": {"max_attempts": 2}}),
        "COMPLETE", {"run_tests": "COMPLETE"}, happy=True, tags=["retry"])
    add("build-typecheck-lint(fail)-unit-e2e-package",
        chain(["build", "typecheck", "lint", "unit", "e2e", "package"], modes={"lint": "fail"}),
        "PARTIAL", {"build": "COMPLETE", "typecheck": "COMPLETE", "lint": "FAILED", "unit": "SKIPPED", "e2e": "SKIPPED", "package": "SKIPPED"})
    add("analyze-identify-fix-rescan", chain(["analyze_repo", "identify_vulns", "fix_findings", "rescan"]), "COMPLETE", happy=True)
    agg = [step("art_a"), step("art_b"), step("art_c"),
           step("aggregate", "concat", ["art_a", "art_b", "art_c"], {"a": "art_a.main", "b": "art_b.main", "c": "art_c.main"},
                {"contains": ["art_a-OK", "art_b-OK", "art_c-OK", "aggregate-OK"]})]
    add("independent-artifacts-aggregate", agg, "COMPLETE", happy=True, final=["aggregate.main"])
    agg_fail = [step("art_a"), step("art_b", "fail"), step("art_c"),
                step("aggregate", "concat", ["art_a", "art_b", "art_c"], {"a": "art_a.main", "b": "art_b.main", "c": "art_c.main"})]
    add("aggregate-with-failed-branch", agg_fail, "PARTIAL",
        {"art_a": "COMPLETE", "art_b": "FAILED", "art_c": "COMPLETE", "aggregate": "SKIPPED"})
    opt = [step("core"), step("polish", capability="tool:optimizer", optional=True, prerequisites=["core"]),
           step("ship_report", "concat", ["core", "polish"], {"c": "core.main", "p": "polish.main"})]
    add("missing-optional-tool", opt, "COMPLETE", {"core": "COMPLETE", "polish": "SKIPPED", "ship_report": "COMPLETE"}, tags=["optional"])
    req = [step("make_model", capability="tool:blender"), step("render", "concat", ["make_model"], {"m": "make_model.main"}),
           step("write_notes")]
    add("missing-required-tool", req, "PARTIAL", {"make_model": "BLOCKED", "render": "SKIPPED", "write_notes": "COMPLETE"})
    add("failed-first-step", chain(["first", "second", "third"], modes={"first": "fail"}), "FAILED",
        {"first": "FAILED", "second": "SKIPPED", "third": "SKIPPED"})
    add("failed-step-plus-independent-branch", [step("x", "fail"), step("y", "concat", ["x"], {"i": "x.main"}), step("z")],
        "PARTIAL", {"x": "FAILED", "y": "SKIPPED", "z": "COMPLETE"})
    add("timeout", [step("slow", "slow", sleep=5, timeout_s=1), step("after", "concat", ["slow"], {"i": "slow.main"})], "FAILED",
        {"slow": "FAILED", "after": "SKIPPED"}, tags=["timeout"])
    add("retries-exhausted", [step("flaky", "flaky", state=str(tmp / "flaky2"), fail_times=5, retry={"max_attempts": 3})], "FAILED",
        {"flaky": "FAILED"}, tags=["retry"])
    add("corrupted-json-artifact", [step("emit", "corrupt-json", validate={"type": "json"}, out="out/emit.json"),
                                    step("use", "concat", ["emit"], {"i": "emit.main"})], "FAILED", {"emit": "FAILED", "use": "SKIPPED"})
    add("exit0-without-output", [step("liar", "exit0-no-output")], "FAILED", {"liar": "FAILED"}, tags=["no_false_complete"])
    add("empty-output", [step("hollow", "empty")], "FAILED", {"hollow": "FAILED"}, tags=["no_false_complete"])
    add("crash-exit-137", [step("boom", "crash")], "FAILED", {"boom": "FAILED"})
    dep = chain(["fix_bug", "run_tests"]) + [step("deploy", "concat", ["run_tests"], {"i": "run_tests.main"}, requires_confirmation="deployment")]
    add("deploy-needs-confirmation", dep, "PARTIAL", {"fix_bug": "COMPLETE", "run_tests": "COMPLETE", "deploy": "BLOCKED"}, tags=["confirmation"])
    add("deploy-confirmed", json.loads(json.dumps(dep)), "COMPLETE", {"deploy": "COMPLETE"}, confirm=["deploy"], happy=True)
    pub = [step("draft_post"), step("publish", "concat", ["draft_post"], {"i": "draft_post.main"}, requires_confirmation="publishing"),
           step("pay_invoice", requires_confirmation="financial"), step("wipe_cache", requires_confirmation="destructive")]
    add("publish-financial-destructive-gates", pub, "PARTIAL",
        {"draft_post": "COMPLETE", "publish": "BLOCKED", "pay_invoice": "BLOCKED", "wipe_cache": "BLOCKED"}, tags=["confirmation"])
    fb = [step("render_3d", capability="tool:blender", fallback_capability="tool:python",
               fallback_command=[PY, FAKE, "ok", "--out", "{out:main}", "--content", "render_3d-OK"])]
    add("fallback-capability-limited", fb, "COMPLETE", {"render_3d": "COMPLETE"}, tags=["limited"])
    sec = [step("leaky", "echo-secret")]
    add("secret-redaction-in-ledger", sec, "COMPLETE", {"leaky": "COMPLETE"}, tags=["redaction"])
    fin = [step("core"), step("extra", capability="tool:none", optional=True, prerequisites=["core"])]
    add("final-deliverable-missing", fin, "PARTIAL", {"core": "COMPLETE", "extra": "SKIPPED"}, final=["extra.main"])
    return S


ABS_PATH = "/" + "tmp/abs.txt"  # deliberately absolute: the validator must reject it
INVALID = {
    "cycle": {"steps": [step("a", pre=["b"]), step("b", pre=["a"])]},
    "cycle-3": {"steps": [step("a", pre=["c"]), step("b", pre=["a"]), step("c", pre=["b"])]},
    "self-dependency": {"steps": [step("a", pre=["a"])]},
    "unknown-prerequisite": {"steps": [step("a", pre=["ghost"])]},
    "duplicate-id": {"steps": [step("a"), step("a")]},
    "input-not-a-prerequisite": {"steps": [step("a"), step("b", inputs={"x": "a.main"})]},
    "input-undeclared-output": {"steps": [step("a"), step("b", pre=["a"], inputs={"x": "a.nothing"})]},
    "path-traversal": {"steps": [step("a", out="../escape.txt")]},
    "absolute-path": {"steps": [step("a", out=ABS_PATH)]},
    "shell-string-command": {"steps": [{**step("a"), "command": "python3 x.py && rm -rf /"}]},
    "no-outputs-no-evidence": {"steps": [{**step("a"), "outputs": {}}]},
    "retry-unbounded": {"steps": [step("a", retry={"max_attempts": 50})]},
    "timeout-out-of-range": {"steps": [step("a", timeout_s=0)]},
    "bad-confirmation-kind": {"steps": [step("a", requires_confirmation="maybe")]},
    "empty-steps": {"steps": []},
    "bad-final-deliverable": {"steps": [step("a")], "final_deliverables": ["zzz.main"]},
}

ROUTE_CASES = [  # declared multi-step prompts (authored for this gate; NOT a blind set): expected plan ids in order
    ("fix the login crash, then add regression tests, then deploy to staging", ["debugging", "tdd", "deployment-release"]),
    ("deploy it after you fix the crash and add a test", ["debugging", "tdd", "deployment-release"]),
    ("research current vector databases, compare them and write a report", ["web-research", "documents"]),
    ("generate a product image then turn it into a short video", ["image", "video-animation"]),
    ("fix the bug but do not deploy", ["debugging"]),
    ("a3melli logo w ba3d 7awlou video, ma tpublishich", ["image", "video-animation"]),
    ("صلح المشكل في الكود وبعد زيد tests", ["debugging", "tdd"]),
    ("corrige le bug puis écris les tests unitaires, ne déploie rien", ["debugging", "tdd"]),
    ("before deploying, run the tests", ["tdd", "deployment-release"]),
    ("audit the repo for vulnerabilities, fix them, then commit and open a PR", ["security", "git-workflow"]),
]


def audit(spec, led, summary):
    by_id = {s["id"]: s for s in spec["steps"]}
    issues = {"prerequisite_enforcement": [], "dependent_prevention": [], "artifact_integrity": [], "no_false_complete": []}
    status_at = {}
    for ev in led["events"]:
        if ev.get("event") != "status":
            continue
        sid, st = ev["step"], ev["status"]
        if st == "RUNNING":
            for p in by_id[sid].get("prerequisites", []):
                if status_at.get(p) != "COMPLETE" and not (status_at.get(p) == "SKIPPED" and by_id[p].get("optional")):
                    issues["prerequisite_enforcement"].append(f"{sid} started while {p} was {status_at.get(p)}")
        status_at[sid] = st

    def ancestors(s, seen=None):
        seen = seen if seen is not None else set()
        for p in by_id[s].get("prerequisites", []):
            if p not in seen:
                seen.add(p)
                ancestors(p, seen)
        return seen

    for sid, rec in led["steps"].items():
        bad = [a for a in ancestors(sid) if led["steps"][a]["status"] in ("FAILED", "BLOCKED") or
               (led["steps"][a]["status"] == "SKIPPED" and not by_id[a].get("optional"))]
        if bad and rec["history"]:
            issues["dependent_prevention"].append(f"{sid} ran although {bad} did not complete")
        if rec["status"] == "COMPLETE":
            for name, a in rec["artifacts"].items():
                if not Path(a["path"]).is_file() or W.sha256(a["path"]) != a["sha256"]:
                    issues["artifact_integrity"].append(f"{sid}.{name} does not match its recorded hash")
            outs = by_id[sid].get("outputs") or {}
            if set(outs) != set(rec["artifacts"]) and not by_id[sid].get("evidence"):
                issues["no_false_complete"].append(f"{sid} COMPLETE without all declared outputs")
            last = rec["history"][-1] if rec["history"] else {}
            if last.get("result") != "ok":
                issues["no_false_complete"].append(f"{sid} COMPLETE but last attempt was {last.get('result')}")
    return issues


def run_matrix(keep=None):
    root = Path(keep) if keep else Path(tempfile.mkdtemp(prefix="omega-gate-"))
    root.mkdir(parents=True, exist_ok=True)
    results = []
    crit = {k: [0, 0] for k in ("status_reporting", "prerequisite_enforcement", "dependent_prevention", "artifact_integrity",
                                "no_false_complete", "happy_path_success", "invalid_spec_detection", "recovery", "routing_steps")}

    def tick(k, ok):
        crit[k][1] += 1
        crit[k][0] += bool(ok)

    for sc in scenarios(root):
        wd = root / sc["name"]
        shutil.rmtree(wd, ignore_errors=True)
        wd.mkdir(parents=True)
        spec_path = wd.parent / f"{sc['name']}.spec.json"
        spec_path.write_text(json.dumps(sc["spec"]), encoding="utf-8")
        summary, led = W.execute(spec_path, wd, sc["caps"], sc["confirm"])
        got = {s["id"]: s["status"] for s in summary["steps"]}
        wrong = {k: (v, got.get(k)) for k, v in sc["steps_expect"].items() if got.get(k) != v}
        ok_status = summary["status"] == sc["expect"] and not wrong
        tick("status_reporting", ok_status)
        iss = audit(sc["spec"], led, summary)
        for k, v in iss.items():
            tick(k, not v)
        if sc["happy"]:
            tick("happy_path_success", summary["status"] == "COMPLETE")
        extra = []
        if "redaction" in sc["tags"]:
            blob = json.dumps(led)
            if "sk-THIS-IS-FAKE" in blob:
                extra.append("secret visible in ledger")
                ok_status = False
        if "retry" in sc["tags"] and sc["expect"] == "COMPLETE" and led["steps"]["run_tests"]["attempts"] != 2:
            extra.append("retry not recorded as 2 attempts")
            ok_status = False
        results.append({"name": sc["name"], "expected": sc["expect"], "got": summary["status"], "step_mismatch": wrong,
                        "audit": {k: v for k, v in iss.items() if v}, "extra": extra, "pass": ok_status and not any(iss.values()) and not extra})

    for name, spec in INVALID.items():
        try:
            W.validate_spec(spec)
            ok, why = False, "accepted"
        except W.SpecError as exc:
            ok, why = True, str(exc)[:160]
        tick("invalid_spec_detection", ok)
        results.append({"name": f"invalid:{name}", "expected": "rejected", "got": "rejected" if ok else "accepted", "detail": why, "pass": ok})

    results += recovery_scenarios(root, tick)

    os.environ.setdefault("OMEGA_CLASSIFIER", "on")
    import omega  # noqa: PLC0415
    for prompt, want in ROUTE_CASES:
        plan = omega.route(prompt)["plan"]
        spec = W.from_route(omega.route(prompt))
        ok = plan == want and [s["capability"] for s in spec["steps"]] == want
        try:
            W.validate_spec({"steps": [{**s, "command": None} for s in spec["steps"]]})
        except W.SpecError as exc:
            ok = False
            plan = plan + [f"invalid spec: {exc}"]
        tick("routing_steps", ok)
        results.append({"name": f"route:{prompt[:50]}", "expected": want, "got": plan, "pass": ok})
    return results, crit, root


def recovery_scenarios(root, tick):
    out = []
    # 1. stale artifact: a step completes, its output is tampered with, resume must re-run producer and dependents
    wd = root / "recovery-stale"
    shutil.rmtree(wd, ignore_errors=True)
    wd.mkdir(parents=True)
    spec = {"name": "stale", "steps": [step("produce"), step("consume", "concat", ["produce"], {"i": "produce.main"},
                                                                capability="tool:late")]}
    sp = root / "recovery-stale.spec.json"
    sp.write_text(json.dumps(spec))
    s1, _ = W.execute(sp, wd, CAPS)
    (wd / "out" / "produce.txt").write_text("tampered\n")
    s2, led = W.execute(sp, wd, CAPS + ["tool:late"], resume=True)
    ok = (s1["status"] == "PARTIAL" and s2["status"] == "COMPLETE" and len(led["steps"]["produce"]["history"]) == 2
          and "produce-OK" in (wd / "out" / "consume.txt").read_text())
    tick("recovery", ok)
    out.append({"name": "recovery:stale-artifact-rerun", "expected": "PARTIAL then COMPLETE, producer re-run",
                "got": f"{s1['status']} then {s2['status']}, producer attempts {len(led['steps']['produce']['history'])}", "pass": ok})
    # 2. interrupted run: kill the executor while a step is running, then resume
    wd = root / "recovery-interrupted"
    shutil.rmtree(wd, ignore_errors=True)
    wd.mkdir(parents=True)
    spec = {"name": "interrupt", "steps": [step("quick"), step("long", "slow", ["quick"], sleep=3, timeout_s=30),
                                           step("tail", "concat", ["long"], {"i": "long.main"})]}
    sp = root / "recovery-interrupted.spec.json"
    sp.write_text(json.dumps(spec))
    proc = subprocess.Popen([PY, str(SCRIPTS / "omega_workflow.py"), "run", str(sp), "--workdir", str(wd),  # noqa: S603
                             "--capabilities", "tool:python"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    deadline = time.time() + 20
    seen_running = False
    while time.time() < deadline:
        try:
            led = json.loads((wd / W.LEDGER).read_text())
            if led["steps"]["long"]["status"] == "RUNNING":
                seen_running = True
                break
        except (OSError, ValueError, KeyError):
            pass
        time.sleep(0.05)
    proc.send_signal(signal.SIGKILL)
    proc.wait()
    s2, led = W.execute(sp, wd, CAPS, resume=True)
    ok = seen_running and s2["status"] == "COMPLETE" and any(e.get("reason") == "interrupted while running; re-run" for e in led["events"])
    tick("recovery", ok)
    out.append({"name": "recovery:interrupted-run-resume", "expected": "RUNNING at kill, COMPLETE after resume",
                "got": f"running_seen={seen_running}, {s2['status']}", "pass": ok})
    # 3. spec changed between runs must be refused
    sp.write_text(json.dumps({**spec, "name": "changed"}))
    try:
        W.execute(sp, wd, CAPS, resume=True)
        ok = False
    except W.SpecError:
        ok = True
    tick("recovery", ok)
    out.append({"name": "recovery:spec-changed-refused", "expected": "refused", "got": "refused" if ok else "accepted", "pass": ok})
    # 4. integrity check between steps in the same run: corrupt a prerequisite's output right after it completes
    wd = root / "recovery-midrun-corruption"
    shutil.rmtree(wd, ignore_errors=True)
    wd.mkdir(parents=True)
    tamper = [PY, "-c", "import pathlib;pathlib.Path('out/first.txt').write_text('evil');pathlib.Path('out/t.txt').write_text('x')"]
    spec = {"name": "midrun", "steps": [step("first"), {"id": "tamperer", "action": "corrupts first", "capability": "tool:python",
                                                         "prerequisites": ["first"], "command": tamper,
                                                         "outputs": {"main": {"path": "out/t.txt"}}},
                                        step("second", "concat", ["first", "tamperer"], {"i": "first.main"})]}
    sp = root / "recovery-midrun.spec.json"
    sp.write_text(json.dumps(spec))
    s, led = W.execute(sp, wd, CAPS)
    ok = led["steps"]["second"]["history"] == [] and led["steps"]["first"]["status"] == "FAILED" and s["status"] != "COMPLETE"
    tick("recovery", ok)
    out.append({"name": "recovery:corruption-between-steps-detected", "expected": "first FAILED (integrity), second never runs",
                "got": f"first={led['steps']['first']['status']} second_ran={bool(led['steps']['second']['history'])}", "pass": ok})
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--json")
    ap.add_argument("--keep")
    a = ap.parse_args(argv)
    results, crit, root = run_matrix(a.keep)
    for r in results:
        print(("PASS " if r["pass"] else "FAIL ") + r["name"] + ("" if r["pass"] else f"  expected={r['expected']} got={r['got']} "
                                                              f"{r.get('step_mismatch', '')} {r.get('audit', '')} {r.get('extra', '')}"))
    print("\ncriteria:")
    gate = True
    for k, (ok, n) in crit.items():
        print(f"  {k:<26} {ok}/{n}" + ("" if ok == n else "   NOT PASSED"))
        gate &= ok == n
    total = sum(r["pass"] for r in results)
    print(f"\nscenarios {total}/{len(results)}; multi-step gate: {'PASSED' if gate and total == len(results) else 'NOT PASSED'}")
    if a.json:
        Path(a.json).write_text(json.dumps({"results": results, "criteria": crit, "passed": gate and total == len(results)}, indent=1))
    if not a.keep:
        shutil.rmtree(root, ignore_errors=True)
    return 0 if gate and total == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
